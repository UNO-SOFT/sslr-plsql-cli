// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import org.A.J.E;
import org.A.J.q;
import org.A.J.EA;
import org.A.J.i;
import java.util.Iterator;
import org.A.J.r;
import org.A.J.h;
import org.A.J.u;
import org.A.J.M;
import java.util.LinkedList;
import org.A.J.F;
import org.A.J.e;
import org.A.F.G;

public class I implements G
{
    private e C;
    private F B;
    protected boolean D;
    protected LinkedList A;
    
    public I() {
        this.A = new LinkedList();
        this.C = new M();
    }
    
    public void A(final e c) {
        this.C = c;
    }
    
    public e f() {
        return this.C;
    }
    
    public F i() {
        return this.D(true);
    }
    
    public F D(final boolean b) {
        if (b && !this.D) {
            this.B.A();
            this.D = true;
        }
        return this.B;
    }
    
    public void S() {
        this.D = false;
        this.c();
    }
    
    public void T() throws S {
        this.B = this.f().A((u)this.a());
        this.d();
    }
    
    public void L() {
        this.c();
    }
    
    public void M() throws S {
        h h;
        r r;
        if (this._() == 2) {
            h = (h)this.a();
            r = (r)this.a();
        }
        else {
            final Object a = this.a();
            if (a instanceof h) {
                h = (h)a;
                r = null;
            }
            else {
                h = null;
                r = (r)a;
            }
        }
        this.d();
        this.A(this.f().A(r, h));
    }
    
    public void Q() throws S {
        this.c();
        this.A(this.f().A());
    }
    
    public void F() throws S {
        this.g();
    }
    
    public void N() throws S {
        this.c();
        this.A(this.f().C());
    }
    
    public void D() throws S {
        this.g();
    }
    
    protected void g() throws S {
        final h h = this.e().removeFirst();
        this.A(h, this.d().iterator());
        this.A(h);
    }
    
    protected void A(final h h, final Iterator iterator) {
        while (iterator.hasNext()) {
            h.A(iterator.next());
        }
    }
    
    public void A(final int n, final String s, final String s2) throws S {
        this.c();
        this.A(this.f().A(n, s, s2));
    }
    
    public void P() {
        this.b();
    }
    
    public void C(final int n) throws S {
        this.c();
        this.A(this.f().A(n));
    }
    
    public void W() {
        this.b();
    }
    
    public void B(final int n) throws S {
        this.c();
        this.A(this.f().B(n));
    }
    
    public void R() {
        this.b();
    }
    
    public void E(final int n) throws S {
        this.c();
        this.A(this.f().D(n));
    }
    
    public void Y() {
        this.b();
    }
    
    public void A(final int n, final String s) throws S {
        this.c();
        this.A(this.f().A(n, s));
    }
    
    public void V() {
        this.b();
    }
    
    protected void b() {
        final i i = this.e().removeFirst();
        this.A(i, this.d().iterator());
        this.A(i);
    }
    
    public void O() {
        this.c();
    }
    
    public void X() throws S {
        final q b = this.f().B((u)this.a());
        this.d();
        this.A(b);
    }
    
    public void J() {
        this.c();
    }
    
    public void H() throws S {
        final r c = this.f().C(this.e().removeFirst());
        this.A(c, this.d().iterator());
        this.A(c);
    }
    
    protected void A(final EA ea, final Iterator iterator) {
        while (iterator.hasNext()) {
            ea.A(iterator.next());
        }
    }
    
    protected void h() {
        final u u = (u)this.a();
        this.d();
        this.A(u);
    }
    
    public void C() {
    }
    
    public void B(final boolean b) throws S {
        if (b) {
            this.A(this.f().A((u)this.a(), (u)this.a()));
        }
    }
    
    public void K() {
    }
    
    public void A(final boolean b) throws S {
        if (b) {
            this.A(this.f().C((u)this.a(), (u)this.a()));
        }
    }
    
    public void A() {
    }
    
    public void G(final int n) throws S {
        if (n != 0) {
            this.A(this.f().A((u)this.a(), (u)this.a(), n));
        }
    }
    
    public void Z() {
    }
    
    public void I(final int n) throws S {
        if (n != 0) {
            this.A(this.f().B((u)this.a(), (u)this.a(), n));
        }
    }
    
    public void E() {
    }
    
    public void D(final int n) throws S {
        if (n != 0) {
            this.A(this.f().C((u)this.a(), (u)this.a(), n));
        }
    }
    
    public void G() {
    }
    
    public void H(final int n) throws S {
        if (n != 0) {
            this.A(this.f().D((u)this.a(), (u)this.a(), n));
        }
    }
    
    public void B() {
    }
    
    public void F(final int n) throws S {
        if (n != 0) {
            this.A(this.f().A((u)this.a(), n));
        }
    }
    
    public void U() {
    }
    
    public void C(final boolean b) throws S {
        if (b) {
            this.A(this.f().B((u)this.a(), (u)this.a()));
        }
    }
    
    public void A(final int n) throws S {
        this.A(this.f().C(n));
    }
    
    public void A(final double n) throws S {
        this.A(this.f().A(n));
    }
    
    public void A(final String s) throws S {
        this.A(this.f().A(s));
    }
    
    public void B(final String s, final String s2) throws S {
        this.A(this.f().B(s, s2));
    }
    
    public void A(final String s, final String s2) throws S {
        this.c();
        this.A(this.f().A(s, s2));
    }
    
    public void I() {
        final E e = this.e().removeFirst();
        this.A(e, this.d().iterator());
        this.A(e);
    }
    
    protected void A(final E e, final Iterator iterator) {
        while (iterator.hasNext()) {
            e.A(iterator.next());
        }
    }
    
    protected int _() {
        return this.e().size();
    }
    
    protected void A(final Object e) {
        this.e().addLast(e);
    }
    
    protected Object a() {
        return this.e().removeLast();
    }
    
    protected boolean j() {
        return this.e().size() > 0;
    }
    
    protected void c() {
        this.A.addLast(new LinkedList<LinkedList>());
    }
    
    protected LinkedList d() {
        return this.A.removeLast();
    }
    
    protected LinkedList e() {
        return this.A.getLast();
    }
}
