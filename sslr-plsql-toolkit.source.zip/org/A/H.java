// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import java.util.List;

public interface H
{
    Object A(final P p0, final List p1) throws K;
}
