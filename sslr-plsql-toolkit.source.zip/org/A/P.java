// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import java.util.Collection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.io.Serializable;

public class P implements Serializable
{
    private static final long E = 2315979994685591055L;
    private V B;
    private List D;
    private int C;
    private int A;
    
    public P(final V b) {
        this.B = b;
        this.D = Collections.EMPTY_LIST;
        this.C = 0;
        this.A = 0;
    }
    
    public void A(final List d) {
        this.D = d;
        this.C = d.size();
        if (this.A >= this.C) {
            this.A = 0;
        }
    }
    
    public List F() {
        return this.D;
    }
    
    public void A(final V b) {
        this.B = b;
    }
    
    public V C() {
        return this.B;
    }
    
    public E D() {
        return this.C().D();
    }
    
    public String A(final String s) {
        return this.C().A(s);
    }
    
    public Object A(final String s, final String s2, final String s3) throws U {
        return this.C().A(s, s2, s3);
    }
    
    public H B(final String s, final String s2, final String s3) throws U {
        return this.C().B(s, s2, s3);
    }
    
    public void A(final int c) {
        this.C = c;
    }
    
    public int B() {
        return this.C;
    }
    
    public void B(final int a) {
        this.A = a;
    }
    
    public int A() {
        return this.A;
    }
    
    public P E() {
        final P p = new P(this.C());
        final List f = this.F();
        if (f != null) {
            final ArrayList list = new ArrayList(f.size());
            list.addAll(f);
            p.A(list);
            p.B(this.A);
        }
        return p;
    }
}
