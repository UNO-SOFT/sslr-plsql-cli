// 
// Decompiled by Procyon v0.6.0
// 

package org.A.H;

import org.jdom.Namespace;
import org.jdom.Element;

public class B
{
    private Element A;
    private Namespace B;
    
    public B(final Namespace b) {
        this.B = b;
    }
    
    public B(final Element a, final Namespace b) {
        this.A = a;
        this.B = b;
    }
    
    public Element B() {
        return this.A;
    }
    
    public void A(final Element a) {
        this.A = a;
    }
    
    public Namespace A() {
        return this.B;
    }
    
    public String toString() {
        return "[xmlns:" + this.B.getPrefix() + "=\"" + this.B.getURI() + "\", element=" + this.A.getName() + "]";
    }
}
