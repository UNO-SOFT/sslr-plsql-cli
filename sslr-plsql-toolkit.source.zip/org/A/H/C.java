// 
// Decompiled by Procyon v0.6.0
// 

package org.A.H;

import org.A.S;
import org.A.F;

public class C extends F
{
    private static final long H = 6426091824802286928L;
    
    public C(final String s) throws S {
        super(s, org.A.H.A.D());
    }
}
