// 
// Decompiled by Procyon v0.6.0
// 

package org.A.H;

private static class _A
{
    private static A A;
    
    static {
        _A.A = new A();
    }
}
