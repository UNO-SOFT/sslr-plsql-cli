// 
// Decompiled by Procyon v0.6.0
// 

package org.A.H;

import org.A.K;
import org.jdom.input.SAXBuilder;
import org.A.D;
import java.util.HashMap;
import org.A.E.F;
import org.A.M;
import java.util.Iterator;
import org.jdom.Namespace;
import org.jdom.Document;
import org.jdom.ProcessingInstruction;
import org.jdom.Attribute;
import org.jdom.CDATA;
import org.jdom.Text;
import org.jdom.Comment;
import org.jdom.Element;
import org.A.E;
import org.A.J;
import org.A.L;

public class A extends L implements J
{
    private static final long F = -1636727587303584165L;
    
    public static E D() {
        return _A.A;
    }
    
    public boolean isElement(final Object o) {
        return o instanceof Element;
    }
    
    public boolean isComment(final Object o) {
        return o instanceof Comment;
    }
    
    public boolean isText(final Object o) {
        return o instanceof Text || o instanceof CDATA;
    }
    
    public boolean isAttribute(final Object o) {
        return o instanceof Attribute;
    }
    
    public boolean isProcessingInstruction(final Object o) {
        return o instanceof ProcessingInstruction;
    }
    
    public boolean isDocument(final Object o) {
        return o instanceof Document;
    }
    
    public boolean isNamespace(final Object o) {
        return o instanceof Namespace || o instanceof B;
    }
    
    public String getElementName(final Object o) {
        return ((Element)o).getName();
    }
    
    public String getElementNamespaceUri(final Object o) {
        final String namespaceURI = ((Element)o).getNamespaceURI();
        if (namespaceURI != null && namespaceURI.length() == 0) {
            return null;
        }
        return namespaceURI;
    }
    
    public String getAttributeName(final Object o) {
        return ((Attribute)o).getName();
    }
    
    public String getAttributeNamespaceUri(final Object o) {
        final String namespaceURI = ((Attribute)o).getNamespaceURI();
        if (namespaceURI != null && namespaceURI.length() == 0) {
            return null;
        }
        return namespaceURI;
    }
    
    public Iterator getChildAxisIterator(final Object o) {
        if (o instanceof Element) {
            return ((Element)o).getContent().iterator();
        }
        if (o instanceof Document) {
            return ((Document)o).getContent().iterator();
        }
        return M.B;
    }
    
    public Iterator A(final Object o, final String anObject, final String s, final String s2) {
        if (o instanceof Element) {
            final Element element = (Element)o;
            if (s2 == null) {
                return element.getChildren(anObject).iterator();
            }
            return element.getChildren(anObject, Namespace.getNamespace(s, s2)).iterator();
        }
        else {
            if (!(o instanceof Document)) {
                return M.B;
            }
            final Element rootElement = ((Document)o).getRootElement();
            if (!rootElement.getName().equals(anObject)) {
                return M.B;
            }
            if (s2 != null) {
                if (!Namespace.getNamespace(s, s2).equals((Object)rootElement.getNamespace())) {
                    return M.B;
                }
            }
            else if (rootElement.getNamespace() != Namespace.NO_NAMESPACE) {
                return M.B;
            }
            return new F(rootElement);
        }
    }
    
    public Iterator getNamespaceAxisIterator(final Object o) {
        if (!(o instanceof Element)) {
            return M.B;
        }
        final Element element = (Element)o;
        final HashMap hashMap = new HashMap();
        Element element2 = element;
        while (element2 != null) {
            final Namespace namespace = element2.getNamespace();
            if (namespace != Namespace.NO_NAMESPACE && !hashMap.containsKey(namespace.getPrefix())) {
                hashMap.put(namespace.getPrefix(), new B(element, namespace));
            }
            final Iterator iterator = element2.getAdditionalNamespaces().iterator();
            while (iterator.hasNext()) {
                final Namespace namespace2 = (Namespace)iterator.next();
                if (!hashMap.containsKey(namespace2.getPrefix())) {
                    hashMap.put(namespace2.getPrefix(), new B(element, namespace2));
                }
            }
            final Iterator iterator2 = element2.getAttributes().iterator();
            while (iterator2.hasNext()) {
                final Namespace namespace3 = ((Attribute)iterator2.next()).getNamespace();
                if (namespace3 != Namespace.NO_NAMESPACE && !hashMap.containsKey(namespace3.getPrefix())) {
                    hashMap.put(namespace3.getPrefix(), new B(element, namespace3));
                }
            }
            if (element2.getParent() instanceof Element) {
                element2 = (Element)element2.getParent();
            }
            else {
                element2 = null;
            }
        }
        hashMap.put("xml", new B(element, Namespace.XML_NAMESPACE));
        return hashMap.values().iterator();
    }
    
    public Iterator getParentAxisIterator(final Object o) {
        Object o2 = null;
        if (o instanceof Document) {
            return M.B;
        }
        if (o instanceof Element) {
            o2 = ((Element)o).getParent();
            if (o2 == null && ((Element)o).isRootElement()) {
                o2 = ((Element)o).getDocument();
            }
        }
        else if (o instanceof Attribute) {
            o2 = ((Attribute)o).getParent();
        }
        else if (o instanceof B) {
            o2 = ((B)o).B();
        }
        else if (o instanceof ProcessingInstruction) {
            o2 = ((ProcessingInstruction)o).getParent();
        }
        else if (o instanceof Comment) {
            o2 = ((Comment)o).getParent();
        }
        else if (o instanceof Text) {
            o2 = ((Text)o).getParent();
        }
        if (o2 != null) {
            return new F(o2);
        }
        return M.B;
    }
    
    public Iterator getAttributeAxisIterator(final Object o) {
        if (!(o instanceof Element)) {
            return M.B;
        }
        return ((Element)o).getAttributes().iterator();
    }
    
    public Iterator B(final Object o, final String s, final String s2, final String s3) {
        if (o instanceof Element) {
            final Attribute attribute = ((Element)o).getAttribute(s, (s3 == null) ? Namespace.NO_NAMESPACE : Namespace.getNamespace(s2, s3));
            if (attribute != null) {
                return new F(attribute);
            }
        }
        return M.B;
    }
    
    public D parseXPath(final String s) throws org.A.F.D {
        return new C(s);
    }
    
    public Object getDocumentNode(final Object o) {
        if (o instanceof Document) {
            return o;
        }
        return ((Element)o).getDocument();
    }
    
    public String getElementQName(final Object o) {
        final Element element = (Element)o;
        final String namespacePrefix = element.getNamespacePrefix();
        if (namespacePrefix == null || namespacePrefix.length() == 0) {
            return element.getName();
        }
        return namespacePrefix + ":" + element.getName();
    }
    
    public String getAttributeQName(final Object o) {
        final Attribute attribute = (Attribute)o;
        final String namespacePrefix = attribute.getNamespacePrefix();
        if (namespacePrefix == null || "".equals(namespacePrefix)) {
            return attribute.getName();
        }
        return namespacePrefix + ":" + attribute.getName();
    }
    
    public String getNamespaceStringValue(final Object o) {
        if (o instanceof Namespace) {
            return ((Namespace)o).getURI();
        }
        return ((B)o).A().getURI();
    }
    
    public String getNamespacePrefix(final Object o) {
        if (o instanceof Namespace) {
            return ((Namespace)o).getPrefix();
        }
        return ((B)o).A().getPrefix();
    }
    
    public String getTextStringValue(final Object o) {
        if (o instanceof Text) {
            return ((Text)o).getText();
        }
        if (o instanceof CDATA) {
            return ((CDATA)o).getText();
        }
        return "";
    }
    
    public String getAttributeStringValue(final Object o) {
        return ((Attribute)o).getValue();
    }
    
    public String getElementStringValue(final Object o) {
        final Element element = (Element)o;
        final StringBuffer sb = new StringBuffer();
        final Iterator iterator = element.getContent().iterator();
        while (iterator.hasNext()) {
            final Object next = iterator.next();
            if (next instanceof Text) {
                sb.append(((Text)next).getText());
            }
            else if (next instanceof CDATA) {
                sb.append(((CDATA)next).getText());
            }
            else {
                if (!(next instanceof Element)) {
                    continue;
                }
                sb.append(this.getElementStringValue(next));
            }
        }
        return sb.toString();
    }
    
    public String getProcessingInstructionTarget(final Object o) {
        return ((ProcessingInstruction)o).getTarget();
    }
    
    public String getProcessingInstructionData(final Object o) {
        return ((ProcessingInstruction)o).getData();
    }
    
    public String getCommentStringValue(final Object o) {
        return ((Comment)o).getText();
    }
    
    public String translateNamespacePrefixToUri(final String s, final Object o) {
        Element element = null;
        if (o instanceof Element) {
            element = (Element)o;
        }
        else if (o instanceof Text) {
            element = (Element)((Text)o).getParent();
        }
        else if (o instanceof Attribute) {
            element = ((Attribute)o).getParent();
        }
        else if (o instanceof B) {
            element = ((B)o).B();
        }
        else if (o instanceof Comment) {
            element = (Element)((Comment)o).getParent();
        }
        else if (o instanceof ProcessingInstruction) {
            element = (Element)((ProcessingInstruction)o).getParent();
        }
        if (element != null) {
            final Namespace namespace = element.getNamespace(s);
            if (namespace != null) {
                return namespace.getURI();
            }
        }
        return null;
    }
    
    public Object getDocument(final String s) throws K {
        try {
            return new SAXBuilder().build(s);
        }
        catch (final Exception ex) {
            throw new K(ex.getMessage());
        }
    }
    
    private static class _A
    {
        private static A A;
        
        static {
            _A.A = new A();
        }
    }
}
