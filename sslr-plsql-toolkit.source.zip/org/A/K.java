// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

public class K extends S
{
    private static final long N = 7908649612495640943L;
    
    public K(final String s) {
        super(s);
    }
    
    public K(final Throwable t) {
        super(t);
    }
    
    public K(final String s, final Exception ex) {
        super(s, ex);
    }
    
    public Throwable I() {
        return this.getCause();
    }
}
