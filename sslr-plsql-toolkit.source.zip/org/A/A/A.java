// 
// Decompiled by Procyon v0.6.0
// 

package org.A.A;

public class A
{
    private A C;
    private String B;
    private Object A;
    
    public A(final A c, final String b, final Object a) {
        this.C = c;
        this.B = b;
        this.A = a;
    }
    
    public A A() {
        return this.C;
    }
    
    public String B() {
        return this.B;
    }
    
    public Object C() {
        return this.A;
    }
}
