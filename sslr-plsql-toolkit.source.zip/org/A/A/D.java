// 
// Decompiled by Procyon v0.6.0
// 

package org.A.A;

import java.util.Iterator;

public class D implements Iterator
{
    private A C;
    private String A;
    private Iterator B;
    
    public D(final A c, final String a, final Iterator b) {
        this.C = c;
        this.A = a;
        this.B = b;
    }
    
    public boolean hasNext() {
        return this.B.hasNext();
    }
    
    public Object next() {
        return new A(this.C, this.A, this.B.next());
    }
    
    public void remove() {
        throw new UnsupportedOperationException();
    }
}
