// 
// Decompiled by Procyon v0.6.0
// 

package org.A.A;

import org.A.K;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import org.A.E.F;
import java.util.Collection;
import org.A.M;
import java.util.Iterator;
import org.A.E;
import org.A.J;
import org.A.L;

public class B extends L implements J
{
    private static final long K = -1768605107626726499L;
    private static final Class[] J;
    private static final Object[] I;
    private static final B H;
    
    public static E E() {
        return B.H;
    }
    
    public boolean isElement(final Object o) {
        return o instanceof A;
    }
    
    public boolean isComment(final Object o) {
        return false;
    }
    
    public boolean isText(final Object o) {
        return o instanceof String;
    }
    
    public boolean isAttribute(final Object o) {
        return false;
    }
    
    public boolean isProcessingInstruction(final Object o) {
        return false;
    }
    
    public boolean isDocument(final Object o) {
        return false;
    }
    
    public boolean isNamespace(final Object o) {
        return false;
    }
    
    public String getElementName(final Object o) {
        return ((A)o).B();
    }
    
    public String getElementNamespaceUri(final Object o) {
        return "";
    }
    
    public String getElementQName(final Object o) {
        return "";
    }
    
    public String getAttributeName(final Object o) {
        return "";
    }
    
    public String getAttributeNamespaceUri(final Object o) {
        return "";
    }
    
    public String getAttributeQName(final Object o) {
        return "";
    }
    
    public Iterator getChildAxisIterator(final Object o) {
        return M.B;
    }
    
    public Iterator A(final Object o, final String name, final String s, final String s2) {
        final Class<?> class1 = ((A)o).C().getClass();
        final String a = this.A(name);
        Method method;
        try {
            method = class1.getMethod("get" + a, (Class[])B.J);
        }
        catch (final NoSuchMethodException ex) {
            try {
                method = class1.getMethod("get" + a + "s", (Class[])B.J);
            }
            catch (final NoSuchMethodException ex2) {
                try {
                    method = class1.getMethod(name, (Class[])B.J);
                }
                catch (final NoSuchMethodException ex3) {
                    method = null;
                }
            }
        }
        if (method == null) {
            return M.B;
        }
        try {
            final Object invoke = method.invoke(((A)o).C(), B.I);
            if (invoke == null) {
                return M.B;
            }
            if (invoke instanceof Collection) {
                return new D((A)o, name, ((Collection)invoke).iterator());
            }
            if (((Collection)invoke).getClass().isArray()) {
                return M.B;
            }
            return new F(new A((A)o, name, invoke));
        }
        catch (final IllegalAccessException ex4) {}
        catch (final InvocationTargetException ex5) {}
        return M.B;
    }
    
    public Iterator getParentAxisIterator(final Object o) {
        if (o instanceof A) {
            return new F(((A)o).A());
        }
        return M.B;
    }
    
    public Iterator getAttributeAxisIterator(final Object o) {
        return M.B;
    }
    
    public Iterator B(final Object o, final String s, final String s2, final String s3) {
        return M.B;
    }
    
    public Iterator getNamespaceAxisIterator(final Object o) {
        return M.B;
    }
    
    public Object getDocumentNode(final Object o) {
        return null;
    }
    
    public Object getParentNode(final Object o) {
        if (o instanceof A) {
            return ((A)o).A();
        }
        return M.B;
    }
    
    public String getTextStringValue(final Object o) {
        if (o instanceof A) {
            return ((A)o).C().toString();
        }
        return o.toString();
    }
    
    public String getElementStringValue(final Object o) {
        if (o instanceof A) {
            return ((A)o).C().toString();
        }
        return o.toString();
    }
    
    public String getAttributeStringValue(final Object o) {
        return o.toString();
    }
    
    public String getNamespaceStringValue(final Object o) {
        return o.toString();
    }
    
    public String getNamespacePrefix(final Object o) {
        return null;
    }
    
    public String getCommentStringValue(final Object o) {
        return null;
    }
    
    public String translateNamespacePrefixToUri(final String s, final Object o) {
        return null;
    }
    
    public short getNodeType(final Object o) {
        return 0;
    }
    
    public Object getDocument(final String s) throws K {
        return null;
    }
    
    public String getProcessingInstructionTarget(final Object o) {
        return null;
    }
    
    public String getProcessingInstructionData(final Object o) {
        return null;
    }
    
    public org.A.D parseXPath(final String s) throws org.A.F.D {
        return new C(s);
    }
    
    protected String A(final String s) {
        if (s.length() == 0) {
            return s;
        }
        if (s.length() == 1) {
            return s.toUpperCase();
        }
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }
    
    static {
        J = new Class[0];
        I = new Object[0];
        H = new B();
    }
}
