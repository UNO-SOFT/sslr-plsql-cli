// 
// Decompiled by Procyon v0.6.0
// 

package org.A.A;

import java.util.Collection;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import org.A.P;
import org.A.S;
import org.A.F;

public class C extends F
{
    private static final long J = -1567521943360266313L;
    
    public C(final String s) throws S {
        super(s, org.A.A.B.E());
    }
    
    protected P H(final Object o) {
        if (o instanceof P) {
            return (P)o;
        }
        if (o instanceof A) {
            return super.H(o);
        }
        if (o instanceof List) {
            final ArrayList list = new ArrayList();
            final Iterator iterator = ((List)o).iterator();
            while (iterator.hasNext()) {
                list.add(new A(null, "root", iterator.next()));
            }
            return super.H(list);
        }
        return super.H(new A(null, "root", o));
    }
    
    public Object B(final Object o) throws S {
        final Object b = super.B(o);
        if (b instanceof A) {
            return ((A)b).C();
        }
        if (b instanceof Collection) {
            final ArrayList list = new ArrayList();
            final Iterator iterator = ((Collection)b).iterator();
            while (iterator.hasNext()) {
                final Object next = iterator.next();
                if (next instanceof A) {
                    list.add(((A)next).C());
                }
                else {
                    list.add(next);
                }
            }
            return list;
        }
        return b;
    }
}
