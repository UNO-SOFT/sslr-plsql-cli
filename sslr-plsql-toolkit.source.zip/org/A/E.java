// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import java.util.Iterator;
import java.io.Serializable;

public interface E extends Serializable
{
    Iterator getChildAxisIterator(final Object p0) throws X;
    
    Iterator getDescendantAxisIterator(final Object p0) throws X;
    
    Iterator getParentAxisIterator(final Object p0) throws X;
    
    Iterator getAncestorAxisIterator(final Object p0) throws X;
    
    Iterator getFollowingSiblingAxisIterator(final Object p0) throws X;
    
    Iterator getPrecedingSiblingAxisIterator(final Object p0) throws X;
    
    Iterator getFollowingAxisIterator(final Object p0) throws X;
    
    Iterator getPrecedingAxisIterator(final Object p0) throws X;
    
    Iterator getAttributeAxisIterator(final Object p0) throws X;
    
    Iterator getNamespaceAxisIterator(final Object p0) throws X;
    
    Iterator getSelfAxisIterator(final Object p0) throws X;
    
    Iterator getDescendantOrSelfAxisIterator(final Object p0) throws X;
    
    Iterator getAncestorOrSelfAxisIterator(final Object p0) throws X;
    
    Object getDocument(final String p0) throws K;
    
    Object getDocumentNode(final Object p0);
    
    Object getParentNode(final Object p0) throws X;
    
    String getElementNamespaceUri(final Object p0);
    
    String getElementName(final Object p0);
    
    String getElementQName(final Object p0);
    
    String getAttributeNamespaceUri(final Object p0);
    
    String getAttributeName(final Object p0);
    
    String getAttributeQName(final Object p0);
    
    String getProcessingInstructionTarget(final Object p0);
    
    String getProcessingInstructionData(final Object p0);
    
    boolean isDocument(final Object p0);
    
    boolean isElement(final Object p0);
    
    boolean isAttribute(final Object p0);
    
    boolean isNamespace(final Object p0);
    
    boolean isComment(final Object p0);
    
    boolean isText(final Object p0);
    
    boolean isProcessingInstruction(final Object p0);
    
    String getCommentStringValue(final Object p0);
    
    String getElementStringValue(final Object p0);
    
    String getAttributeStringValue(final Object p0);
    
    String getNamespaceStringValue(final Object p0);
    
    String getTextStringValue(final Object p0);
    
    String getNamespacePrefix(final Object p0);
    
    String translateNamespacePrefixToUri(final String p0, final Object p1);
    
    D parseXPath(final String p0) throws org.A.F.D;
    
    Object getElementById(final Object p0, final String p1);
    
    short getNodeType(final Object p0);
}
