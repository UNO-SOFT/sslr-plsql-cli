// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import java.io.Serializable;

public class V implements Serializable
{
    private static final long E = 4494082174713652559L;
    private transient C C;
    private O B;
    private T D;
    private E A;
    
    public V() {
    }
    
    public V(final O o, final C c, final T t, final E a) {
        this.A(o);
        this.A(c);
        this.A(t);
        this.A = a;
    }
    
    public void A(final O b) {
        this.B = b;
    }
    
    public O B() {
        return this.B;
    }
    
    public void A(final C c) {
        this.C = c;
    }
    
    public C C() {
        return this.C;
    }
    
    public void A(final T d) {
        this.D = d;
    }
    
    public T A() {
        return this.D;
    }
    
    public E D() {
        return this.A;
    }
    
    public String A(final String anObject) {
        if ("xml".equals(anObject)) {
            return "http://www.w3.org/XML/1998/namespace";
        }
        final O b = this.B();
        if (b != null) {
            return b.A(anObject);
        }
        return null;
    }
    
    public Object A(final String s, final String s2, final String s3) throws U {
        final T a = this.A();
        if (a != null) {
            return a.A(s, s2, s3);
        }
        throw new U("No variable context installed");
    }
    
    public H B(final String s, final String s2, final String s3) throws U {
        final C c = this.C();
        if (c != null) {
            return c.A(s, s2, s3);
        }
        throw new U("No function context installed");
    }
}
