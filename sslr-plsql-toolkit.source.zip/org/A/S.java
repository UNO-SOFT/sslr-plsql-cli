// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import org.A.F.D;

public class S extends D
{
    private static final long J = 7132891439526672639L;
    static double I;
    
    public S(final String s) {
        super(s);
    }
    
    public S(final Throwable t) {
        super(t);
    }
    
    public S(final String s, final Throwable t) {
        super(s, t);
    }
    
    static {
        S.I = 1.4;
        try {
            S.I = Double.valueOf(System.getProperty("java.version").substring(0, 3));
        }
        catch (final RuntimeException ex) {}
    }
}
