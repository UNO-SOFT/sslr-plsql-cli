// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

public class U extends S
{
    private static final long O = 953578478331961473L;
    
    public U(final String s) {
        super(s);
    }
}
