// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

abstract class A extends AA implements PA
{
    A(final u u, final u u2) {
        super(u, u2);
    }
    
    public String toString() {
        return "[(DefaultMultiplicativeExpr): " + this.X() + ", " + this.Y() + "]";
    }
}
