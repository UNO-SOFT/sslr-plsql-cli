// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import java.util.HashSet;

final class KA
{
    private HashSet A;
    
    KA() {
        this.A = new HashSet();
    }
    
    void A(final Object o) {
        this.A.add(new _A(o));
    }
    
    public boolean B(final Object o) {
        return this.A.contains(new _A(o));
    }
    
    private static class _A
    {
        private Object A;
        
        _A(final Object a) {
            this.A = a;
        }
        
        public boolean equals(final Object o) {
            return this.A == ((_A)o).A;
        }
        
        public int hashCode() {
            return System.identityHashCode(this.A);
        }
    }
}
