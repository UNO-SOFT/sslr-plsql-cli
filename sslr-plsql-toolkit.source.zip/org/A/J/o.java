// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import org.A.E;
import org.A.P;

class o extends C
{
    private static final long i = 4894552680753026730L;
    
    o(final u u, final u u2) {
        super(u, u2);
    }
    
    public String W() {
        return "or";
    }
    
    public String toString() {
        return "[(DefaultOrExpr): " + this.X() + ", " + this.Y() + "]";
    }
    
    public Object A(final P p) throws S {
        final E d = p.D();
        if (org.A.D.C.B(this.X().A(p), d)) {
            return Boolean.TRUE;
        }
        if (org.A.D.C.B(this.Y().A(p), d)) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }
}
