// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import java.util.Collection;
import java.util.ArrayList;
import org.A.P;
import java.util.List;

public class Q extends t implements r, EA
{
    private static final long L = -549640659288005735L;
    private u K;
    private LA J;
    
    public Q(final LA j) {
        this.J = j;
    }
    
    public Q(final u k, final LA j) {
        this.K = k;
        this.J = j;
    }
    
    public void A(final q q) {
        this.J.A(q);
    }
    
    public List K() {
        return this.J.B();
    }
    
    public LA L() {
        return this.J;
    }
    
    public u M() {
        return this.K;
    }
    
    public String toString() {
        return "[(DefaultFilterExpr): expr: " + this.K + " predicates: " + this.J + " ]";
    }
    
    public String A() {
        String a = "";
        if (this.K != null) {
            a = this.K.A();
        }
        return a + this.J.C();
    }
    
    public u B() {
        this.J.A();
        if (this.K != null) {
            this.K = this.K.B();
        }
        if (this.J.B().size() == 0) {
            return this.M();
        }
        return this;
    }
    
    public boolean B(final P p) throws S {
        Object a;
        if (this.K != null) {
            a = this.K.A(p);
        }
        else {
            final List f = p.F();
            final ArrayList list = new ArrayList(f.size());
            list.addAll(f);
            a = list;
        }
        if (a instanceof Boolean) {
            return (boolean)a;
        }
        return a instanceof List && this.L().B((List)a, p.C());
    }
    
    public Object A(final P p) throws S {
        Object o = this.M().A(p);
        if (o instanceof List) {
            o = this.L().A((List)o, p.C());
        }
        return o;
    }
}
