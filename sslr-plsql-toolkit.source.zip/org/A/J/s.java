// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import org.A.D._;
import org.A.P;

class s extends N
{
    private static final long e = 6468563688098527800L;
    
    s(final u u, final u u2) {
        super(u, u2);
    }
    
    public String W() {
        return "-";
    }
    
    public Object A(final P p) throws S {
        return new Double(_.K(this.X().A(p), p.D()).doubleValue() - _.K(this.Y().A(p), p.D()).doubleValue());
    }
}
