// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

class m extends p
{
    private static final long l = -7848747981787197470L;
    
    m(final u u, final u u2) {
        super(u, u2);
    }
    
    public String W() {
        return ">=";
    }
    
    protected boolean A(final Double n, final Double anotherDouble) {
        return n.compareTo(anotherDouble) >= 0;
    }
}
