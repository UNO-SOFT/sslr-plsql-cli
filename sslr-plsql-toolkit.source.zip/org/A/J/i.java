// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import java.util.List;
import org.A.P;
import org.A.X;
import java.util.Iterator;
import org.A.S;
import org.A.V;

public interface i extends EA
{
    boolean B(final Object p0, final V p1) throws S;
    
    String O();
    
    void N();
    
    int P();
    
    Iterator A(final Object p0, final V p1) throws X;
    
    List C(final P p0) throws S;
}
