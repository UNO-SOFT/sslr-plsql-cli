// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import java.util.List;
import org.A.P;

public class HA implements F
{
    private static final long B = 3007613096320896040L;
    private u A;
    
    public HA(final u a) {
        this.A = a;
    }
    
    public u C() {
        return this.A;
    }
    
    public void A(final u a) {
        this.A = a;
    }
    
    public String toString() {
        return "[(DefaultXPath): " + this.C() + "]";
    }
    
    public String B() {
        return this.C().A();
    }
    
    public void A() {
        this.A(this.C().B());
    }
    
    public List A(final P p) throws S {
        return t.A(this.C().A(p));
    }
}
