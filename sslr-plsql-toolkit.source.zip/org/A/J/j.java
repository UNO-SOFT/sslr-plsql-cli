// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import java.util.Iterator;
import org.A.X;
import org.A.E;
import java.util.Comparator;

class j implements Comparator
{
    private E A;
    
    j(final E a) {
        this.A = a;
    }
    
    public int compare(final Object o, final Object o2) {
        if (o == o2) {
            return 0;
        }
        if (this.A == null) {
            return 0;
        }
        if (this.B(o) && this.B(o2)) {
            try {
                final Object parentNode = this.A.getParentNode(o);
                final Object parentNode2 = this.A.getParentNode(o2);
                if (parentNode == parentNode2) {
                    if (this.A.isNamespace(o) && this.A.isAttribute(o2)) {
                        return -1;
                    }
                    if (this.A.isNamespace(o2) && this.A.isAttribute(o)) {
                        return 1;
                    }
                    if (this.A.isNamespace(o)) {
                        return this.A.getNamespacePrefix(o).compareTo(this.A.getNamespacePrefix(o2));
                    }
                    if (this.A.isAttribute(o)) {
                        return this.A.getAttributeQName(o).compareTo(this.A.getAttributeQName(o2));
                    }
                }
                return this.compare(parentNode, parentNode2);
            }
            catch (final X x) {
                return 0;
            }
        }
        try {
            int i = this.A(o);
            int j = this.A(o2);
            Object parentNode3 = o;
            Object parentNode4 = o2;
            while (i > j) {
                parentNode3 = this.A.getParentNode(parentNode3);
                --i;
            }
            if (parentNode3 == o2) {
                return 1;
            }
            while (j > i) {
                parentNode4 = this.A.getParentNode(parentNode4);
                --j;
            }
            if (parentNode4 == o) {
                return -1;
            }
            while (true) {
                final Object parentNode5 = this.A.getParentNode(parentNode3);
                final Object parentNode6 = this.A.getParentNode(parentNode4);
                if (parentNode5 == parentNode6) {
                    break;
                }
                parentNode3 = parentNode5;
                parentNode4 = parentNode6;
            }
            return this.A(parentNode3, parentNode4);
        }
        catch (final X x2) {
            return 0;
        }
    }
    
    private boolean B(final Object o) {
        return this.A.isAttribute(o) || this.A.isNamespace(o);
    }
    
    private int A(final Object o, final Object obj) throws X {
        if (this.B(o)) {
            return 1;
        }
        if (this.B(obj)) {
            return -1;
        }
        final Iterator followingSiblingAxisIterator = this.A.getFollowingSiblingAxisIterator(o);
        while (followingSiblingAxisIterator.hasNext()) {
            if (followingSiblingAxisIterator.next().equals(obj)) {
                return -1;
            }
        }
        return 1;
    }
    
    private int A(final Object o) throws X {
        int n = 0;
        Object parentNode = o;
        while ((parentNode = this.A.getParentNode(parentNode)) != null) {
            ++n;
        }
        return n;
    }
}
