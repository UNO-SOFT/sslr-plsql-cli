// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.E;
import org.A.S;
import java.util.Iterator;
import org.A.V;
import org.A.U;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.A.P;
import org.A.J.A.K;

public class _ extends g implements b
{
    private static final long V = 428414912247718390L;
    private String U;
    private String S;
    private boolean T;
    private boolean R;
    
    public _(final K k, final String u, final String s, final LA la) {
        super(k, la);
        this.U = u;
        this.S = s;
        this.T = "*".equals(s);
        this.R = (this.U != null && this.U.length() > 0);
    }
    
    public String U() {
        return this.U;
    }
    
    public String T() {
        return this.S;
    }
    
    public boolean V() {
        return this.T;
    }
    
    public String O() {
        final StringBuffer sb = new StringBuffer(64);
        sb.append(this.Q()).append("::");
        if (this.U() != null && this.U().length() > 0) {
            sb.append(this.U()).append(':');
        }
        return sb.append(this.T()).append(super.O()).toString();
    }
    
    public List C(final P p) throws S {
        final List f = p.F();
        final int size = f.size();
        if (size == 0) {
            return Collections.EMPTY_LIST;
        }
        final V c = p.C();
        final K r = this.R();
        final boolean b = !this.T && r.A(c);
        if (size != 1) {
            final KA ka = new KA();
            final ArrayList list = new ArrayList(size);
            final ArrayList list2 = new ArrayList(size);
            if (b) {
                String a = null;
                if (this.R) {
                    a = c.A(this.U);
                    if (a == null) {
                        throw new U("XPath expression uses unbound namespace prefix " + this.U);
                    }
                }
                for (int i = 0; i < size; ++i) {
                    final Iterator a2 = r.A(f.get(i), c, this.S, this.U, a);
                    if (a2 != null) {
                        if (a2.hasNext()) {
                            while (a2.hasNext()) {
                                list.add(a2.next());
                            }
                            final Iterator iterator = this.L().A(list, c).iterator();
                            while (iterator.hasNext()) {
                                final Object next = iterator.next();
                                if (!ka.B(next)) {
                                    ka.A(next);
                                    list2.add(next);
                                }
                            }
                            list.clear();
                        }
                    }
                }
            }
            else {
                for (int j = 0; j < size; ++j) {
                    final Iterator a3 = this.A(f.get(j), c);
                    if (a3 != null) {
                        if (a3.hasNext()) {
                            while (a3.hasNext()) {
                                final Object next2 = a3.next();
                                if (this.B(next2, c)) {
                                    list.add(next2);
                                }
                            }
                            final Iterator iterator2 = this.L().A(list, c).iterator();
                            while (iterator2.hasNext()) {
                                final Object next3 = iterator2.next();
                                if (!ka.B(next3)) {
                                    ka.A(next3);
                                    list2.add(next3);
                                }
                            }
                            list.clear();
                        }
                    }
                }
            }
            return list2;
        }
        final Object value = f.get(0);
        if (b) {
            String a4 = null;
            if (this.R) {
                a4 = c.A(this.U);
                if (a4 == null) {
                    throw new U("XPath expression uses unbound namespace prefix " + this.U);
                }
            }
            final Iterator a5 = r.A(value, c, this.S, this.U, a4);
            if (a5 == null || !a5.hasNext()) {
                return Collections.EMPTY_LIST;
            }
            final ArrayList list3 = new ArrayList();
            while (a5.hasNext()) {
                list3.add(a5.next());
            }
            return this.L().A(list3, c);
        }
        else {
            final Iterator a6 = r.A(value, c);
            if (a6 == null || !a6.hasNext()) {
                return Collections.EMPTY_LIST;
            }
            final ArrayList list4 = new ArrayList(size);
            while (a6.hasNext()) {
                final Object next4 = a6.next();
                if (this.B(next4, c)) {
                    list4.add(next4);
                }
            }
            return this.L().A(list4, c);
        }
    }
    
    public boolean B(final Object o, final V v) throws S {
        final E d = v.D();
        String a = null;
        String s = null;
        String s2;
        if (d.isElement(o)) {
            s2 = d.getElementName(o);
            s = d.getElementNamespaceUri(o);
        }
        else {
            if (d.isText(o)) {
                return false;
            }
            if (d.isAttribute(o)) {
                if (this.P() != 9) {
                    return false;
                }
                s2 = d.getAttributeName(o);
                s = d.getAttributeNamespaceUri(o);
            }
            else {
                if (d.isDocument(o)) {
                    return false;
                }
                if (!d.isNamespace(o)) {
                    return false;
                }
                if (this.P() != 10) {
                    return false;
                }
                s2 = d.getNamespacePrefix(o);
            }
        }
        if (this.R) {
            a = v.A(this.U);
            if (a == null) {
                throw new U("Cannot resolve namespace prefix '" + this.U + "'");
            }
        }
        else if (this.T) {
            return true;
        }
        return this.A(a) == this.A(s) && (this.T || s2.equals(this.T())) && this.A(a, s);
    }
    
    private boolean A(final String s) {
        return s != null && s.length() > 0;
    }
    
    protected boolean A(final String s, final String anObject) {
        if (s == anObject) {
            return true;
        }
        if (s == null) {
            return anObject.length() == 0;
        }
        if (anObject == null) {
            return s.length() == 0;
        }
        return s.equals(anObject);
    }
    
    public String toString() {
        return "[(DefaultNameStep): " + ("".equals(this.U()) ? this.T() : (this.U() + ":" + this.T())) + "]";
    }
}
