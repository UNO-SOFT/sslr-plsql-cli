// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.V;
import org.A.J.A.K;

public class MA extends g implements v
{
    private static final long W = 292886316770123856L;
    
    public MA(final K k, final LA la) {
        super(k, la);
    }
    
    public String toString() {
        return "[(DefaultAllNodeStep): " + this.Q() + "]";
    }
    
    public String O() {
        return this.Q() + "::node()" + super.O();
    }
    
    public boolean B(final Object o, final V v) {
        return true;
    }
}
