// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.E.E;
import org.A.E.F;
import java.util.List;
import java.util.Iterator;

public abstract class t implements u
{
    public u B() {
        return this;
    }
    
    public static Iterator B(final Object o) {
        if (o instanceof Iterator) {
            return (Iterator)o;
        }
        if (o instanceof List) {
            return ((List)o).iterator();
        }
        return new F(o);
    }
    
    public static List A(final Object o) {
        if (o instanceof List) {
            return (List)o;
        }
        return new E(o);
    }
}
