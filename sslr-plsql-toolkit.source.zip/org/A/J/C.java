// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

abstract class C extends GA implements BA
{
    C(final u u, final u u2) {
        super(u, u2);
    }
}
