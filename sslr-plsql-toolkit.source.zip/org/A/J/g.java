// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import java.util.Collection;
import java.util.ArrayList;
import org.A.P;
import org.A.X;
import java.util.Iterator;
import org.A.V;
import org.A.F.B;
import java.util.List;
import org.A.J.A.K;

public abstract class g implements i
{
    private K N;
    private LA M;
    
    public g(final K n, final LA m) {
        this.N = n;
        this.M = m;
    }
    
    public void A(final q q) {
        this.M.A(q);
    }
    
    public List K() {
        return this.M.B();
    }
    
    public LA L() {
        return this.M;
    }
    
    public int P() {
        return this.N.A();
    }
    
    public K R() {
        return this.N;
    }
    
    public String Q() {
        return B.A(this.P());
    }
    
    public String O() {
        return this.M.C();
    }
    
    public String toString() {
        return this.R() + " " + super.toString();
    }
    
    public void N() {
        this.M.A();
    }
    
    public Iterator A(final Object o, final V v) throws X {
        return this.R().A(o, v);
    }
    
    public List C(final P p) throws S {
        final List f = p.F();
        final KA ka = new KA();
        final int size = f.size();
        final ArrayList list = new ArrayList();
        final ArrayList list2 = new ArrayList();
        final V c = p.C();
        for (int i = 0; i < size; ++i) {
            final Iterator a = this.N.A(f.get(i), c);
            while (a.hasNext()) {
                final Object next = a.next();
                if (!ka.B(next) && this.B(next, c)) {
                    ka.A(next);
                    list.add(next);
                }
            }
            list2.addAll(this.L().A(list, c));
            list.clear();
        }
        return list2;
    }
}
