// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.D._;

class f extends B
{
    private static final long f = -8327599812627931648L;
    
    f(final u u, final u u2) {
        super(u, u2);
    }
    
    public String W() {
        return "=";
    }
    
    public String toString() {
        return "[(DefaultEqualsExpr): " + this.X() + ", " + this.Y() + "]";
    }
    
    protected boolean F(final Object o, final Object obj) {
        return (!this.C(o, obj) || (!_.A((Double)o) && !_.A((Double)obj))) && o.equals(obj);
    }
}
