// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import org.A.D._;

class P extends t implements d
{
    private static final long I = 2303714238683092334L;
    private u H;
    
    P(final u h) {
        this.H = h;
    }
    
    public u J() {
        return this.H;
    }
    
    public String toString() {
        return "[(DefaultUnaryExpr): " + this.J() + "]";
    }
    
    public String A() {
        return "-(" + this.J().A() + ")";
    }
    
    public u B() {
        this.H = this.H.B();
        return this;
    }
    
    public Object A(final org.A.P p) throws S {
        return new Double(_.K(this.J().A(p), p.D()).doubleValue() * -1.0);
    }
}
