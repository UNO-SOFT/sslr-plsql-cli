// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import org.A.V;
import java.util.Comparator;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import org.A.P;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

abstract class O extends t implements h
{
    private List E;
    
    O() {
        this.E = new LinkedList();
    }
    
    public void A(final i i) {
        this.H().add(i);
    }
    
    public List H() {
        return this.E;
    }
    
    public u B() {
        final Iterator iterator = this.H().iterator();
        while (iterator.hasNext()) {
            ((i)iterator.next()).N();
        }
        return this;
    }
    
    public String A() {
        final StringBuffer sb = new StringBuffer();
        final Iterator iterator = this.H().iterator();
        while (iterator.hasNext()) {
            sb.append(((i)iterator.next()).O());
            if (iterator.hasNext()) {
                sb.append("/");
            }
        }
        return sb.toString();
    }
    
    public String toString() {
        final StringBuffer sb = new StringBuffer();
        final Iterator iterator = this.H().iterator();
        while (iterator.hasNext()) {
            sb.append(iterator.next().toString());
            if (iterator.hasNext()) {
                sb.append("/");
            }
        }
        return sb.toString();
    }
    
    public boolean I() {
        return false;
    }
    
    public Object A(final P p) throws S {
        final List f = p.F();
        List c = new ArrayList(f);
        final V c2 = p.C();
        final P p2 = new P(c2);
        final Iterator iterator = this.H().iterator();
        while (iterator.hasNext()) {
            final i i = (i)iterator.next();
            p2.A(c);
            c = i.C(p2);
            if (this.B(i)) {
                Collections.reverse(c);
            }
        }
        if (this.H().size() > 1 || f.size() > 1) {
            Collections.sort((List<Object>)c, new j(c2.D()));
        }
        return c;
    }
    
    private boolean B(final i i) {
        final int p = i.P();
        return p == 8 || p == 6 || p == 4 || p == 13;
    }
}
