// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import org.A.P;

class X implements q
{
    private static final long B = -4140068594075364971L;
    private u A;
    
    X(final u u) {
        this.A(u);
    }
    
    public u C() {
        return this.A;
    }
    
    public void A(final u a) {
        this.A = a;
    }
    
    public String B() {
        return "[" + this.C().A() + "]";
    }
    
    public String toString() {
        return "[(DefaultPredicate): " + this.C() + "]";
    }
    
    public void A() {
        this.A(this.C().B());
    }
    
    public Object A(final P p) throws S {
        return this.C().A(p);
    }
}
