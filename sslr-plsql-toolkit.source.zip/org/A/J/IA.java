// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.D._;

class IA extends B
{
    private static final long g = -8001267398136979152L;
    
    IA(final u u, final u u2) {
        super(u, u2);
    }
    
    public String W() {
        return "!=";
    }
    
    public String toString() {
        return "[(DefaultNotEqualsExpr): " + this.X() + ", " + this.Y() + "]";
    }
    
    protected boolean F(final Object o, final Object obj) {
        return (this.C(o, obj) && (_.A((Double)o) || _.A((Double)obj))) || !o.equals(obj);
    }
}
