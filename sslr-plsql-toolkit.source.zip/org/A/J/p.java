// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.D._;
import java.util.Iterator;
import org.A.S;
import org.A.E;
import java.util.List;
import org.A.P;

abstract class p extends GA implements J
{
    p(final u u, final u u2) {
        super(u, u2);
    }
    
    public String toString() {
        return "[(DefaultRelationalExpr): " + this.X() + ", " + this.Y() + "]";
    }
    
    public Object A(final P p) throws S {
        final Object a = this.X().A(p);
        final Object a2 = this.Y().A(p);
        final E d = p.D();
        if (this.A(a, a2)) {
            return this.B((List)a, (List)a2, d);
        }
        if (!this.E(a, a2)) {
            return this.B(a, a2, d) ? Boolean.TRUE : Boolean.FALSE;
        }
        if (this.D(a)) {
            return this.B((List)a, t.A(a2), d);
        }
        return this.B(t.A(a), (List)a2, d);
    }
    
    private Object B(final List list, final List list2, final E e) {
        if (this.A(list) || this.A(list2)) {
            return Boolean.FALSE;
        }
        final Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            final Object next = iterator.next();
            final Iterator iterator2 = list2.iterator();
            while (iterator2.hasNext()) {
                if (this.B(next, iterator2.next(), e)) {
                    return Boolean.TRUE;
                }
            }
        }
        return Boolean.FALSE;
    }
    
    private boolean B(final Object o, final Object o2, final E e) {
        if (o == null || o2 == null) {
            return false;
        }
        final Double k = _.K(o, e);
        final Double i = _.K(o2, e);
        return !_.A(k) && !_.A(i) && this.A(k, i);
    }
    
    protected abstract boolean A(final Double p0, final Double p1);
}
