// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.D.C;
import org.A.P;
import org.A.S;
import org.A.V;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.io.Serializable;

public class LA implements Serializable
{
    private static final long B = -7166491740228977853L;
    private List A;
    
    public LA() {
        this.A = Collections.EMPTY_LIST;
    }
    
    public void A(final q q) {
        if (this.A == Collections.EMPTY_LIST) {
            this.A = new ArrayList();
        }
        this.A.add(q);
    }
    
    public List B() {
        return this.A;
    }
    
    public void A() {
        final Iterator iterator = this.A.iterator();
        while (iterator.hasNext()) {
            ((q)iterator.next()).A();
        }
    }
    
    public String C() {
        final StringBuffer sb = new StringBuffer();
        final Iterator iterator = this.A.iterator();
        while (iterator.hasNext()) {
            sb.append(((q)iterator.next()).B());
        }
        return sb.toString();
    }
    
    protected boolean B(final List list, final V v) throws S {
        return this.C(list, v);
    }
    
    private boolean C(final List list, final V v) throws S {
        if (this.A.size() == 0) {
            return false;
        }
        final Iterator iterator = this.A.iterator();
        while (iterator.hasNext()) {
            final int size = list.size();
            final P p2 = new P(v);
            final ArrayList list2 = new ArrayList(1);
            p2.A(list2);
            for (int i = 0; i < size; ++i) {
                final Object value = list.get(i);
                list2.clear();
                list2.add(value);
                p2.A(list2);
                p2.B(i + 1);
                p2.A(size);
                final Object a = ((q)iterator.next()).A(p2);
                if (a instanceof Number) {
                    if (((Number)a).intValue() == i + 1) {
                        return true;
                    }
                }
                else if (C.B(a, p2.D())) {
                    return true;
                }
            }
        }
        return false;
    }
    
    protected List A(final List list, final V v) throws S {
        if (this.A.size() == 0) {
            return list;
        }
        final Iterator iterator = this.A.iterator();
        List a = list;
        while (iterator.hasNext()) {
            a = this.A((q)iterator.next(), a, v);
        }
        return a;
    }
    
    public List A(final q q, final List list, final V v) throws S {
        final int size = list.size();
        final ArrayList list2 = new ArrayList(size);
        final P p3 = new P(v);
        final ArrayList list3 = new ArrayList(1);
        p3.A(list3);
        for (int i = 0; i < size; ++i) {
            final Object value = list.get(i);
            list3.clear();
            list3.add(value);
            p3.A(list3);
            p3.B(i + 1);
            p3.A(size);
            final Object a = q.A(p3);
            if (a instanceof Number) {
                if (((Number)a).intValue() == i + 1) {
                    list2.add(value);
                }
            }
            else if (C.B(a, p3.D())) {
                list2.add(value);
            }
        }
        return list2;
    }
}
