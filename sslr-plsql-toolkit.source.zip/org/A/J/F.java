// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import java.util.List;
import org.A.P;
import java.io.Serializable;

public interface F extends Serializable
{
    u C();
    
    void A(final u p0);
    
    String B();
    
    void A();
    
    List A(final P p0) throws S;
}
