// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

public interface QA extends u
{
    String _();
    
    String Z();
}
