// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import org.A.P;

class l extends t implements n
{
    private static final long s = -6593934674727004281L;
    private u r;
    private h q;
    
    l(final u r, final h q) {
        this.r = r;
        this.q = q;
    }
    
    public u c() {
        return this.r;
    }
    
    public void D(final u r) {
        this.r = r;
    }
    
    public h b() {
        return this.q;
    }
    
    public String toString() {
        if (this.b() != null) {
            return "[(DefaultPathExpr): " + this.c() + ", " + this.b() + "]";
        }
        return "[(DefaultPathExpr): " + this.c() + "]";
    }
    
    public String A() {
        final StringBuffer sb = new StringBuffer();
        if (this.c() != null) {
            sb.append(this.c().A());
        }
        if (this.b() != null) {
            if (!this.b().H().isEmpty()) {
                sb.append("/");
            }
            sb.append(this.b().A());
        }
        return sb.toString();
    }
    
    public u B() {
        if (this.c() != null) {
            this.D(this.c().B());
        }
        if (this.b() != null) {
            this.b().B();
        }
        if (this.c() == null && this.b() == null) {
            return null;
        }
        if (this.b() == null) {
            return this.c();
        }
        if (this.c() == null) {
            return this.b();
        }
        return this;
    }
    
    public Object A(final P p) throws S {
        Object a = null;
        P p2 = null;
        if (this.c() != null) {
            a = this.c().A(p);
            p2 = new P(p.C());
            p2.A(t.A(a));
        }
        if (this.b() != null) {
            return this.b().A(p2);
        }
        return a;
    }
}
