// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;

public interface e
{
    F A(final u p0) throws S;
    
    n A(final r p0, final h p1) throws S;
    
    h C() throws S;
    
    h A() throws S;
    
    w A(final u p0, final u p1) throws S;
    
    w C(final u p0, final u p1) throws S;
    
    w A(final u p0, final u p1, final int p2) throws S;
    
    w B(final u p0, final u p1, final int p2) throws S;
    
    w C(final u p0, final u p1, final int p2) throws S;
    
    w D(final u p0, final u p1, final int p2) throws S;
    
    u A(final u p0, final int p1) throws S;
    
    NA B(final u p0, final u p1) throws S;
    
    r C(final u p0) throws S;
    
    E A(final String p0, final String p1) throws S;
    
    Z C(final int p0) throws S;
    
    Z A(final double p0) throws S;
    
    CA A(final String p0) throws S;
    
    QA B(final String p0, final String p1) throws S;
    
    i A(final int p0, final String p1, final String p2) throws S;
    
    i D(final int p0) throws S;
    
    i B(final int p0) throws S;
    
    i A(final int p0) throws S;
    
    i A(final int p0, final String p1) throws S;
    
    q B(final u p0) throws S;
    
    LA B() throws S;
}
