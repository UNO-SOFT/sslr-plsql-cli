// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import org.A.P;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

public class z extends t implements E
{
    private static final long w = -4747789292572193708L;
    private String v;
    private String u;
    private List t;
    
    public z(final String v, final String u) {
        this.v = v;
        this.u = u;
        this.t = new ArrayList();
    }
    
    public void A(final u u) {
        this.t.add(u);
    }
    
    public List D() {
        return this.t;
    }
    
    public String E() {
        return this.v;
    }
    
    public String C() {
        return this.u;
    }
    
    public String A() {
        final StringBuffer sb = new StringBuffer();
        final String e = this.E();
        if (e != null && e.length() > 0) {
            sb.append(e);
            sb.append(":");
        }
        sb.append(this.C());
        sb.append("(");
        final Iterator iterator = this.D().iterator();
        while (iterator.hasNext()) {
            sb.append(((u)iterator.next()).A());
            if (iterator.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(")");
        return sb.toString();
    }
    
    public u B() {
        final List d = this.D();
        final int size = d.size();
        final ArrayList t = new ArrayList(size);
        for (int i = 0; i < size; ++i) {
            t.add((Object)((u)d.get(i)).B());
        }
        this.t = t;
        return this;
    }
    
    public String toString() {
        if (this.E() == null) {
            return "[(DefaultFunctionCallExpr): " + this.C() + "(" + this.D() + ") ]";
        }
        return "[(DefaultFunctionCallExpr): " + this.E() + ":" + this.C() + "(" + this.D() + ") ]";
    }
    
    public Object A(final P p) throws S {
        final String e = this.E();
        String a = null;
        if (e != null && !"".equals(e)) {
            a = p.A(e);
        }
        return p.B(a, e, this.C()).A(p, this.D(p));
    }
    
    public List D(final P p) throws S {
        final List d = this.D();
        final int size = d.size();
        final ArrayList list = new ArrayList(size);
        for (int i = 0; i < size; ++i) {
            list.add(((u)d.get(i)).A(p));
        }
        return list;
    }
}
