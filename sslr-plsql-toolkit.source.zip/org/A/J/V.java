// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

abstract class V extends t implements w
{
    private u Y;
    private u Z;
    
    V(final u y, final u z) {
        this.Y = y;
        this.Z = z;
    }
    
    public u X() {
        return this.Y;
    }
    
    public u Y() {
        return this.Z;
    }
    
    public void C(final u y) {
        this.Y = y;
    }
    
    public void B(final u z) {
        this.Z = z;
    }
    
    public abstract String W();
    
    public String A() {
        return "(" + this.X().A() + " " + this.W() + " " + this.Y().A() + ")";
    }
    
    public String toString() {
        return "[" + this.getClass().getName() + ": " + this.X() + ", " + this.Y() + "]";
    }
    
    public u B() {
        this.C(this.X().B());
        this.B(this.Y().B());
        return this;
    }
}
