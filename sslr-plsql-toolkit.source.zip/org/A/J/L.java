// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import org.A.V;
import java.util.List;
import org.A.E.E;
import java.util.Collections;
import org.A.P;

public class L extends O
{
    private static final long F = 2174836928310146874L;
    
    public String toString() {
        return "[(DefaultAbsoluteLocationPath): " + super.toString() + "]";
    }
    
    public boolean I() {
        return true;
    }
    
    public String A() {
        return "/" + super.A();
    }
    
    public Object A(final P p) throws S {
        final V c = p.C();
        final org.A.E d = c.D();
        final P p2 = new P(c);
        final List f = p.F();
        if (f.isEmpty()) {
            return Collections.EMPTY_LIST;
        }
        final Object documentNode = d.getDocumentNode(f.get(0));
        if (documentNode == null) {
            return Collections.EMPTY_LIST;
        }
        p2.A(new E(documentNode));
        return super.A(p2);
    }
}
