// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J.A;

import org.A.J;
import org.A.X;
import java.util.Iterator;
import org.A.V;

public class E extends K
{
    private static final long E = 1L;
    
    public E(final int n) {
        super(n);
    }
    
    public Iterator A(final Object o, final V v) throws X {
        return v.D().getAttributeAxisIterator(o);
    }
    
    public Iterator A(final Object o, final V v, final String s, final String s2, final String s3) throws X {
        return ((J)v.D()).B(o, s, s2, s3);
    }
    
    public boolean A(final V v) {
        return v.D() instanceof J;
    }
}
