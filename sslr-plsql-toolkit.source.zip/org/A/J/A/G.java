// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J.A;

import org.A.X;
import java.util.Iterator;
import org.A.V;

public class G extends K
{
    private static final long G = 1L;
    
    public G(final int n) {
        super(n);
    }
    
    public Iterator A(final Object o, final V v) throws X {
        return v.D().getAncestorOrSelfAxisIterator(o);
    }
}
