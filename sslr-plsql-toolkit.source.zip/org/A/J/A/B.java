// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J.A;

import org.A.X;
import java.util.Iterator;
import org.A.V;

public class B extends K
{
    private static final long B = 7286715505909806723L;
    
    public B(final int n) {
        super(n);
    }
    
    public Iterator A(final Object o, final V v) throws X {
        return v.D().getDescendantAxisIterator(o);
    }
}
