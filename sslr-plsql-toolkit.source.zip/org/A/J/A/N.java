// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J.A;

import org.A.X;
import java.util.Iterator;
import org.A.V;

public class N extends K
{
    private static final long M = -7100245752300813209L;
    
    public N(final int n) {
        super(n);
    }
    
    public Iterator A(final Object o, final V v) throws X {
        return v.D().getFollowingAxisIterator(o);
    }
}
