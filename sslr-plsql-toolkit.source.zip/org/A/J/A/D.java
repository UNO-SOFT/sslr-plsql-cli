// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J.A;

import org.A.X;
import java.util.Iterator;
import org.A.V;

public class D extends K
{
    private static final long D = -8022585664651357087L;
    
    public D(final int n) {
        super(n);
    }
    
    public Iterator A(final Object o, final V v) throws X {
        return v.D().getNamespaceAxisIterator(o);
    }
}
