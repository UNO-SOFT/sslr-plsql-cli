// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J.A;

import org.A.X;
import java.util.Iterator;
import org.A.V;

public class I extends K
{
    private static final long I = 4412705219546610009L;
    
    public I(final int n) {
        super(n);
    }
    
    public Iterator A(final Object o, final V v) throws X {
        return v.D().getFollowingSiblingAxisIterator(o);
    }
}
