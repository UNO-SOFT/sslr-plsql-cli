// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J.A;

import org.A.X;
import java.util.Iterator;
import org.A.V;
import java.io.Serializable;

public abstract class K implements Serializable
{
    private int A;
    
    public K(final int a) {
        this.A = a;
    }
    
    public int A() {
        return this.A;
    }
    
    public abstract Iterator A(final Object p0, final V p1) throws X;
    
    public Iterator A(final Object o, final V v, final String s, final String s2, final String s3) throws X {
        throw new UnsupportedOperationException("Named access unsupported");
    }
    
    public boolean A(final V v) {
        return false;
    }
}
