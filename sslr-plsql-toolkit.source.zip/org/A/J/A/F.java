// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J.A;

import org.A.J;
import org.A.X;
import java.util.Iterator;
import org.A.V;

public class F extends K
{
    private static final long F = 1L;
    
    public F(final int n) {
        super(n);
    }
    
    public Iterator A(final Object o, final V v) throws X {
        return v.D().getChildAxisIterator(o);
    }
    
    public Iterator A(final Object o, final V v, final String s, final String s2, final String s3) throws X {
        return ((J)v.D()).A(o, s, s2, s3);
    }
    
    public boolean A(final V v) {
        return v.D() instanceof J;
    }
}
