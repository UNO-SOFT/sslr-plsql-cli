// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.P;

class H extends t implements CA
{
    private static final long D = -953829179036273338L;
    private String C;
    
    H(final String c) {
        this.C = c;
    }
    
    public String G() {
        return this.C;
    }
    
    public String toString() {
        return "[(DefaultLiteralExpr): " + this.G() + "]";
    }
    
    public String A() {
        if (this.C.indexOf(34) == -1) {
            return "\"" + this.G() + "\"";
        }
        return "'" + this.G() + "'";
    }
    
    public Object A(final P p) {
        return this.G();
    }
}
