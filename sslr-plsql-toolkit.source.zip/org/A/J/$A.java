// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.V;
import org.A.J.A.K;

public class $A extends g implements S
{
    private static final long X = 4340788283861875606L;
    
    public $A(final K k, final LA la) {
        super(k, la);
    }
    
    public String toString() {
        return "[(DefaultCommentNodeStep): " + this.P() + "]";
    }
    
    public String O() {
        return this.Q() + "::comment()";
    }
    
    public boolean B(final Object o, final V v) {
        return v.D().isComment(o);
    }
}
