// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

public interface n extends u
{
    u c();
    
    void D(final u p0);
    
    h b();
}
