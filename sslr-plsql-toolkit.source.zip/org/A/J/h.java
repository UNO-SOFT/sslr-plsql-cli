// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import java.util.List;

public interface h extends u
{
    void A(final i p0);
    
    List H();
    
    boolean I();
}
