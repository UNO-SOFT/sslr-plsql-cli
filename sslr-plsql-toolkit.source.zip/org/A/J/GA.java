// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import java.util.List;

abstract class GA extends V
{
    GA(final u u, final u u2) {
        super(u, u2);
    }
    
    public String toString() {
        return "[(DefaultTruthExpr): " + this.X() + ", " + this.Y() + "]";
    }
    
    protected boolean A(final Object o, final Object o2) {
        return o instanceof List && o2 instanceof List;
    }
    
    protected boolean E(final Object o, final Object o2) {
        return o instanceof List || o2 instanceof List;
    }
    
    protected boolean D(final Object o) {
        return o instanceof List;
    }
    
    protected boolean C(final Object o) {
        return o instanceof Boolean;
    }
    
    protected boolean A(final List list) {
        return list == null || list.size() == 0;
    }
    
    protected boolean B(final Object o, final Object o2) {
        return o instanceof Boolean || o2 instanceof Boolean;
    }
    
    protected boolean D(final Object o, final Object o2) {
        return o instanceof Boolean && o2 instanceof Boolean;
    }
    
    protected boolean C(final Object o, final Object o2) {
        return o instanceof Number || o2 instanceof Number;
    }
}
