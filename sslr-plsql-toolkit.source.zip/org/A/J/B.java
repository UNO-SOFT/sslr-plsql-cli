// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.D.U;
import org.A.D._;
import org.A.D.C;
import java.util.Iterator;
import org.A.S;
import org.A.E;
import java.util.List;
import org.A.P;

abstract class B extends GA implements T
{
    B(final u u, final u u2) {
        super(u, u2);
    }
    
    public String toString() {
        return "[(DefaultEqualityExpr): " + this.X() + ", " + this.Y() + "]";
    }
    
    public Object A(final P p) throws S {
        final Object a = this.X().A(p);
        final Object a2 = this.Y().A(p);
        if (a == null || a2 == null) {
            return Boolean.FALSE;
        }
        final E d = p.D();
        if (this.A(a, a2)) {
            return this.A((List)a, (List)a2, d);
        }
        if (this.D(a) && this.C(a2)) {
            return this.A(((List)a).isEmpty() ? Boolean.FALSE : Boolean.TRUE, a2, d);
        }
        if (this.C(a) && this.D(a2)) {
            return this.A(a, ((List)a2).isEmpty() ? Boolean.FALSE : Boolean.TRUE, d);
        }
        if (!this.E(a, a2)) {
            return this.A(a, a2, d);
        }
        if (this.D(a)) {
            return this.A((List)a, t.A(a2), d);
        }
        return this.A(t.A(a), (List)a2, d);
    }
    
    private Boolean A(final List list, final List list2, final E e) {
        if (this.A(list) || this.A(list2)) {
            return Boolean.FALSE;
        }
        final Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            final Object next = iterator.next();
            final Iterator iterator2 = list2.iterator();
            while (iterator2.hasNext()) {
                if (this.A(next, iterator2.next(), e)) {
                    return Boolean.TRUE;
                }
            }
        }
        return Boolean.FALSE;
    }
    
    private boolean A(final Object o, final Object o2, final E e) {
        if (this.B(o, o2)) {
            return this.F(C.B(o, e), C.B(o2, e));
        }
        if (this.C(o, o2)) {
            return this.F(_.K(o, e), _.K(o2, e));
        }
        return this.F(U.J(o, e), U.J(o2, e));
    }
    
    protected abstract boolean F(final Object p0, final Object p1);
}
