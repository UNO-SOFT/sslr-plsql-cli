// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.J.A.A;
import org.A.J.A.N;
import org.A.J.A.J;
import org.A.J.A.C;
import org.A.J.A.B;
import org.A.S;

public class M implements e
{
    public F A(final u u) throws S {
        return new HA(u);
    }
    
    public n A(final r r, final h h) throws S {
        return new l(r, h);
    }
    
    public h C() throws S {
        return new x();
    }
    
    public h A() throws S {
        return new L();
    }
    
    public w A(final u u, final u u2) throws S {
        return new o(u, u2);
    }
    
    public w C(final u u, final u u2) throws S {
        return new W(u, u2);
    }
    
    public w A(final u u, final u u2, final int i) throws S {
        switch (i) {
            case 1: {
                return new f(u, u2);
            }
            case 2: {
                return new IA(u, u2);
            }
            default: {
                throw new S("Unhandled operator in createEqualityExpr(): " + i);
            }
        }
    }
    
    public w B(final u u, final u u2, final int i) throws S {
        switch (i) {
            case 3: {
                return new K(u, u2);
            }
            case 5: {
                return new DA(u, u2);
            }
            case 4: {
                return new U(u, u2);
            }
            case 6: {
                return new m(u, u2);
            }
            default: {
                throw new S("Unhandled operator in createRelationalExpr(): " + i);
            }
        }
    }
    
    public w C(final u u, final u u2, final int i) throws S {
        switch (i) {
            case 7: {
                return new G(u, u2);
            }
            case 8: {
                return new s(u, u2);
            }
            default: {
                throw new S("Unhandled operator in createAdditiveExpr(): " + i);
            }
        }
    }
    
    public w D(final u u, final u u2, final int i) throws S {
        switch (i) {
            case 9: {
                return new OA(u, u2);
            }
            case 11: {
                return new FA(u, u2);
            }
            case 10: {
                return new JA(u, u2);
            }
            default: {
                throw new S("Unhandled operator in createMultiplicativeExpr(): " + i);
            }
        }
    }
    
    public u A(final u u, final int n) throws S {
        switch (n) {
            case 12: {
                return new P(u);
            }
            default: {
                return u;
            }
        }
    }
    
    public NA B(final u u, final u u2) throws S {
        return new y(u, u2);
    }
    
    public r C(final u u) throws S {
        return new Q(u, this.B());
    }
    
    public E A(final String s, final String s2) throws S {
        return new z(s, s2);
    }
    
    public Z C(final int n) throws S {
        return new D(new Double(n));
    }
    
    public Z A(final double value) throws S {
        return new D(new Double(value));
    }
    
    public CA A(final String s) throws S {
        return new H(s);
    }
    
    public QA B(final String s, final String s2) throws S {
        return new a(s, s2);
    }
    
    public i A(final int n, final String s, final String s2) throws S {
        return new _(this.E(n), s, s2, this.B());
    }
    
    public i A(final int n) throws S {
        return new R(this.E(n), this.B());
    }
    
    public i B(final int n) throws S {
        return new $A(this.E(n), this.B());
    }
    
    public i D(final int n) throws S {
        return new MA(this.E(n), this.B());
    }
    
    public i A(final int n, final String s) throws S {
        return new I(this.E(n), s, this.B());
    }
    
    public q B(final u u) throws S {
        return new X(u);
    }
    
    protected org.A.J.A.K E(final int i) throws S {
        switch (i) {
            case 1: {
                return new org.A.J.A.F(i);
            }
            case 2: {
                return new B(i);
            }
            case 3: {
                return new C(i);
            }
            case 5: {
                return new org.A.J.A.I(i);
            }
            case 6: {
                return new J(i);
            }
            case 7: {
                return new N(i);
            }
            case 8: {
                return new A(i);
            }
            case 9: {
                return new org.A.J.A.E(i);
            }
            case 10: {
                return new org.A.J.A.D(i);
            }
            case 11: {
                return new org.A.J.A.M(i);
            }
            case 12: {
                return new org.A.J.A.H(i);
            }
            case 13: {
                return new org.A.J.A.G(i);
            }
            case 4: {
                return new org.A.J.A.L(i);
            }
            default: {
                throw new S("Unrecognized axis code: " + i);
            }
        }
    }
    
    public LA B() throws S {
        return new LA();
    }
}
