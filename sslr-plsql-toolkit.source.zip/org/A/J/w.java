// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

public interface w extends u
{
    u X();
    
    u Y();
    
    String W();
}
