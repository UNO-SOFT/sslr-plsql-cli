// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import org.A.P;

public interface r extends u, EA
{
    boolean B(final P p0) throws S;
    
    u M();
}
