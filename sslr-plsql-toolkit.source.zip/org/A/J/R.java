// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.V;
import org.A.J.A.K;

public class R extends g implements k
{
    private static final long Q = -3821960984972022948L;
    
    public R(final K k, final LA la) {
        super(k, la);
    }
    
    public boolean B(final Object o, final V v) {
        return v.D().isText(o);
    }
    
    public String O() {
        return this.Q() + "::text()" + super.O();
    }
}
