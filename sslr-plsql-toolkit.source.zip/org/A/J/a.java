// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.U;
import org.A.P;

class a extends t implements QA
{
    private static final long p = 8832095437149358674L;
    private String o;
    private String n;
    
    a(final String o, final String n) {
        this.o = o;
        this.n = n;
    }
    
    public String _() {
        return this.o;
    }
    
    public String Z() {
        return this.n;
    }
    
    public String toString() {
        return "[(DefaultVariableReferenceExpr): " + this.a() + "]";
    }
    
    private String a() {
        if ("".equals(this.o)) {
            return this.n;
        }
        return this.o + ":" + this.n;
    }
    
    public String A() {
        return "$" + this.a();
    }
    
    public Object A(final P p) throws U {
        final String _ = this._();
        String a = null;
        if (_ != null && !"".equals(_)) {
            a = p.A(_);
        }
        return p.A(a, _, this.n);
    }
}
