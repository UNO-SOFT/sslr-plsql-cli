// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.P;

class D extends t implements Z
{
    private static final long B = -6021898973386269611L;
    private Double A;
    
    D(final Double a) {
        this.A = a;
    }
    
    public Number F() {
        return this.A;
    }
    
    public String toString() {
        return "[(DefaultNumberExpr): " + this.F() + "]";
    }
    
    public String A() {
        return this.F().toString();
    }
    
    public Object A(final P p) {
        return this.F();
    }
}
