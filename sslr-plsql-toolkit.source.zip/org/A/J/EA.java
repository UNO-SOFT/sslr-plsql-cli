// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import java.util.List;
import java.io.Serializable;

public interface EA extends Serializable
{
    void A(final q p0);
    
    List K();
    
    LA L();
}
