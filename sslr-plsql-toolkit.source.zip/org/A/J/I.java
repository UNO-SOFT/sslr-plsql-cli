// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.E;
import org.A.V;
import org.A.J.A.K;

public class I extends g implements Y
{
    private static final long P = -4825000697808126927L;
    private String O;
    
    public I(final K k, final String o, final LA la) {
        super(k, la);
        this.O = o;
    }
    
    public String S() {
        return this.O;
    }
    
    public String O() {
        final StringBuffer sb = new StringBuffer();
        sb.append(this.Q());
        sb.append("::processing-instruction(");
        final String s = this.S();
        if (s != null && s.length() != 0) {
            sb.append("'");
            sb.append(s);
            sb.append("'");
        }
        sb.append(")");
        sb.append(super.O());
        return sb.toString();
    }
    
    public boolean B(final Object o, final V v) {
        final E d = v.D();
        if (d.isProcessingInstruction(o)) {
            final String s = this.S();
            return s == null || s.length() == 0 || s.equals(d.getProcessingInstructionTarget(o));
        }
        return false;
    }
}
