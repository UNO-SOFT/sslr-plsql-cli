// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import org.A.P;
import java.io.Serializable;

public interface u extends Serializable
{
    String A();
    
    u B();
    
    Object A(final P p0) throws S;
}
