// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

public class x extends O
{
    private static final long G = -1006862529366150615L;
    
    public String toString() {
        return "[(DefaultRelativeLocationPath): " + super.toString() + "]";
    }
}
