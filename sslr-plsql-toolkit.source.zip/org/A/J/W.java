// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import org.A.E;
import org.A.P;

class W extends C
{
    private static final long h = -5237984010263103742L;
    
    W(final u u, final u u2) {
        super(u, u2);
    }
    
    public String W() {
        return "and";
    }
    
    public String toString() {
        return "[(DefaultAndExpr): " + this.X() + ", " + this.Y() + "]";
    }
    
    public Object A(final P p) throws S {
        final E d = p.D();
        if (!org.A.D.C.B(this.X().A(p), d)) {
            return Boolean.FALSE;
        }
        if (!org.A.D.C.B(this.Y().A(p), d)) {
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }
}
