// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import java.util.Iterator;
import org.A.B;
import java.util.Comparator;
import java.util.Collections;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;
import org.A.P;

public class y extends V implements NA
{
    private static final long _ = 7629142718276852707L;
    
    public y(final u u, final u u2) {
        super(u, u2);
    }
    
    public String W() {
        return "|";
    }
    
    public String toString() {
        return "[(DefaultUnionExpr): " + this.X() + ", " + this.Y() + "]";
    }
    
    public Object A(final P p) throws S {
        final ArrayList list = new ArrayList();
        try {
            final List list2 = (List)this.X().A(p);
            final List list3 = (List)this.Y().A(p);
            final HashSet set = new HashSet();
            list.addAll(list2);
            set.addAll(list2);
            final Iterator iterator = list3.iterator();
            while (iterator.hasNext()) {
                final Object next = iterator.next();
                if (!set.contains(next)) {
                    list.add(next);
                    set.add(next);
                }
            }
            Collections.sort((List<Object>)list, new j(p.D()));
            return list;
        }
        catch (final ClassCastException ex) {
            throw new B(this.A(), p.A(), "Unions are only allowed over node-sets");
        }
    }
}
