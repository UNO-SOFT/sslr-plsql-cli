// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import org.A.S;
import org.A.P;
import java.io.Serializable;

public interface q extends Serializable
{
    u C();
    
    void A(final u p0);
    
    void A();
    
    String B();
    
    Object A(final P p0) throws S;
}
