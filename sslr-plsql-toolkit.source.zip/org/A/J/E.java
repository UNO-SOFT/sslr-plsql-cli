// 
// Decompiled by Procyon v0.6.0
// 

package org.A.J;

import java.util.List;

public interface E extends u
{
    String E();
    
    String C();
    
    void A(final u p0);
    
    List D();
}
