// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import java.util.List;

public interface D
{
    Object B(final Object p0) throws S;
    
    String F(final Object p0) throws S;
    
    String E(final Object p0) throws S;
    
    boolean G(final Object p0) throws S;
    
    Number D(final Object p0) throws S;
    
    List C(final Object p0) throws S;
    
    Object A(final Object p0) throws S;
    
    void A(final String p0, final String p1) throws S;
    
    void A(final O p0);
    
    void A(final C p0);
    
    void A(final T p0);
    
    O B();
    
    C C();
    
    T A();
    
    E D();
}
