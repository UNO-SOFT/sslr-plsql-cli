// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import org.A.D.Y;
import org.A.D.B;
import org.A.D.R;
import org.A.D.X;
import org.A.D.K;
import org.A.D.G;
import org.A.D.U;
import org.A.D.V;
import org.A.D.W;
import org.A.D._;
import org.A.D.E;
import org.A.D.S;
import org.A.D.Z;
import org.A.D.O;
import org.A.D.J;
import org.A.D.M;
import org.A.D.P;
import org.A.D.T;
import org.A.D.D;
import org.A.D.I;
import org.A.D.L;
import org.A.D.A;
import org.A.D.F;

public class Q extends N
{
    private static Q B;
    
    public static C A() {
        return Q.B;
    }
    
    public Q() {
        this(true);
    }
    
    public Q(final boolean b) {
        this.C();
        if (b) {
            this.D();
            this.B();
        }
    }
    
    private void C() {
        this.A(null, "boolean", new org.A.D.C());
        this.A(null, "ceiling", new F());
        this.A(null, "concat", new A());
        this.A(null, "contains", new L());
        this.A(null, "count", new I());
        this.A(null, "false", new D());
        this.A(null, "floor", new T());
        this.A(null, "id", new org.A.D.Q());
        this.A(null, "lang", new P());
        this.A(null, "last", new M());
        this.A(null, "local-name", new J());
        this.A(null, "name", new O());
        this.A(null, "namespace-uri", new Z());
        this.A(null, "normalize-space", new S());
        this.A(null, "not", new E());
        this.A(null, "number", new _());
        this.A(null, "position", new W());
        this.A(null, "round", new org.A.D.H());
        this.A(null, "starts-with", new V());
        this.A(null, "string", new U());
        this.A(null, "string-length", new G());
        this.A(null, "substring-after", new org.A.D.N());
        this.A(null, "substring-before", new K());
        this.A(null, "substring", new X());
        this.A(null, "sum", new R());
        this.A(null, "true", new B());
        this.A(null, "translate", new Y());
    }
    
    private void D() {
        this.A(null, "document", new org.A.D.A.A());
    }
    
    private void B() {
        this.A(null, "evaluate", new org.A.D.B.E());
        this.A(null, "lower-case", new org.A.D.B.D());
        this.A(null, "upper-case", new org.A.D.B.B());
        this.A(null, "ends-with", new org.A.D.B.C());
    }
    
    static {
        Q.B = new Q();
    }
}
