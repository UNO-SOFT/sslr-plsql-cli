// 
// Decompiled by Procyon v0.6.0
// 

package org.A.B;

import org.dom4j.DocumentException;
import org.A.K;
import org.A.D;
import java.util.Collection;
import java.util.HashSet;
import java.util.ArrayList;
import org.dom4j.Node;
import org.A.E.F;
import org.dom4j.QName;
import org.A.M;
import org.dom4j.Branch;
import java.util.Iterator;
import org.dom4j.Namespace;
import org.dom4j.Document;
import org.dom4j.ProcessingInstruction;
import org.dom4j.Attribute;
import org.dom4j.CDATA;
import org.dom4j.Text;
import org.dom4j.Comment;
import org.dom4j.Element;
import org.A.E;
import org.dom4j.io.SAXReader;
import org.A.J;
import org.A.L;

public class A extends L implements J
{
    private static final long C = 5582300797286535936L;
    private transient SAXReader B;
    
    public static E A() {
        return _A.A;
    }
    
    public boolean isElement(final Object o) {
        return o instanceof Element;
    }
    
    public boolean isComment(final Object o) {
        return o instanceof Comment;
    }
    
    public boolean isText(final Object o) {
        return o instanceof Text || o instanceof CDATA;
    }
    
    public boolean isAttribute(final Object o) {
        return o instanceof Attribute;
    }
    
    public boolean isProcessingInstruction(final Object o) {
        return o instanceof ProcessingInstruction;
    }
    
    public boolean isDocument(final Object o) {
        return o instanceof Document;
    }
    
    public boolean isNamespace(final Object o) {
        return o instanceof Namespace;
    }
    
    public String getElementName(final Object o) {
        return ((Element)o).getName();
    }
    
    public String getElementNamespaceUri(final Object o) {
        final String namespaceURI = ((Element)o).getNamespaceURI();
        if (namespaceURI == null) {
            return "";
        }
        return namespaceURI;
    }
    
    public String getElementQName(final Object o) {
        return ((Element)o).getQualifiedName();
    }
    
    public String getAttributeName(final Object o) {
        return ((Attribute)o).getName();
    }
    
    public String getAttributeNamespaceUri(final Object o) {
        final String namespaceURI = ((Attribute)o).getNamespaceURI();
        if (namespaceURI == null) {
            return "";
        }
        return namespaceURI;
    }
    
    public String getAttributeQName(final Object o) {
        return ((Attribute)o).getQualifiedName();
    }
    
    public Iterator getChildAxisIterator(final Object o) {
        Iterator nodeIterator = null;
        if (o instanceof Branch) {
            nodeIterator = ((Branch)o).nodeIterator();
        }
        if (nodeIterator != null) {
            return nodeIterator;
        }
        return M.B;
    }
    
    public Iterator A(final Object o, final String anObject, final String s, final String s2) {
        if (o instanceof Element) {
            return ((Element)o).elementIterator(QName.get(anObject, s, s2));
        }
        if (!(o instanceof Document)) {
            return M.B;
        }
        final Element rootElement = ((Document)o).getRootElement();
        if (rootElement == null || !rootElement.getName().equals(anObject)) {
            return M.B;
        }
        if (s2 != null && !s2.equals(rootElement.getNamespaceURI())) {
            return M.B;
        }
        return new F(rootElement);
    }
    
    public Iterator getParentAxisIterator(final Object o) {
        if (o instanceof Document) {
            return M.B;
        }
        final Node node = (Node)o;
        Object o2 = node.getParent();
        if (o2 == null) {
            o2 = node.getDocument();
        }
        return new F(o2);
    }
    
    public Iterator getAttributeAxisIterator(final Object o) {
        if (!(o instanceof Element)) {
            return M.B;
        }
        return ((Element)o).attributeIterator();
    }
    
    public Iterator B(final Object o, final String s, final String s2, final String s3) {
        if (!(o instanceof Element)) {
            return M.B;
        }
        final Attribute attribute = ((Element)o).attribute(QName.get(s, s2, s3));
        if (attribute == null) {
            return M.B;
        }
        return new F(attribute);
    }
    
    public Iterator getNamespaceAxisIterator(final Object o) {
        if (!(o instanceof Element)) {
            return M.B;
        }
        final Element element = (Element)o;
        final ArrayList list = new ArrayList();
        final HashSet set = new HashSet();
        for (Element parent = element; parent != null; parent = parent.getParent()) {
            final ArrayList list2 = new ArrayList(parent.declaredNamespaces());
            list2.add((Object)parent.getNamespace());
            final Iterator iterator = parent.attributes().iterator();
            while (iterator.hasNext()) {
                list2.add((Object)((Attribute)iterator.next()).getNamespace());
            }
            final Iterator iterator2 = list2.iterator();
            while (iterator2.hasNext()) {
                final Namespace namespace = (Namespace)iterator2.next();
                if (namespace != Namespace.NO_NAMESPACE) {
                    final String prefix = namespace.getPrefix();
                    if (set.contains(prefix)) {
                        continue;
                    }
                    set.add(prefix);
                    list.add(namespace.asXPathResult(element));
                }
            }
        }
        list.add(Namespace.XML_NAMESPACE.asXPathResult(element));
        return list.iterator();
    }
    
    public Object getDocumentNode(final Object o) {
        if (o instanceof Document) {
            return o;
        }
        if (o instanceof Node) {
            return ((Node)o).getDocument();
        }
        return null;
    }
    
    public D parseXPath(final String s) throws org.A.F.D {
        return new B(s);
    }
    
    public Object getParentNode(final Object o) {
        if (o instanceof Node) {
            final Node node = (Node)o;
            Object o2 = node.getParent();
            if (o2 == null) {
                o2 = node.getDocument();
                if (o2 == o) {
                    return null;
                }
            }
            return o2;
        }
        return null;
    }
    
    public String getTextStringValue(final Object o) {
        return this.A((Node)o);
    }
    
    public String getElementStringValue(final Object o) {
        return this.A((Node)o);
    }
    
    public String getAttributeStringValue(final Object o) {
        return this.A((Node)o);
    }
    
    private String A(final Node node) {
        return node.getStringValue();
    }
    
    public String getNamespaceStringValue(final Object o) {
        return ((Namespace)o).getURI();
    }
    
    public String getNamespacePrefix(final Object o) {
        return ((Namespace)o).getPrefix();
    }
    
    public String getCommentStringValue(final Object o) {
        return ((Comment)o).getText();
    }
    
    public String translateNamespacePrefixToUri(final String s, final Object o) {
        Element parent = null;
        if (o instanceof Element) {
            parent = (Element)o;
        }
        else if (o instanceof Node) {
            parent = ((Node)o).getParent();
        }
        if (parent != null) {
            final Namespace namespaceForPrefix = parent.getNamespaceForPrefix(s);
            if (namespaceForPrefix != null) {
                return namespaceForPrefix.getURI();
            }
        }
        return null;
    }
    
    public short getNodeType(final Object o) {
        if (o instanceof Node) {
            return ((Node)o).getNodeType();
        }
        return 0;
    }
    
    public Object getDocument(final String str) throws K {
        try {
            return this.B().read(str);
        }
        catch (final DocumentException ex) {
            throw new K("Failed to parse document for URI: " + str, (Exception)ex);
        }
    }
    
    public String getProcessingInstructionTarget(final Object o) {
        return ((ProcessingInstruction)o).getTarget();
    }
    
    public String getProcessingInstructionData(final Object o) {
        return ((ProcessingInstruction)o).getText();
    }
    
    public SAXReader B() {
        if (this.B == null) {
            (this.B = new SAXReader()).setMergeAdjacentText(true);
        }
        return this.B;
    }
    
    public void A(final SAXReader b) {
        this.B = b;
    }
    
    private static class _A
    {
        private static A A;
        
        static {
            _A.A = new A();
        }
    }
}
