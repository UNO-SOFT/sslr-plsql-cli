// 
// Decompiled by Procyon v0.6.0
// 

package org.A.B;

import org.A.S;
import org.A.F;

public class B extends F
{
    private static final long F = -75510941087659775L;
    
    public B(final String s) throws S {
        super(s, org.A.B.A.A());
    }
}
