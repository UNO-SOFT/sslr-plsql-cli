// 
// Decompiled by Procyon v0.6.0
// 

package org.A.F;

public interface A extends E
{
    void A(final String p0) throws D;
}
