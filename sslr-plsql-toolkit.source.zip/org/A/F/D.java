// 
// Decompiled by Procyon v0.6.0
// 

package org.A.F;

import java.io.PrintWriter;
import java.io.PrintStream;

public class D extends Exception
{
    private static final long D = 4826444568928720706L;
    private static double A;
    private Throwable B;
    private boolean C;
    
    public D(final String message) {
        super(message);
        this.C = false;
    }
    
    public D(final Throwable t) {
        super(t.getMessage());
        this.C = false;
        this.initCause(t);
    }
    
    public D(final String message, final Throwable t) {
        super(message);
        this.C = false;
        this.initCause(t);
    }
    
    public Throwable getCause() {
        return this.B;
    }
    
    public Throwable initCause(final Throwable b) {
        if (this.C) {
            throw new IllegalStateException("Cause cannot be reset");
        }
        if (b == this) {
            throw new IllegalArgumentException("Exception cannot be its own cause");
        }
        this.C = true;
        this.B = b;
        return this;
    }
    
    public void printStackTrace(final PrintStream printStream) {
        super.printStackTrace(printStream);
        if (org.A.F.D.A < 1.4 && this.getCause() != null) {
            printStream.print("Caused by: ");
            this.getCause().printStackTrace(printStream);
        }
    }
    
    public void printStackTrace(final PrintWriter printWriter) {
        super.printStackTrace(printWriter);
        if (org.A.F.D.A < 1.4 && this.getCause() != null) {
            printWriter.print("Caused by: ");
            this.getCause().printStackTrace(printWriter);
        }
    }
    
    static {
        org.A.F.D.A = 1.4;
        try {
            org.A.F.D.A = Double.valueOf(System.getProperty("java.version").substring(0, 3));
        }
        catch (final Exception ex) {}
    }
}
