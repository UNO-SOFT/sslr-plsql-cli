// 
// Decompiled by Procyon v0.6.0
// 

package org.A.F;

public class F extends D
{
    private static final long H = 3567675610742422397L;
    private String G;
    private int F;
    private static final String E;
    
    public F(final String g, final int f, final String s) {
        super(s);
        this.F = f;
        this.G = g;
    }
    
    public int D() {
        return this.F;
    }
    
    public String B() {
        return this.G;
    }
    
    public String toString() {
        return this.getClass() + ": " + this.B() + ": " + this.D() + ": " + this.getMessage();
    }
    
    private String C() {
        final int d = this.D();
        final StringBuffer sb = new StringBuffer(d + 1);
        for (int i = 0; i < d; ++i) {
            sb.append(" ");
        }
        sb.append("^");
        return sb.toString();
    }
    
    public String A() {
        final StringBuffer sb = new StringBuffer();
        sb.append(this.getMessage());
        sb.append(org.A.F.F.E);
        sb.append(this.B());
        sb.append(org.A.F.F.E);
        sb.append(this.C());
        return sb.toString();
    }
    
    static {
        E = System.getProperty("line.separator");
    }
}
