// 
// Decompiled by Procyon v0.6.0
// 

package org.A.F.B;

class E
{
    private int C;
    private String B;
    private int A;
    private int D;
    
    E(final int n, final String s, final int n2, final int n3) {
        this.B(n);
        this.A(s);
        this.C(n2);
        this.A(n3);
    }
    
    private void B(final int c) {
        this.C = c;
    }
    
    int D() {
        return this.C;
    }
    
    private void A(final String b) {
        this.B = b;
    }
    
    String B() {
        return this.B.substring(this.A(), this.C());
    }
    
    private void C(final int a) {
        this.A = a;
    }
    
    int A() {
        return this.A;
    }
    
    private void A(final int d) {
        this.D = d;
    }
    
    int C() {
        return this.D;
    }
    
    public String toString() {
        return "[ (" + this.C + ") (" + this.B() + ")";
    }
}
