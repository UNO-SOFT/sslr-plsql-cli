// 
// Decompiled by Procyon v0.6.0
// 

package org.A.F.B;

class C
{
    static final int S = -1;
    static final int g = -2;
    static final int M = -3;
    static final int Q = 1;
    static final int Y = 2;
    static final int K = 3;
    static final int H = 4;
    static final int a = 5;
    static final int _ = 6;
    static final int D = 7;
    static final int V = 8;
    static final int I = 9;
    static final int A = 10;
    static final int U = 11;
    static final int J = 12;
    static final int T = 13;
    static final int X = 14;
    static final int c = 15;
    static final int L = 16;
    static final int N = 17;
    static final int C = 18;
    static final int P = 19;
    static final int Z = 20;
    static final int W = 21;
    static final int f = 22;
    static final int F = 23;
    static final int b = 24;
    static final int G = 25;
    static final int O = 26;
    static final int B = 27;
    static final int E = 28;
    static final int e = 29;
    static final int R = 30;
    static final int d = 31;
    
    static String A(final int i) {
        switch (i) {
            case -3: {
                return "(error)";
            }
            case -2: {
                return "(skip)";
            }
            case -1: {
                return "(eof)";
            }
            case 0: {
                return "Unrecognized token type: 0";
            }
            case 1: {
                return "=";
            }
            case 2: {
                return "!=";
            }
            case 3: {
                return "<";
            }
            case 4: {
                return "<=";
            }
            case 5: {
                return ">";
            }
            case 6: {
                return ">=";
            }
            case 7: {
                return "+";
            }
            case 8: {
                return "-";
            }
            case 9: {
                return "*";
            }
            case 31: {
                return "*";
            }
            case 11: {
                return "div";
            }
            case 10: {
                return "mod";
            }
            case 12: {
                return "/";
            }
            case 13: {
                return "//";
            }
            case 14: {
                return ".";
            }
            case 15: {
                return "..";
            }
            case 16: {
                return "(identifier)";
            }
            case 17: {
                return "@";
            }
            case 18: {
                return "|";
            }
            case 19: {
                return ":";
            }
            case 20: {
                return "::";
            }
            case 21: {
                return "[";
            }
            case 22: {
                return "]";
            }
            case 23: {
                return "(";
            }
            case 24: {
                return ")";
            }
            case 25: {
                return "$";
            }
            case 26: {
                return "(literal)";
            }
            case 27: {
                return "and";
            }
            case 28: {
                return "or";
            }
            case 29: {
                return "(double)";
            }
            case 30: {
                return ",";
            }
            default: {
                return "Unrecognized token type: " + i;
            }
        }
    }
}
