// 
// Decompiled by Procyon v0.6.0
// 

package org.A.F.B;

import org.A.F.F;
import org.A.F.G;
import java.util.ArrayList;
import org.A.F.A;

public class B implements A
{
    private ArrayList D;
    private D C;
    private G B;
    private static G A;
    
    public B() {
        this.A(org.A.F.B.B.A);
    }
    
    public void A(final G b) {
        this.B = b;
    }
    
    public G A() {
        return this.B;
    }
    
    public void A(final String s) throws org.A.F.D {
        this.B(s);
        this.A().S();
        this.K();
        this.A().T();
        if (this.A(1) != -1) {
            throw this.D("Unexpected '" + this.C(1).B() + "'");
        }
        this.C = null;
        this.D = null;
    }
    
    void B(final String s) {
        this.D = new ArrayList();
        this.C = new D(s);
    }
    
    private void Y() throws org.A.F.D {
        this.A().L();
        switch (this.A(1)) {
            case 26:
            case 29: {
                this.O();
                if (this.A(1) == 12 || this.A(1) == 13) {
                    throw this.D("Node-set expected");
                }
                break;
            }
            case 23:
            case 25: {
                this.O();
                if (this.A(1) == 12 || this.A(1) == 13) {
                    this.A(false);
                    break;
                }
                break;
            }
            case 16: {
                if ((this.A(2) != 23 || this.A(this.C(1))) && (this.A(2) != 19 || this.A(4) != 23)) {
                    this.A(false);
                    break;
                }
                this.O();
                if (this.A(1) == 12 || this.A(1) == 13) {
                    this.A(false);
                    break;
                }
                break;
            }
            case 9:
            case 14:
            case 15:
            case 17: {
                this.A(false);
                break;
            }
            case 12:
            case 13: {
                this.A(true);
                break;
            }
            default: {
                throw this.D("Unexpected '" + this.C(1).B() + "'");
            }
        }
        this.A().M();
    }
    
    private void I() throws org.A.F.D {
        this.A().A(this.D(26).B());
    }
    
    private void Q() throws org.A.F.D {
        String b;
        if (this.A(2) == 19) {
            b = this.D(16).B();
            this.D(19);
        }
        else {
            b = "";
        }
        this.A().A(b, this.D(16).B());
        this.D(23);
        this.J();
        this.D(24);
        this.A().I();
    }
    
    private void J() throws org.A.F.D {
        while (this.A(1) != 24) {
            this.K();
            if (this.A(1) != 30) {
                break;
            }
            this.D(30);
        }
    }
    
    private void O() throws org.A.F.D {
        this.A().J();
        switch (this.A(1)) {
            case 29: {
                this.A().A(Double.parseDouble(this.D(29).B()));
                break;
            }
            case 26: {
                this.I();
                break;
            }
            case 23: {
                this.D(23);
                this.K();
                this.D(24);
                break;
            }
            case 16: {
                this.Q();
                break;
            }
            case 25: {
                this.G();
                break;
            }
        }
        this.D();
        this.A().H();
    }
    
    private void G() throws org.A.F.D {
        this.D(25);
        String b;
        if (this.A(2) == 19) {
            b = this.D(16).B();
            this.D(19);
        }
        else {
            b = "";
        }
        this.A().B(b, this.D(16).B());
    }
    
    void A(final boolean b) throws org.A.F.D {
        switch (this.A(1)) {
            case 12:
            case 13: {
                if (b) {
                    this.V();
                    break;
                }
                this.U();
                break;
            }
            case 9:
            case 14:
            case 15:
            case 16:
            case 17: {
                this.U();
                break;
            }
            default: {
                throw this.D("Unexpected '" + this.C(1).B() + "'");
            }
        }
    }
    
    private void V() throws org.A.F.D {
        this.A().Q();
        Label_0208: {
            switch (this.A(1)) {
                case 12: {
                    this.D(12);
                    switch (this.A(1)) {
                        case 9:
                        case 14:
                        case 15:
                        case 16:
                        case 17: {
                            this.E();
                            break;
                        }
                    }
                    break;
                }
                case 13: {
                    this.A().E(12);
                    this.A().Y();
                    this.D(13);
                    switch (this.A(1)) {
                        case 9:
                        case 14:
                        case 15:
                        case 16:
                        case 17: {
                            this.E();
                            break Label_0208;
                        }
                        default: {
                            throw this.D("Location path cannot end with //");
                        }
                    }
                    break;
                }
            }
        }
        this.A().F();
    }
    
    private void U() throws org.A.F.D {
        this.A().N();
        switch (this.A(1)) {
            case 12: {
                this.D(12);
                break;
            }
            case 13: {
                this.A().E(12);
                this.A().Y();
                this.D(13);
                break;
            }
        }
        this.E();
        this.A().D();
    }
    
    private void E() throws org.A.F.D {
        switch (this.A(1)) {
            case 9:
            case 14:
            case 15:
            case 16:
            case 17: {
                this.N();
                while (this.A(1) == 12 || this.A(1) == 13) {
                    switch (this.A(1)) {
                        case 12: {
                            this.D(12);
                            break;
                        }
                        case 13: {
                            this.A().E(12);
                            this.A().Y();
                            this.D(13);
                            break;
                        }
                    }
                    switch (this.A(1)) {
                        case 9:
                        case 14:
                        case 15:
                        case 16:
                        case 17: {
                            this.N();
                            continue;
                        }
                        default: {
                            throw this.D("Expected one of '.', '..', '@', '*', <QName>");
                        }
                    }
                }
                return;
            }
            case -1: {
                return;
            }
            default: {
                throw this.D("Expected one of '.', '..', '@', '*', <QName>");
            }
        }
    }
    
    void N() throws org.A.F.D {
        int n = 0;
        switch (this.A(1)) {
            case 14:
            case 15: {
                this.W();
                return;
            }
            case 17: {
                n = this.P();
                break;
            }
            case 16: {
                if (this.A(2) == 20) {
                    n = this.P();
                    break;
                }
                n = 1;
                break;
            }
            case 9: {
                n = 1;
                break;
            }
        }
        this.E(n);
    }
    
    private int P() throws org.A.F.D {
        int a = 0;
        switch (this.A(1)) {
            case 17: {
                this.D(17);
                a = 9;
                break;
            }
            case 16: {
                final org.A.F.B.E c = this.C(1);
                a = org.A.F.B.A(c.B());
                if (a == 0) {
                    this.C(c.B());
                }
                this.D(16);
                this.D(20);
                break;
            }
        }
        return a;
    }
    
    private void E(final int n) throws org.A.F.D {
        Label_0089: {
            switch (this.A(1)) {
                case 16: {
                    switch (this.A(2)) {
                        case 23: {
                            this.F(n);
                            break Label_0089;
                        }
                        default: {
                            this.B(n);
                            break Label_0089;
                        }
                    }
                    break;
                }
                case 9: {
                    this.B(n);
                    break;
                }
                default: {
                    throw this.D("Expected <QName> or *");
                }
            }
        }
    }
    
    private void F(final int n) throws org.A.F.D {
        final String b = this.D(16).B();
        this.D(23);
        if ("processing-instruction".equals(b)) {
            String b2 = "";
            if (this.A(1) == 26) {
                b2 = this.D(26).B();
            }
            this.D(24);
            this.A().A(n, b2);
            this.D();
            this.A().V();
        }
        else if ("node".equals(b)) {
            this.D(24);
            this.A().E(n);
            this.D();
            this.A().Y();
        }
        else if ("text".equals(b)) {
            this.D(24);
            this.A().C(n);
            this.D();
            this.A().W();
        }
        else {
            if (!"comment".equals(b)) {
                throw this.D("Expected node-type");
            }
            this.D(24);
            this.A().B(n);
            this.D();
            this.A().R();
        }
    }
    
    private void B(final int n) throws org.A.F.D {
        String b = null;
        String b2 = null;
        Label_0069: {
            switch (this.A(2)) {
                case 19: {
                    switch (this.A(1)) {
                        case 16: {
                            b = this.D(16).B();
                            this.D(19);
                            break Label_0069;
                        }
                    }
                    break;
                }
            }
        }
        switch (this.A(1)) {
            case 16: {
                b2 = this.D(16).B();
                break;
            }
            case 9: {
                this.D(9);
                b2 = "*";
                break;
            }
        }
        if (b == null) {
            b = "";
        }
        this.A().A(n, b, b2);
        this.D();
        this.A().P();
    }
    
    private void W() throws org.A.F.D {
        switch (this.A(1)) {
            case 14: {
                this.D(14);
                this.A().E(11);
                this.D();
                this.A().Y();
                break;
            }
            case 15: {
                this.D(15);
                this.A().E(3);
                this.D();
                this.A().Y();
                break;
            }
        }
    }
    
    private void D() throws org.A.F.D {
        while (this.A(1) == 21) {
            this.B();
        }
    }
    
    void B() throws org.A.F.D {
        this.A().O();
        this.D(21);
        this.S();
        this.D(22);
        this.A().X();
    }
    
    private void S() throws org.A.F.D {
        this.K();
    }
    
    private void K() throws org.A.F.D {
        this.L();
    }
    
    private void L() throws org.A.F.D {
        this.A().C();
        this.H();
        boolean b = false;
        switch (this.A(1)) {
            case 28: {
                b = true;
                this.D(28);
                this.L();
                break;
            }
        }
        this.A().B(b);
    }
    
    private void H() throws org.A.F.D {
        this.A().K();
        this.R();
        boolean b = false;
        switch (this.A(1)) {
            case 27: {
                b = true;
                this.D(27);
                this.H();
                break;
            }
        }
        this.A().A(b);
    }
    
    private void R() throws org.A.F.D {
        this.C();
        for (int n = this.A(1); n == 1 || n == 2; n = this.A(1)) {
            switch (n) {
                case 1: {
                    this.D(1);
                    this.A().A();
                    this.C();
                    this.A().G(1);
                    break;
                }
                case 2: {
                    this.D(2);
                    this.A().A();
                    this.C();
                    this.A().G(2);
                    break;
                }
            }
        }
    }
    
    private void C() throws org.A.F.D {
        this.X();
        for (int n = this.A(1); n == 3 || n == 5 || n == 4 || n == 6; n = this.A(1)) {
            switch (n) {
                case 3: {
                    this.D(3);
                    this.A().Z();
                    this.X();
                    this.A().I(3);
                    break;
                }
                case 5: {
                    this.D(5);
                    this.A().Z();
                    this.X();
                    this.A().I(5);
                    break;
                }
                case 6: {
                    this.D(6);
                    this.A().Z();
                    this.X();
                    this.A().I(6);
                    break;
                }
                case 4: {
                    this.D(4);
                    this.A().Z();
                    this.X();
                    this.A().I(4);
                    break;
                }
            }
        }
    }
    
    private void X() throws org.A.F.D {
        this.T();
        for (int n = this.A(1); n == 7 || n == 8; n = this.A(1)) {
            switch (n) {
                case 7: {
                    this.D(7);
                    this.A().E();
                    this.T();
                    this.A().D(7);
                    break;
                }
                case 8: {
                    this.D(8);
                    this.A().E();
                    this.T();
                    this.A().D(8);
                    break;
                }
            }
        }
    }
    
    private void T() throws org.A.F.D {
        this.M();
        for (int n = this.A(1); n == 31 || n == 11 || n == 10; n = this.A(1)) {
            switch (n) {
                case 9:
                case 31: {
                    this.D(31);
                    this.A().G();
                    this.M();
                    this.A().H(9);
                    break;
                }
                case 11: {
                    this.D(11);
                    this.A().G();
                    this.M();
                    this.A().H(11);
                    break;
                }
                case 10: {
                    this.D(10);
                    this.A().G();
                    this.M();
                    this.A().H(10);
                    break;
                }
            }
        }
    }
    
    private void M() throws org.A.F.D {
        switch (this.A(1)) {
            case 8: {
                this.A().B();
                this.D(8);
                this.M();
                this.A().F(12);
                break;
            }
            default: {
                this.F();
                break;
            }
        }
    }
    
    private void F() throws org.A.F.D {
        this.A().U();
        this.Y();
        boolean b = false;
        switch (this.A(1)) {
            case 18: {
                this.D(18);
                b = true;
                this.K();
                break;
            }
        }
        this.A().C(b);
    }
    
    private org.A.F.B.E D(final int n) throws F {
        this.C(1);
        final org.A.F.B.E e = this.D.get(0);
        if (e.D() == n) {
            this.D.remove(0);
            return e;
        }
        throw this.D("Expected: " + org.A.F.B.C.A(n));
    }
    
    private int A(final int n) {
        return this.C(n).D();
    }
    
    private org.A.F.B.E C(final int n) {
        if (this.D.size() <= n - 1) {
            for (int i = 0; i < n; ++i) {
                this.D.add(this.C.W());
            }
        }
        return this.D.get(n - 1);
    }
    
    private boolean A(final org.A.F.B.E e) {
        final String b = e.B();
        return "node".equals(b) || "comment".equals(b) || "text".equals(b) || "processing-instruction".equals(b);
    }
    
    private F D(final String s) {
        return new F(this.C.G(), this.C(1).A(), s);
    }
    
    private void C(final String str) throws org.A.F.D {
        throw new F(this.C.G(), this.C(1).A(), "Expected valid axis name instead of [" + str + "]");
    }
    
    static {
        B.A = new org.A.F.A.B();
    }
}
