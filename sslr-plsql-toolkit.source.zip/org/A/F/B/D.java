// 
// Decompiled by Procyon v0.6.0
// 

package org.A.F.B;

class D
{
    private String B;
    private int D;
    private int C;
    private boolean A;
    
    D(final String s) {
        this.A = false;
        this.A(s);
    }
    
    private void A(final String b) {
        this.B = b;
        this.D = 0;
        this.C = b.length();
    }
    
    String G() {
        return this.B;
    }
    
    E W() {
        E e;
        do {
            e = null;
            Label_0760: {
                switch (this.A(1)) {
                    case '$': {
                        e = this.O();
                        break;
                    }
                    case '\"':
                    case '\'': {
                        e = this.J();
                        break;
                    }
                    case '/': {
                        e = this.A();
                        break;
                    }
                    case ',': {
                        e = this.R();
                        break;
                    }
                    case '(': {
                        e = this.V();
                        break;
                    }
                    case ')': {
                        e = this.B();
                        break;
                    }
                    case '[': {
                        e = this.X();
                        break;
                    }
                    case ']': {
                        e = this.Y();
                        break;
                    }
                    case '+': {
                        e = this.D();
                        break;
                    }
                    case '-': {
                        e = this.N();
                        break;
                    }
                    case '<':
                    case '>': {
                        e = this.c();
                        break;
                    }
                    case '=': {
                        e = this.L();
                        break;
                    }
                    case '!': {
                        if (this.A(2) == '=') {
                            e = this.F();
                            break;
                        }
                        break;
                    }
                    case '|': {
                        e = this.I();
                        break;
                    }
                    case '@': {
                        e = this.Q();
                        break;
                    }
                    case ':': {
                        if (this.A(2) == ':') {
                            e = this.P();
                            break;
                        }
                        e = this.U();
                        break;
                    }
                    case '*': {
                        e = this.T();
                        break;
                    }
                    case '.': {
                        switch (this.A(2)) {
                            case '0':
                            case '1':
                            case '2':
                            case '3':
                            case '4':
                            case '5':
                            case '6':
                            case '7':
                            case '8':
                            case '9': {
                                e = this.C();
                                break Label_0760;
                            }
                            default: {
                                e = this.S();
                                break Label_0760;
                            }
                        }
                        break;
                    }
                    case '0':
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9': {
                        e = this.C();
                        break;
                    }
                    case '\t':
                    case '\n':
                    case '\r':
                    case ' ': {
                        e = this.d();
                        break;
                    }
                    default: {
                        if (org.A.F.B.A.C(this.A(1))) {
                            e = this.M();
                            break;
                        }
                        break;
                    }
                }
            }
            if (e == null) {
                if (!this.H()) {
                    e = new E(-1, this.G(), this.D, this.C);
                }
                else {
                    e = new E(-3, this.G(), this.D, this.C);
                }
            }
        } while (e.D() == -2);
        switch (e.D()) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 10:
            case 11:
            case 12:
            case 13:
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:
            case 23:
            case 25:
            case 27:
            case 28:
            case 30:
            case 31: {
                this.A = false;
                break;
            }
            default: {
                this.A = true;
                break;
            }
        }
        return e;
    }
    
    private E M() {
        E e;
        if (this.A) {
            e = this.K();
        }
        else {
            e = this.a();
        }
        return e;
    }
    
    private E a() {
        final int d = this.D;
        while (this.H() && org.A.F.B.A.D(this.A(1))) {
            this._();
        }
        return new E(16, this.G(), d, this.D);
    }
    
    private E K() {
        E e = null;
        switch (this.A(1)) {
            case 'a': {
                e = this.E();
                break;
            }
            case 'o': {
                e = this.b();
                break;
            }
            case 'm': {
                e = this.Z();
                break;
            }
            case 'd': {
                e = this.e();
                break;
            }
        }
        return e;
    }
    
    private E Z() {
        E e = null;
        if (this.A(1) == 'm' && this.A(2) == 'o' && this.A(3) == 'd') {
            e = new E(10, this.G(), this.D, this.D + 3);
            this._();
            this._();
            this._();
        }
        return e;
    }
    
    private E e() {
        E e = null;
        if (this.A(1) == 'd' && this.A(2) == 'i' && this.A(3) == 'v') {
            e = new E(11, this.G(), this.D, this.D + 3);
            this._();
            this._();
            this._();
        }
        return e;
    }
    
    private E E() {
        E e = null;
        if (this.A(1) == 'a' && this.A(2) == 'n' && this.A(3) == 'd') {
            e = new E(27, this.G(), this.D, this.D + 3);
            this._();
            this._();
            this._();
        }
        return e;
    }
    
    private E b() {
        E e = null;
        if (this.A(1) == 'o' && this.A(2) == 'r') {
            e = new E(28, this.G(), this.D, this.D + 2);
            this._();
            this._();
        }
        return e;
    }
    
    private E C() {
        final int d = this.D;
        int n = 1;
    Label_0099:
        while (true) {
            switch (this.A(1)) {
                case '.': {
                    if (n != 0) {
                        n = 0;
                        this._();
                        continue;
                    }
                    break Label_0099;
                }
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9': {
                    this._();
                    continue;
                }
                default: {
                    break Label_0099;
                }
            }
        }
        return new E(29, this.G(), d, this.D);
    }
    
    private E d() {
        this._();
    Label_0070:
        while (this.H()) {
            switch (this.A(1)) {
                case '\t':
                case '\n':
                case '\r':
                case ' ': {
                    this._();
                    continue;
                }
                default: {
                    break Label_0070;
                }
            }
        }
        return new E(-2, this.G(), 0, 0);
    }
    
    private E R() {
        final E e = new E(30, this.G(), this.D, this.D + 1);
        this._();
        return e;
    }
    
    private E L() {
        final E e = new E(1, this.G(), this.D, this.D + 1);
        this._();
        return e;
    }
    
    private E N() {
        final E e = new E(8, this.G(), this.D, this.D + 1);
        this._();
        return e;
    }
    
    private E D() {
        final E e = new E(7, this.G(), this.D, this.D + 1);
        this._();
        return e;
    }
    
    private E O() {
        final E e = new E(25, this.G(), this.D, this.D + 1);
        this._();
        return e;
    }
    
    private E I() {
        final E e = new E(18, this.G(), this.D, this.D + 1);
        this._();
        return e;
    }
    
    private E Q() {
        final E e = new E(17, this.G(), this.D, this.D + 1);
        this._();
        return e;
    }
    
    private E U() {
        final E e = new E(19, this.G(), this.D, this.D + 1);
        this._();
        return e;
    }
    
    private E P() {
        final E e = new E(20, this.G(), this.D, this.D + 2);
        this._();
        this._();
        return e;
    }
    
    private E F() {
        final E e = new E(2, this.G(), this.D, this.D + 2);
        this._();
        this._();
        return e;
    }
    
    private E c() {
        E e = null;
        switch (this.A(1)) {
            case '<': {
                if (this.A(2) == '=') {
                    e = new E(4, this.G(), this.D, this.D + 2);
                    this._();
                }
                else {
                    e = new E(3, this.G(), this.D, this.D + 1);
                }
                this._();
                break;
            }
            case '>': {
                if (this.A(2) == '=') {
                    e = new E(6, this.G(), this.D, this.D + 2);
                    this._();
                }
                else {
                    e = new E(5, this.G(), this.D, this.D + 1);
                }
                this._();
                break;
            }
        }
        return e;
    }
    
    private E T() {
        final E e = new E(this.A ? 31 : 9, this.G(), this.D, this.D + 1);
        this._();
        return e;
    }
    
    private E J() {
        E e = null;
        final char a = this.A(1);
        this._();
        final int d = this.D;
        while (e == null && this.H()) {
            if (this.A(1) == a) {
                e = new E(26, this.G(), d, this.D);
            }
            this._();
        }
        return e;
    }
    
    private E S() {
        E e = null;
        switch (this.A(2)) {
            case '.': {
                e = new E(15, this.G(), this.D, this.D + 2);
                this._();
                this._();
                break;
            }
            default: {
                e = new E(14, this.G(), this.D, this.D + 1);
                this._();
                break;
            }
        }
        return e;
    }
    
    private E X() {
        final E e = new E(21, this.G(), this.D, this.D + 1);
        this._();
        return e;
    }
    
    private E Y() {
        final E e = new E(22, this.G(), this.D, this.D + 1);
        this._();
        return e;
    }
    
    private E V() {
        final E e = new E(23, this.G(), this.D, this.D + 1);
        this._();
        return e;
    }
    
    private E B() {
        final E e = new E(24, this.G(), this.D, this.D + 1);
        this._();
        return e;
    }
    
    private E A() {
        E e = null;
        switch (this.A(2)) {
            case '/': {
                e = new E(13, this.G(), this.D, this.D + 2);
                this._();
                this._();
                break;
            }
            default: {
                e = new E(12, this.G(), this.D, this.D + 1);
                this._();
                break;
            }
        }
        return e;
    }
    
    private char A(final int n) {
        if (this.D + (n - 1) >= this.C) {
            return '\uffff';
        }
        return this.G().charAt(this.D + (n - 1));
    }
    
    private void _() {
        ++this.D;
    }
    
    private boolean H() {
        return this.D < this.C;
    }
}
