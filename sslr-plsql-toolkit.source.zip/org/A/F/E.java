// 
// Decompiled by Procyon v0.6.0
// 

package org.A.F;

public interface E
{
    void A(final G p0);
    
    G A();
}
