// 
// Decompiled by Procyon v0.6.0
// 

package org.A.F;

public interface G
{
    void S() throws D;
    
    void T() throws D;
    
    void L() throws D;
    
    void M() throws D;
    
    void Q() throws D;
    
    void F() throws D;
    
    void N() throws D;
    
    void D() throws D;
    
    void A(final int p0, final String p1, final String p2) throws D;
    
    void P() throws D;
    
    void C(final int p0) throws D;
    
    void W() throws D;
    
    void B(final int p0) throws D;
    
    void R() throws D;
    
    void E(final int p0) throws D;
    
    void Y() throws D;
    
    void A(final int p0, final String p1) throws D;
    
    void V() throws D;
    
    void O() throws D;
    
    void X() throws D;
    
    void J() throws D;
    
    void H() throws D;
    
    void C() throws D;
    
    void B(final boolean p0) throws D;
    
    void K() throws D;
    
    void A(final boolean p0) throws D;
    
    void A() throws D;
    
    void G(final int p0) throws D;
    
    void Z() throws D;
    
    void I(final int p0) throws D;
    
    void E() throws D;
    
    void D(final int p0) throws D;
    
    void G() throws D;
    
    void H(final int p0) throws D;
    
    void B() throws D;
    
    void F(final int p0) throws D;
    
    void U() throws D;
    
    void C(final boolean p0) throws D;
    
    void A(final int p0) throws D;
    
    void A(final double p0) throws D;
    
    void A(final String p0) throws D;
    
    void B(final String p0, final String p1) throws D;
    
    void A(final String p0, final String p1) throws D;
    
    void I() throws D;
}
