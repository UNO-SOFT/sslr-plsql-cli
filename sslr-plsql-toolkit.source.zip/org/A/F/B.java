// 
// Decompiled by Procyon v0.6.0
// 

package org.A.F;

import org.A.A;

public class B
{
    public static final int D = 0;
    public static final int M = 1;
    public static final int B = 2;
    public static final int J = 3;
    public static final int G = 4;
    public static final int K = 5;
    public static final int N = 6;
    public static final int H = 7;
    public static final int I = 8;
    public static final int E = 9;
    public static final int F = 10;
    public static final int L = 11;
    public static final int C = 12;
    public static final int A = 13;
    
    private B() {
    }
    
    public static String A(final int n) {
        switch (n) {
            case 1: {
                return "child";
            }
            case 2: {
                return "descendant";
            }
            case 3: {
                return "parent";
            }
            case 4: {
                return "ancestor";
            }
            case 5: {
                return "following-sibling";
            }
            case 6: {
                return "preceding-sibling";
            }
            case 7: {
                return "following";
            }
            case 8: {
                return "preceding";
            }
            case 9: {
                return "attribute";
            }
            case 10: {
                return "namespace";
            }
            case 11: {
                return "self";
            }
            case 12: {
                return "descendant-or-self";
            }
            case 13: {
                return "ancestor-or-self";
            }
            default: {
                throw new A("Illegal Axis Number");
            }
        }
    }
    
    public static int A(final String anObject) {
        if ("child".equals(anObject)) {
            return 1;
        }
        if ("descendant".equals(anObject)) {
            return 2;
        }
        if ("parent".equals(anObject)) {
            return 3;
        }
        if ("ancestor".equals(anObject)) {
            return 4;
        }
        if ("following-sibling".equals(anObject)) {
            return 5;
        }
        if ("preceding-sibling".equals(anObject)) {
            return 6;
        }
        if ("following".equals(anObject)) {
            return 7;
        }
        if ("preceding".equals(anObject)) {
            return 8;
        }
        if ("attribute".equals(anObject)) {
            return 9;
        }
        if ("namespace".equals(anObject)) {
            return 10;
        }
        if ("self".equals(anObject)) {
            return 11;
        }
        if ("descendant-or-self".equals(anObject)) {
            return 12;
        }
        if ("ancestor-or-self".equals(anObject)) {
            return 13;
        }
        return 0;
    }
}
