// 
// Decompiled by Procyon v0.6.0
// 

package org.A.F.A;

import org.A.F.D;

public class A
{
    public static final String A = "org.saxpath.driver";
    protected static final String B = "org.A.F.B.B";
    
    private A() {
    }
    
    public static org.A.F.A A() throws D {
        String property = null;
        try {
            property = System.getProperty("org.saxpath.driver");
        }
        catch (final SecurityException ex) {}
        if (property == null || property.length() == 0) {
            property = "org.A.F.B.B";
        }
        return A(property);
    }
    
    public static org.A.F.A A(final String s) throws D {
        Class<?> forName;
        try {
            forName = Class.forName(s, true, A.class.getClassLoader());
            if (!org.A.F.A.class.isAssignableFrom(forName)) {
                throw new D("Class [" + s + "] does not implement the org.jaxen.saxpath.XPathReader interface.");
            }
        }
        catch (final ClassNotFoundException ex) {
            throw new D(ex);
        }
        org.A.F.A a;
        try {
            a = (org.A.F.A)forName.newInstance();
        }
        catch (final IllegalAccessException ex2) {
            throw new D(ex2);
        }
        catch (final InstantiationException ex3) {
            throw new D(ex3);
        }
        return a;
    }
}
