// 
// Decompiled by Procyon v0.6.0
// 

package org.A.F.A;

import org.A.F.D;
import org.A.F.G;

public class B implements G
{
    public void S() throws D {
    }
    
    public void T() throws D {
    }
    
    public void L() throws D {
    }
    
    public void M() throws D {
    }
    
    public void Q() throws D {
    }
    
    public void F() throws D {
    }
    
    public void N() throws D {
    }
    
    public void D() throws D {
    }
    
    public void A(final int n, final String s, final String s2) throws D {
    }
    
    public void P() throws D {
    }
    
    public void C(final int n) throws D {
    }
    
    public void W() throws D {
    }
    
    public void B(final int n) throws D {
    }
    
    public void R() throws D {
    }
    
    public void E(final int n) throws D {
    }
    
    public void Y() throws D {
    }
    
    public void A(final int n, final String s) throws D {
    }
    
    public void V() throws D {
    }
    
    public void O() throws D {
    }
    
    public void X() throws D {
    }
    
    public void J() throws D {
    }
    
    public void H() throws D {
    }
    
    public void C() throws D {
    }
    
    public void B(final boolean b) throws D {
    }
    
    public void K() throws D {
    }
    
    public void A(final boolean b) throws D {
    }
    
    public void A() throws D {
    }
    
    public void G(final int n) throws D {
    }
    
    public void Z() throws D {
    }
    
    public void I(final int n) throws D {
    }
    
    public void E() throws D {
    }
    
    public void D(final int n) throws D {
    }
    
    public void G() throws D {
    }
    
    public void H(final int n) throws D {
    }
    
    public void B() throws D {
    }
    
    public void F(final int n) throws D {
    }
    
    public void U() throws D {
    }
    
    public void C(final boolean b) throws D {
    }
    
    public void A(final int n) throws D {
    }
    
    public void A(final double n) throws D {
    }
    
    public void A(final String s) throws D {
    }
    
    public void B(final String s, final String s2) throws D {
    }
    
    public void A(final String s, final String s2) throws D {
    }
    
    public void I() throws D {
    }
}
