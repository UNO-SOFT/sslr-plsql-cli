// 
// Decompiled by Procyon v0.6.0
// 

package org.A.F;

public interface C
{
    public static final int C = 0;
    public static final int K = 1;
    public static final int G = 2;
    public static final int D = 3;
    public static final int J = 4;
    public static final int I = 5;
    public static final int M = 6;
    public static final int F = 7;
    public static final int L = 8;
    public static final int A = 9;
    public static final int B = 10;
    public static final int H = 11;
    public static final int E = 12;
}
