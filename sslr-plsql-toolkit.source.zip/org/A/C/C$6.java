// 
// Decompiled by Procyon v0.6.0
// 

package org.A.C;

import org.w3c.dom.Node;

class C$6 extends _A {
    protected Node C(final Node node) {
        if (node == null) {
            return null;
        }
        final Node nextSibling = node.getNextSibling();
        if (nextSibling == null) {
            return this.C(node.getParentNode());
        }
        return nextSibling;
    }
    
    protected Node B(final Node node) {
        if (node == null) {
            return null;
        }
        Node node2 = node.getFirstChild();
        if (node2 == null) {
            node2 = node.getNextSibling();
        }
        if (node2 == null) {
            return this.C(node.getParentNode());
        }
        return node2;
    }
}