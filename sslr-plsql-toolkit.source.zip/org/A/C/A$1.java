// 
// Decompiled by Procyon v0.6.0
// 

package org.A.C;

static class A$1 {}