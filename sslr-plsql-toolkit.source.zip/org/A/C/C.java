// 
// Decompiled by Procyon v0.6.0
// 

package org.A.C;

import java.util.NoSuchElementException;
import org.w3c.dom.Document;
import org.w3c.dom.ProcessingInstruction;
import java.io.IOException;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import org.A.K;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.NodeList;
import org.A.D;
import org.w3c.dom.NamedNodeMap;
import java.util.HashMap;
import org.w3c.dom.Attr;
import org.A.M;
import org.w3c.dom.Node;
import java.util.Iterator;
import org.A.E;
import org.A.L;

public class C extends L
{
    private static final long E = 8460943068889528115L;
    private static final C D;
    
    public static E C() {
        return C.D;
    }
    
    public Iterator getChildAxisIterator(final Object o) {
        final Node node = (Node)o;
        if (node.getNodeType() == 1 || node.getNodeType() == 9) {
            return new _A((Node)o) {
                protected Node C(final Node node) {
                    return node.getFirstChild();
                }
                
                protected Node B(final Node node) {
                    return node.getNextSibling();
                }
            };
        }
        return M.B;
    }
    
    public Iterator getParentAxisIterator(final Object o) {
        final Node node = (Node)o;
        if (node.getNodeType() == 2) {
            return new _A(node) {
                protected Node C(final Node node) {
                    return ((Attr)node).getOwnerElement();
                }
                
                protected Node B(final Node node) {
                    return null;
                }
            };
        }
        return new _A(node) {
            protected Node C(final Node node) {
                return node.getParentNode();
            }
            
            protected Node B(final Node node) {
                return null;
            }
        };
    }
    
    public Object getParentNode(final Object o) {
        final Node node = (Node)o;
        if (node.getNodeType() == 2) {
            return ((Attr)node).getOwnerElement();
        }
        return node.getParentNode();
    }
    
    public Iterator getFollowingSiblingAxisIterator(final Object o) {
        return new _A((Node)o) {
            protected Node C(final Node node) {
                return this.B(node);
            }
            
            protected Node B(final Node node) {
                return node.getNextSibling();
            }
        };
    }
    
    public Iterator getPrecedingSiblingAxisIterator(final Object o) {
        return new _A((Node)o) {
            protected Node C(final Node node) {
                return this.B(node);
            }
            
            protected Node B(final Node node) {
                return node.getPreviousSibling();
            }
        };
    }
    
    public Iterator getFollowingAxisIterator(final Object o) {
        return new _A((Node)o) {
            protected Node C(final Node node) {
                if (node == null) {
                    return null;
                }
                final Node nextSibling = node.getNextSibling();
                if (nextSibling == null) {
                    return this.C(node.getParentNode());
                }
                return nextSibling;
            }
            
            protected Node B(final Node node) {
                if (node == null) {
                    return null;
                }
                Node node2 = node.getFirstChild();
                if (node2 == null) {
                    node2 = node.getNextSibling();
                }
                if (node2 == null) {
                    return this.C(node.getParentNode());
                }
                return node2;
            }
        };
    }
    
    public Iterator getAttributeAxisIterator(final Object o) {
        if (this.isElement(o)) {
            return new _B((Node)o);
        }
        return M.B;
    }
    
    public Iterator getNamespaceAxisIterator(final Object o) {
        if (this.isElement(o)) {
            final HashMap hashMap = new HashMap();
            for (Node parentNode = (Node)o; parentNode != null; parentNode = parentNode.getParentNode()) {
                final String namespaceURI = parentNode.getNamespaceURI();
                if (namespaceURI != null && !"".equals(namespaceURI)) {
                    final String prefix = parentNode.getPrefix();
                    if (!hashMap.containsKey(prefix)) {
                        hashMap.put(prefix, new A((Node)o, prefix, namespaceURI));
                    }
                }
                if (parentNode.hasAttributes()) {
                    final NamedNodeMap attributes = parentNode.getAttributes();
                    final int length = attributes.getLength();
                    for (int i = 0; i < length; ++i) {
                        final Attr attr = (Attr)attributes.item(i);
                        final String namespaceURI2 = attr.getNamespaceURI();
                        if (!"http://www.w3.org/2000/xmlns/".equals(namespaceURI2)) {
                            if (namespaceURI2 != null) {
                                final String prefix2 = attr.getPrefix();
                                final A value = new A((Node)o, prefix2, namespaceURI2);
                                if (!hashMap.containsKey(prefix2)) {
                                    hashMap.put(prefix2, value);
                                }
                            }
                        }
                    }
                    for (int j = 0; j < length; ++j) {
                        final Attr attr2 = (Attr)attributes.item(j);
                        if ("http://www.w3.org/2000/xmlns/".equals(attr2.getNamespaceURI())) {
                            final A value2 = new A((Node)o, attr2);
                            final String nodeName = value2.getNodeName();
                            if (!hashMap.containsKey(nodeName)) {
                                hashMap.put(nodeName, value2);
                            }
                        }
                    }
                }
            }
            hashMap.put("xml", new A((Node)o, "xml", "http://www.w3.org/XML/1998/namespace"));
            final A a = hashMap.get("");
            if (a != null && a.getNodeValue().length() == 0) {
                hashMap.remove("");
            }
            return hashMap.values().iterator();
        }
        return M.B;
    }
    
    public D parseXPath(final String s) throws org.A.F.D {
        return new B(s);
    }
    
    public Object getDocumentNode(final Object o) {
        if (this.isDocument(o)) {
            return o;
        }
        return ((Node)o).getOwnerDocument();
    }
    
    public String getElementNamespaceUri(final Object o) {
        try {
            final Node node = (Node)o;
            if (node.getNodeType() == 1) {
                return node.getNamespaceURI();
            }
        }
        catch (final ClassCastException ex) {}
        return null;
    }
    
    public String getElementName(final Object o) {
        if (this.isElement(o)) {
            String s = ((Node)o).getLocalName();
            if (s == null) {
                s = ((Node)o).getNodeName();
            }
            return s;
        }
        return null;
    }
    
    public String getElementQName(final Object o) {
        try {
            final Node node = (Node)o;
            if (node.getNodeType() == 1) {
                return node.getNodeName();
            }
        }
        catch (final ClassCastException ex) {}
        return null;
    }
    
    public String getAttributeNamespaceUri(final Object o) {
        try {
            final Node node = (Node)o;
            if (node.getNodeType() == 2) {
                return node.getNamespaceURI();
            }
        }
        catch (final ClassCastException ex) {}
        return null;
    }
    
    public String getAttributeName(final Object o) {
        if (this.isAttribute(o)) {
            String s = ((Node)o).getLocalName();
            if (s == null) {
                s = ((Node)o).getNodeName();
            }
            return s;
        }
        return null;
    }
    
    public String getAttributeQName(final Object o) {
        try {
            final Node node = (Node)o;
            if (node.getNodeType() == 2) {
                return node.getNodeName();
            }
        }
        catch (final ClassCastException ex) {}
        return null;
    }
    
    public boolean isDocument(final Object o) {
        return o instanceof Node && ((Node)o).getNodeType() == 9;
    }
    
    public boolean isNamespace(final Object o) {
        return o instanceof A;
    }
    
    public boolean isElement(final Object o) {
        return o instanceof Node && ((Node)o).getNodeType() == 1;
    }
    
    public boolean isAttribute(final Object o) {
        return o instanceof Node && ((Node)o).getNodeType() == 2 && !"http://www.w3.org/2000/xmlns/".equals(((Node)o).getNamespaceURI());
    }
    
    public boolean isComment(final Object o) {
        return o instanceof Node && ((Node)o).getNodeType() == 8;
    }
    
    public boolean isText(final Object o) {
        if (!(o instanceof Node)) {
            return false;
        }
        switch (((Node)o).getNodeType()) {
            case 3:
            case 4: {
                return true;
            }
            default: {
                return false;
            }
        }
    }
    
    public boolean isProcessingInstruction(final Object o) {
        return o instanceof Node && ((Node)o).getNodeType() == 7;
    }
    
    public String getElementStringValue(final Object o) {
        if (this.isElement(o)) {
            return this.A((Node)o, new StringBuffer()).toString();
        }
        return null;
    }
    
    private StringBuffer A(final Node node, final StringBuffer sb) {
        if (this.isText(node)) {
            sb.append(node.getNodeValue());
        }
        else {
            final NodeList childNodes = node.getChildNodes();
            for (int length = childNodes.getLength(), i = 0; i < length; ++i) {
                this.A(childNodes.item(i), sb);
            }
        }
        return sb;
    }
    
    public String getAttributeStringValue(final Object o) {
        if (this.isAttribute(o)) {
            return ((Node)o).getNodeValue();
        }
        return null;
    }
    
    public String getTextStringValue(final Object o) {
        if (this.isText(o)) {
            return ((Node)o).getNodeValue();
        }
        return null;
    }
    
    public String getCommentStringValue(final Object o) {
        if (this.isComment(o)) {
            return ((Node)o).getNodeValue();
        }
        return null;
    }
    
    public String getNamespaceStringValue(final Object o) {
        if (this.isNamespace(o)) {
            return ((A)o).getNodeValue();
        }
        return null;
    }
    
    public String getNamespacePrefix(final Object o) {
        if (this.isNamespace(o)) {
            return ((A)o).getLocalName();
        }
        return null;
    }
    
    public String translateNamespacePrefixToUri(final String s, final Object o) {
        final Iterator namespaceAxisIterator = this.getNamespaceAxisIterator(o);
        while (namespaceAxisIterator.hasNext()) {
            final A a = namespaceAxisIterator.next();
            if (s.equals(a.getNodeName())) {
                return a.getNodeValue();
            }
        }
        return null;
    }
    
    public Object getDocument(final String uri) throws K {
        try {
            final DocumentBuilderFactory instance = DocumentBuilderFactory.newInstance();
            instance.setNamespaceAware(true);
            return instance.newDocumentBuilder().parse(uri);
        }
        catch (final ParserConfigurationException ex) {
            throw new K("JAXP setup error in document() function: " + ex.getMessage(), ex);
        }
        catch (final SAXException ex2) {
            throw new K("XML error in document() function: " + ex2.getMessage(), ex2);
        }
        catch (final IOException ex3) {
            throw new K("I/O error in document() function: " + ex3.getMessage(), ex3);
        }
    }
    
    public String getProcessingInstructionTarget(final Object obj) {
        if (this.isProcessingInstruction(obj)) {
            return ((ProcessingInstruction)obj).getTarget();
        }
        throw new ClassCastException(obj + " is not a processing instruction");
    }
    
    public String getProcessingInstructionData(final Object obj) {
        if (this.isProcessingInstruction(obj)) {
            return ((ProcessingInstruction)obj).getData();
        }
        throw new ClassCastException(obj + " is not a processing instruction");
    }
    
    public Object getElementById(final Object o, final String s) {
        final Document document = (Document)this.getDocumentNode(o);
        if (document != null) {
            return document.getElementById(s);
        }
        return null;
    }
    
    static {
        D = new C();
    }
    
    private static class _B implements Iterator
    {
        private NamedNodeMap B;
        private int C;
        private int A;
        
        _B(final Node node) {
            this.A = -1;
            this.B = node.getAttributes();
            this.C = 0;
            for (int i = this.B.getLength() - 1; i >= 0; --i) {
                if (!"http://www.w3.org/2000/xmlns/".equals(this.B.item(i).getNamespaceURI())) {
                    this.A = i;
                    break;
                }
            }
        }
        
        public boolean hasNext() {
            return this.C <= this.A;
        }
        
        public Object next() {
            final Node item = this.B.item(this.C++);
            if (item == null) {
                throw new NoSuchElementException();
            }
            if ("http://www.w3.org/2000/xmlns/".equals(item.getNamespaceURI())) {
                return this.next();
            }
            return item;
        }
        
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
    
    abstract class _A implements Iterator
    {
        private Node A;
        
        public _A(final Node node) {
            this.A = this.C(node);
            while (!this.A(this.A)) {
                this.A = this.B(this.A);
            }
        }
        
        public boolean hasNext() {
            return this.A != null;
        }
        
        public Object next() {
            if (this.A == null) {
                throw new NoSuchElementException();
            }
            final Node a = this.A;
            this.A = this.B(this.A);
            while (!this.A(this.A)) {
                this.A = this.B(this.A);
            }
            return a;
        }
        
        public void remove() {
            throw new UnsupportedOperationException();
        }
        
        protected abstract Node C(final Node p0);
        
        protected abstract Node B(final Node p0);
        
        private boolean A(final Node node) {
            if (node == null) {
                return true;
            }
            switch (node.getNodeType()) {
                case 5:
                case 6:
                case 10:
                case 11:
                case 12: {
                    return false;
                }
                default: {
                    return true;
                }
            }
        }
    }
}
