// 
// Decompiled by Procyon v0.6.0
// 

package org.A.C;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

private static class _A implements NodeList
{
    public int getLength() {
        return 0;
    }
    
    public Node item(final int n) {
        return null;
    }
}
