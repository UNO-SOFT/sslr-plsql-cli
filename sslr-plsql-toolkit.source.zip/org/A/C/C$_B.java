// 
// Decompiled by Procyon v0.6.0
// 

package org.A.C;

import java.util.NoSuchElementException;
import org.w3c.dom.Node;
import org.w3c.dom.NamedNodeMap;
import java.util.Iterator;

private static class _B implements Iterator
{
    private NamedNodeMap B;
    private int C;
    private int A;
    
    _B(final Node node) {
        this.A = -1;
        this.B = node.getAttributes();
        this.C = 0;
        for (int i = this.B.getLength() - 1; i >= 0; --i) {
            if (!"http://www.w3.org/2000/xmlns/".equals(this.B.item(i).getNamespaceURI())) {
                this.A = i;
                break;
            }
        }
    }
    
    public boolean hasNext() {
        return this.C <= this.A;
    }
    
    public Object next() {
        final Node item = this.B.item(this.C++);
        if (item == null) {
            throw new NoSuchElementException();
        }
        if ("http://www.w3.org/2000/xmlns/".equals(item.getNamespaceURI())) {
            return this.next();
        }
        return item;
    }
    
    public void remove() {
        throw new UnsupportedOperationException();
    }
}
