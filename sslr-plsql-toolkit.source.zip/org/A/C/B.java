// 
// Decompiled by Procyon v0.6.0
// 

package org.A.C;

import org.A.S;
import org.A.F;

public class B extends F
{
    private static final long G = 5551221776001439091L;
    
    public B(final String s) throws S {
        super(s, org.A.C.C.C());
    }
}
