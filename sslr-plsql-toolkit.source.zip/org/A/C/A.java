// 
// Decompiled by Procyon v0.6.0
// 

package org.A.C;

import java.lang.reflect.InvocationTargetException;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.w3c.dom.DOMException;
import java.util.HashMap;
import org.w3c.dom.Node;

public class A implements Node
{
    public static final short B = 13;
    private Node D;
    private String C;
    private String E;
    private HashMap A;
    
    public A(final Node d, final String s, final String e) {
        this.A = new HashMap();
        this.D = d;
        this.C = ((s == null) ? "" : s);
        this.E = e;
    }
    
    A(final Node d, final Node node) {
        this.A = new HashMap();
        final String nodeName = node.getNodeName();
        if (nodeName.equals("xmlns")) {
            this.C = "";
        }
        else if (nodeName.startsWith("xmlns:")) {
            this.C = nodeName.substring(6);
        }
        else {
            this.C = nodeName;
        }
        this.D = d;
        this.E = node.getNodeValue();
    }
    
    public String getNodeName() {
        return this.C;
    }
    
    public String getNodeValue() {
        return this.E;
    }
    
    public void setNodeValue(final String s) throws DOMException {
        this.A();
    }
    
    public short getNodeType() {
        return 13;
    }
    
    public Node getParentNode() {
        return this.D;
    }
    
    public NodeList getChildNodes() {
        return new _A();
    }
    
    public Node getFirstChild() {
        return null;
    }
    
    public Node getLastChild() {
        return null;
    }
    
    public Node getPreviousSibling() {
        return null;
    }
    
    public Node getNextSibling() {
        return null;
    }
    
    public NamedNodeMap getAttributes() {
        return null;
    }
    
    public Document getOwnerDocument() {
        if (this.D == null) {
            return null;
        }
        return this.D.getOwnerDocument();
    }
    
    public Node insertBefore(final Node node, final Node node2) throws DOMException {
        this.A();
        return null;
    }
    
    public Node replaceChild(final Node node, final Node node2) throws DOMException {
        this.A();
        return null;
    }
    
    public Node removeChild(final Node node) throws DOMException {
        this.A();
        return null;
    }
    
    public Node appendChild(final Node node) throws DOMException {
        this.A();
        return null;
    }
    
    public boolean hasChildNodes() {
        return false;
    }
    
    public Node cloneNode(final boolean b) {
        return new A(this.D, this.C, this.E);
    }
    
    public void normalize() {
    }
    
    public boolean isSupported(final String s, final String s2) {
        return false;
    }
    
    public String getNamespaceURI() {
        return null;
    }
    
    public String getPrefix() {
        return null;
    }
    
    public void setPrefix(final String s) throws DOMException {
        this.A();
    }
    
    public String getLocalName() {
        return this.C;
    }
    
    public boolean hasAttributes() {
        return false;
    }
    
    private void A() throws DOMException {
        throw new DOMException((short)7, "Namespace node may not be modified");
    }
    
    public int hashCode() {
        return this.A(this.D) + this.A(this.C) + this.A(this.E);
    }
    
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o == null) {
            return false;
        }
        if (o instanceof A) {
            final A a = (A)o;
            return this.A(this.D, a.getParentNode()) && this.A(this.C, a.getNodeName()) && this.A(this.E, a.getNodeValue());
        }
        return false;
    }
    
    private int A(final Object o) {
        return (o == null) ? 0 : o.hashCode();
    }
    
    private boolean A(final Object o, final Object obj) {
        return (o == null && obj == null) || (o != null && o.equals(obj));
    }
    
    public String getBaseURI() {
        final Class clazz = Node.class;
        try {
            final Class[] array = new Class[0];
            return (String)clazz.getMethod("getBaseURI", (Class[])array).invoke(this.getParentNode(), (Object[])array);
        }
        catch (final Exception ex) {
            return null;
        }
    }
    
    public short compareDocumentPosition(final Node node) throws DOMException {
        throw new DOMException((short)9, "DOM level 3 interfaces are not fully implemented in Jaxen's NamespaceNode class");
    }
    
    public String getTextContent() {
        return this.E;
    }
    
    public void setTextContent(final String s) throws DOMException {
        this.A();
    }
    
    public boolean isSameNode(final Node node) {
        final boolean equalNode = this.isEqualNode(node);
        final Node parentNode = this.getParentNode();
        final Node parentNode2 = node.getParentNode();
        boolean b;
        try {
            final Class clazz = Node.class;
            b = (boolean)clazz.getMethod("isEqual", clazz).invoke(parentNode, parentNode2);
        }
        catch (final NoSuchMethodException ex) {
            b = parentNode.equals(parentNode2);
        }
        catch (final InvocationTargetException ex2) {
            b = parentNode.equals(parentNode2);
        }
        catch (final IllegalAccessException ex3) {
            b = parentNode.equals(parentNode2);
        }
        return equalNode && b;
    }
    
    public String lookupPrefix(final String s) {
        try {
            return (String)Node.class.getMethod("lookupPrefix", String.class).invoke(this.D, s);
        }
        catch (final NoSuchMethodException ex) {
            throw new UnsupportedOperationException("Cannot lookup prefixes in DOM 2");
        }
        catch (final InvocationTargetException ex2) {
            throw new UnsupportedOperationException("Cannot lookup prefixes in DOM 2");
        }
        catch (final IllegalAccessException ex3) {
            throw new UnsupportedOperationException("Cannot lookup prefixes in DOM 2");
        }
    }
    
    public boolean isDefaultNamespace(final String s) {
        return s.equals(this.lookupNamespaceURI(null));
    }
    
    public String lookupNamespaceURI(final String s) {
        try {
            return (String)Node.class.getMethod("lookupNamespaceURI", String.class).invoke(this.D, s);
        }
        catch (final NoSuchMethodException ex) {
            throw new UnsupportedOperationException("Cannot lookup namespace URIs in DOM 2");
        }
        catch (final InvocationTargetException ex2) {
            throw new UnsupportedOperationException("Cannot lookup namespace URIs in DOM 2");
        }
        catch (final IllegalAccessException ex3) {
            throw new UnsupportedOperationException("Cannot lookup namespace URIs in DOM 2");
        }
    }
    
    public boolean isEqualNode(final Node node) {
        if (node.getNodeType() != this.getNodeType()) {
            return false;
        }
        final A a = (A)node;
        if (a.C == null && this.C != null) {
            return false;
        }
        if (a.C != null && this.C == null) {
            return false;
        }
        if (a.E == null && this.E != null) {
            return false;
        }
        if (a.E != null && this.E == null) {
            return false;
        }
        if (a.C == null && this.C == null) {
            return a.E.equals(this.E);
        }
        return a.C.equals(this.C) && a.E.equals(this.E);
    }
    
    public Object getFeature(final String s, final String s2) {
        return null;
    }
    
    public Object setUserData(final String key, final Object value, final org.C.A.A a) {
        final Object userData = this.getUserData(key);
        this.A.put(key, value);
        return userData;
    }
    
    public Object getUserData(final String key) {
        return this.A.get(key);
    }
    
    private static class _A implements NodeList
    {
        public int getLength() {
            return 0;
        }
        
        public Node item(final int n) {
            return null;
        }
    }
}
