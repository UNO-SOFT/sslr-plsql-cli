// 
// Decompiled by Procyon v0.6.0
// 

package org.A.C;

import org.w3c.dom.Node;

class C$4 extends _A {
    protected Node C(final Node node) {
        return this.B(node);
    }
    
    protected Node B(final Node node) {
        return node.getNextSibling();
    }
}