// 
// Decompiled by Procyon v0.6.0
// 

package org.A.C;

import java.util.NoSuchElementException;
import org.w3c.dom.Node;
import java.util.Iterator;

abstract class _A implements Iterator
{
    private Node A;
    
    public _A(final Node node) {
        this.A = this.C(node);
        while (!this.A(this.A)) {
            this.A = this.B(this.A);
        }
    }
    
    public boolean hasNext() {
        return this.A != null;
    }
    
    public Object next() {
        if (this.A == null) {
            throw new NoSuchElementException();
        }
        final Node a = this.A;
        this.A = this.B(this.A);
        while (!this.A(this.A)) {
            this.A = this.B(this.A);
        }
        return a;
    }
    
    public void remove() {
        throw new UnsupportedOperationException();
    }
    
    protected abstract Node C(final Node p0);
    
    protected abstract Node B(final Node p0);
    
    private boolean A(final Node node) {
        if (node == null) {
            return true;
        }
        switch (node.getNodeType()) {
            case 5:
            case 6:
            case 10:
            case 11:
            case 12: {
                return false;
            }
            default: {
                return true;
            }
        }
    }
}
