// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

public interface O
{
    String A(final String p0);
}
