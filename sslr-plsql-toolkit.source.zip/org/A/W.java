// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import java.util.HashMap;
import java.util.Map;
import java.io.Serializable;

public class W implements T, Serializable
{
    private static final long B = 961322093794516518L;
    private Map A;
    
    public W() {
        this.A = new HashMap();
    }
    
    public void A(final String s, final String s2, final Object o) {
        this.A.put(new G(s, s2), o);
    }
    
    public void A(final String s, final Object o) {
        this.A.put(new G(null, s), o);
    }
    
    public Object A(final String s, final String s2, final String s3) throws U {
        final G g = new G(s, s3);
        if (this.A.containsKey(g)) {
            return this.A.get(g);
        }
        throw new U("Variable " + g.A());
    }
}
