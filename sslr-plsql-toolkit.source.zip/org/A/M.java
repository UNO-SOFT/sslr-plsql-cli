// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import java.util.Collections;
import java.util.ListIterator;
import java.util.Iterator;

public class M
{
    public static final Iterator B;
    public static final ListIterator A;
    
    private M() {
    }
    
    static {
        B = Collections.EMPTY_LIST.iterator();
        A = Collections.EMPTY_LIST.listIterator();
    }
}
