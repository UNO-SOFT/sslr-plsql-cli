// 
// Decompiled by Procyon v0.6.0
// 

package org.A.E;

import java.util.NoSuchElementException;
import org.A.A;
import org.A.X;
import org.A.M;
import org.A.E;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Iterator;

public class K implements Iterator
{
    private Iterator D;
    private Iterator E;
    private ListIterator C;
    private ArrayList A;
    private E B;
    
    public K(final Object o, final E b) throws X {
        this.B = b;
        this.D = b.getAncestorOrSelfAxisIterator(o);
        this.E = M.B;
        this.C = M.A;
        this.A = new ArrayList();
    }
    
    public boolean hasNext() {
        try {
            while (!this.C.hasPrevious()) {
                if (this.A.isEmpty()) {
                    while (!this.E.hasNext()) {
                        if (!this.D.hasNext()) {
                            return false;
                        }
                        this.E = new I(this.D.next(), this.B);
                    }
                    this.C = this.A(this.E.next());
                }
                else {
                    this.C = this.A.remove(this.A.size() - 1);
                }
            }
            return true;
        }
        catch (final X x) {
            throw new A(x);
        }
    }
    
    private ListIterator A(final Object e) {
        try {
            final ArrayList list = new ArrayList();
            list.add(e);
            final Iterator childAxisIterator = this.B.getChildAxisIterator(e);
            if (childAxisIterator != null) {
                while (childAxisIterator.hasNext()) {
                    list.add(childAxisIterator.next());
                }
            }
            return list.listIterator(list.size());
        }
        catch (final X x) {
            throw new A(x);
        }
    }
    
    public Object next() throws NoSuchElementException {
        if (!this.hasNext()) {
            throw new NoSuchElementException();
        }
        Object previous;
        while (true) {
            previous = this.C.previous();
            if (!this.C.hasPrevious()) {
                break;
            }
            this.A.add(this.C);
            this.C = this.A(previous);
        }
        return previous;
    }
    
    public void remove() throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }
}
