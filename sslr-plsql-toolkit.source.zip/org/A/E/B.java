// 
// Decompiled by Procyon v0.6.0
// 

package org.A.E;

import org.A.X;
import org.A.A;
import java.util.NoSuchElementException;
import org.A.E;
import java.util.Iterator;

public class B implements Iterator
{
    private Object B;
    private E A;
    
    public B(final Object b, final E a) {
        this.B = b;
        this.A = a;
    }
    
    public boolean hasNext() {
        return this.B != null;
    }
    
    public Object next() {
        try {
            if (this.hasNext()) {
                final Object b = this.B;
                this.B = this.A.getParentNode(this.B);
                return b;
            }
            throw new NoSuchElementException("Exhausted ancestor-or-self axis");
        }
        catch (final X x) {
            throw new A(x);
        }
    }
    
    public void remove() {
        throw new UnsupportedOperationException();
    }
}
