// 
// Decompiled by Procyon v0.6.0
// 

package org.A.E;

import java.util.NoSuchElementException;
import java.util.Iterator;

public class F implements Iterator
{
    private Object B;
    private boolean A;
    
    public F(final Object b) {
        this.B = b;
        this.A = false;
    }
    
    public boolean hasNext() {
        return !this.A;
    }
    
    public Object next() {
        if (this.hasNext()) {
            this.A = true;
            return this.B;
        }
        throw new NoSuchElementException();
    }
    
    public void remove() {
        throw new UnsupportedOperationException();
    }
}
