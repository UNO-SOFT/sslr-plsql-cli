// 
// Decompiled by Procyon v0.6.0
// 

package org.A.E;

public class A extends F
{
    public A(final Object o) {
        super(o);
    }
}
