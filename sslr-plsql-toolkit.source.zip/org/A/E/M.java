// 
// Decompiled by Procyon v0.6.0
// 

package org.A.E;

import java.util.NoSuchElementException;
import java.util.HashSet;
import java.util.Set;
import org.A.E;
import java.util.LinkedList;
import java.util.Iterator;

public abstract class M implements Iterator
{
    private LinkedList B;
    private E A;
    private Set C;
    
    public M(final Object o, final E e) {
        this.B = new LinkedList();
        this.C = new HashSet();
        this.A(o, e);
    }
    
    protected M() {
        this.B = new LinkedList();
        this.C = new HashSet();
    }
    
    protected void A(final Object o, final E a) {
        this.A = a;
    }
    
    protected Iterator A(final Object o) {
        if (this.C.contains(o)) {
            return null;
        }
        this.C.add(o);
        return this.B(o);
    }
    
    public boolean hasNext() {
        final Iterator b = this.B();
        return b != null && b.hasNext();
    }
    
    public Object next() throws NoSuchElementException {
        if (!this.hasNext()) {
            throw new NoSuchElementException();
        }
        final Object next = this.B().next();
        this.A(this.A(next));
        return next;
    }
    
    public void remove() throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }
    
    protected abstract Iterator B(final Object p0);
    
    protected void A(final Iterator e) {
        if (e != null) {
            this.B.addFirst(e);
        }
    }
    
    private Iterator B() {
        while (this.B.size() > 0) {
            final Iterator iterator = this.B.getFirst();
            if (iterator.hasNext()) {
                return iterator;
            }
            this.B.removeFirst();
        }
        return null;
    }
    
    protected E A() {
        return this.A;
    }
}
