// 
// Decompiled by Procyon v0.6.0
// 

package org.A.E;

import java.util.NoSuchElementException;
import org.A.M;
import org.A.X;
import org.A.E;
import java.util.Iterator;

public class H implements Iterator
{
    private Object C;
    private E B;
    private Iterator A;
    
    public H(final Object c, final E b) throws X {
        this.C = c;
        this.B = b;
        this.A();
    }
    
    private void A() throws X {
        final Object parentNode = this.B.getParentNode(this.C);
        if (parentNode != null) {
            this.A = this.B.getChildAxisIterator(parentNode);
            while (this.A.hasNext()) {
                if (this.A.next().equals(this.C)) {
                    break;
                }
            }
        }
        else {
            this.A = M.B;
        }
    }
    
    public boolean hasNext() {
        return this.A.hasNext();
    }
    
    public Object next() throws NoSuchElementException {
        return this.A.next();
    }
    
    public void remove() throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }
}
