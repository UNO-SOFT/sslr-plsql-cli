// 
// Decompiled by Procyon v0.6.0
// 

package org.A.E;

import org.A.A;
import java.util.NoSuchElementException;
import org.A.X;
import org.A.E;
import java.util.ArrayList;
import java.util.Iterator;

public class D implements Iterator
{
    private ArrayList A;
    private Iterator C;
    private E B;
    
    public D(final Object o, final E e) throws X {
        this(e, e.getChildAxisIterator(o));
    }
    
    public D(final E b, final Iterator c) {
        this.A = new ArrayList();
        this.B = b;
        this.C = c;
    }
    
    public boolean hasNext() {
        while (!this.C.hasNext()) {
            if (this.A.isEmpty()) {
                return false;
            }
            this.C = this.A.remove(this.A.size() - 1);
        }
        return true;
    }
    
    public Object next() {
        try {
            if (this.hasNext()) {
                final Object next = this.C.next();
                this.A.add(this.C);
                this.C = this.B.getChildAxisIterator(next);
                return next;
            }
            throw new NoSuchElementException();
        }
        catch (final X x) {
            throw new A(x);
        }
    }
    
    public void remove() {
        throw new UnsupportedOperationException();
    }
}
