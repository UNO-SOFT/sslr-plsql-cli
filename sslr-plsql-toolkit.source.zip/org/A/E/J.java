// 
// Decompiled by Procyon v0.6.0
// 

package org.A.E;

import java.util.NoSuchElementException;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

public class J implements Iterator
{
    private List A;
    private int B;
    
    public J() {
        this.A = new ArrayList();
        this.B = 0;
    }
    
    public void A(final Iterator iterator) {
        this.A.add(iterator);
    }
    
    public boolean hasNext() {
        boolean b;
        if (this.B < this.A.size()) {
            b = this.A.get(this.B).hasNext();
            if (!b && this.B < this.A.size()) {
                ++this.B;
                b = this.hasNext();
            }
        }
        else {
            b = false;
        }
        return b;
    }
    
    public Object next() {
        if (!this.hasNext()) {
            throw new NoSuchElementException();
        }
        return this.A.get(this.B).next();
    }
    
    public void remove() {
        throw new UnsupportedOperationException();
    }
}
