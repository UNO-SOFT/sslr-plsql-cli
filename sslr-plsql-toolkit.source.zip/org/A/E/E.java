// 
// Decompiled by Procyon v0.6.0
// 

package org.A.E;

import java.util.AbstractList;

public class E extends AbstractList
{
    private final Object A;
    
    public E(final Object a) {
        this.A = a;
    }
    
    public int size() {
        return 1;
    }
    
    public Object get(final int i) {
        if (i == 0) {
            return this.A;
        }
        throw new IndexOutOfBoundsException(i + " != 0");
    }
}
