// 
// Decompiled by Procyon v0.6.0
// 

package org.A.E;

import java.util.Iterator;
import org.A.E;

public class G extends D
{
    public G(final Object o, final E e) {
        super(e, new F(o));
    }
}
