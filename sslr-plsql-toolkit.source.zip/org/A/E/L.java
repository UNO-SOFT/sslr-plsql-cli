// 
// Decompiled by Procyon v0.6.0
// 

package org.A.E;

import java.util.NoSuchElementException;
import org.A.A;
import org.A.X;
import org.A.M;
import org.A.E;
import java.util.Iterator;

public class L implements Iterator
{
    private Object B;
    private E A;
    private Iterator D;
    private Iterator C;
    
    public L(final Object b, final E a) throws X {
        this.B = b;
        this.A = a;
        this.D = a.getFollowingSiblingAxisIterator(b);
        this.C = M.B;
    }
    
    private boolean A() {
        while (!this.D.hasNext()) {
            if (!this.B()) {
                return false;
            }
        }
        this.C = new G(this.D.next(), this.A);
        return true;
    }
    
    private boolean B() {
        if (this.B == null || this.A.isDocument(this.B)) {
            return false;
        }
        try {
            this.B = this.A.getParentNode(this.B);
            if (this.B != null && !this.A.isDocument(this.B)) {
                this.D = this.A.getFollowingSiblingAxisIterator(this.B);
                return true;
            }
            return false;
        }
        catch (final X x) {
            throw new A(x);
        }
    }
    
    public boolean hasNext() {
        while (!this.C.hasNext()) {
            if (!this.A()) {
                return false;
            }
        }
        return true;
    }
    
    public Object next() throws NoSuchElementException {
        if (!this.hasNext()) {
            throw new NoSuchElementException();
        }
        return this.C.next();
    }
    
    public void remove() throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }
}
