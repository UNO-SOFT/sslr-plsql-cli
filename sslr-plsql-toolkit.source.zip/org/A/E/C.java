// 
// Decompiled by Procyon v0.6.0
// 

package org.A.E;

import org.A.E;

public class C extends B
{
    public C(final Object o, final E e) {
        super(o, e);
        this.next();
    }
}
