// 
// Decompiled by Procyon v0.6.0
// 

package org.A.E;

import java.util.NoSuchElementException;
import org.A.M;
import java.util.LinkedList;
import org.A.X;
import org.A.E;
import java.util.Iterator;

public class I implements Iterator
{
    private Object C;
    private E B;
    private Iterator A;
    private Object D;
    
    public I(final Object c, final E b) throws X {
        this.C = c;
        this.B = b;
        this.A();
        if (this.A.hasNext()) {
            this.D = this.A.next();
        }
    }
    
    private void A() throws X {
        final Object parentNode = this.B.getParentNode(this.C);
        if (parentNode != null) {
            final Iterator childAxisIterator = this.B.getChildAxisIterator(parentNode);
            final LinkedList list = new LinkedList();
            while (childAxisIterator.hasNext()) {
                final Object next = childAxisIterator.next();
                if (next.equals(this.C)) {
                    break;
                }
                list.addFirst(next);
            }
            this.A = list.iterator();
        }
        else {
            this.A = M.B;
        }
    }
    
    public boolean hasNext() {
        return this.D != null;
    }
    
    public Object next() throws NoSuchElementException {
        if (!this.hasNext()) {
            throw new NoSuchElementException();
        }
        final Object d = this.D;
        if (this.A.hasNext()) {
            this.D = this.A.next();
        }
        else {
            this.D = null;
        }
        return d;
    }
    
    public void remove() throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }
}
