// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

public interface C
{
    H A(final String p0, final String p1, final String p2) throws U;
}
