// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

public interface T
{
    Object A(final String p0, final String p1, final String p2) throws U;
}
