// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

public class X extends S
{
    private static final long P = 3385500112257420949L;
    
    public X(final String s) {
        super(s);
    }
}
