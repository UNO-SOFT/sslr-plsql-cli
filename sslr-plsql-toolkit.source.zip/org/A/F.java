// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import org.A.J.u;
import org.A.D._;
import org.A.D.C;
import org.A.D.U;
import java.util.List;
import org.A.F.G;
import org.A.F.A.A;
import java.io.Serializable;

public class F implements D, Serializable
{
    private static final long E = -1993731281300293168L;
    private final String C;
    private final org.A.J.F B;
    private V D;
    private E A;
    
    protected F(final String c) throws S {
        try {
            final org.A.F.A a = org.A.F.A.A.A();
            final I i = new I();
            a.A(i);
            a.A(c);
            this.B = i.i();
        }
        catch (final org.A.F.F f) {
            throw new B(f);
        }
        catch (final org.A.F.D d) {
            throw new S(d);
        }
        this.C = c;
    }
    
    public F(final String s, final E a) throws S {
        this(s);
        this.A = a;
    }
    
    public Object B(final Object o) throws S {
        final List c = this.C(o);
        if (c != null && c.size() == 1) {
            final Object value = c.get(0);
            if (value instanceof String || value instanceof Number || value instanceof Boolean) {
                return value;
            }
        }
        return c;
    }
    
    public List C(final Object o) throws S {
        return this.B(this.H(o));
    }
    
    public Object A(final Object o) throws S {
        final List c = this.C(o);
        if (c.isEmpty()) {
            return null;
        }
        return c.get(0);
    }
    
    public String F(final Object o) throws S {
        return this.E(o);
    }
    
    public String E(final Object o) throws S {
        final P h = this.H(o);
        final Object a = this.A(h);
        if (a == null) {
            return "";
        }
        return U.J(a, h.D());
    }
    
    public boolean G(final Object o) throws S {
        final P h = this.H(o);
        final List b = this.B(h);
        return b != null && org.A.D.C.B(b, h.D());
    }
    
    public Number D(final Object o) throws S {
        final P h = this.H(o);
        return _.K(this.A(h), h.D());
    }
    
    public void A(final String s, final String s2) throws S {
        final O b = this.B();
        if (b instanceof R) {
            ((R)b).A(s, s2);
            return;
        }
        throw new S("Operation not permitted while using a non-simple namespace context.");
    }
    
    public void A(final O o) {
        this.G().A(o);
    }
    
    public void A(final org.A.C c) {
        this.G().A(c);
    }
    
    public void A(final T t) {
        this.G().A(t);
    }
    
    public O B() {
        return this.G().B();
    }
    
    public org.A.C C() {
        return this.G().C();
    }
    
    public T A() {
        return this.G().A();
    }
    
    public u H() {
        return this.B.C();
    }
    
    public String toString() {
        return this.C;
    }
    
    public String E() {
        return this.B.toString();
    }
    
    protected P H(final Object o) {
        if (o instanceof P) {
            return (P)o;
        }
        final P p = new P(this.G());
        if (o instanceof List) {
            p.A((List)o);
        }
        else {
            p.A(new org.A.E.E(o));
        }
        return p;
    }
    
    protected V G() {
        if (this.D == null) {
            this.D = new V(this.J(), this.I(), this.F(), this.D());
        }
        return this.D;
    }
    
    public E D() {
        return this.A;
    }
    
    protected org.A.C I() {
        return Q.A();
    }
    
    protected O J() {
        return new R();
    }
    
    protected T F() {
        return new W();
    }
    
    protected List B(final P p) throws S {
        return this.B.A(p);
    }
    
    protected Object A(final P p) throws S {
        final List b = this.B(p);
        if (b.isEmpty()) {
            return null;
        }
        return b.get(0);
    }
}
