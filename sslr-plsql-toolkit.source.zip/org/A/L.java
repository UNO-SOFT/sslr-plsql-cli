// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import org.A.E.B;
import org.A.E.G;
import org.A.E.A;
import org.A.E.K;
import org.A.E.I;
import org.A.E.H;
import org.A.E.C;
import org.A.E.D;
import java.util.Iterator;

public abstract class L implements E
{
    public Iterator getChildAxisIterator(final Object o) throws X {
        throw new X("child");
    }
    
    public Iterator getDescendantAxisIterator(final Object o) throws X {
        return new D(o, this);
    }
    
    public Iterator getParentAxisIterator(final Object o) throws X {
        throw new X("parent");
    }
    
    public Iterator getAncestorAxisIterator(final Object o) throws X {
        return new C(o, this);
    }
    
    public Iterator getFollowingSiblingAxisIterator(final Object o) throws X {
        return new H(o, this);
    }
    
    public Iterator getPrecedingSiblingAxisIterator(final Object o) throws X {
        return new I(o, this);
    }
    
    public Iterator getFollowingAxisIterator(final Object o) throws X {
        return new org.A.E.L(o, this);
    }
    
    public Iterator getPrecedingAxisIterator(final Object o) throws X {
        return new K(o, this);
    }
    
    public Iterator getAttributeAxisIterator(final Object o) throws X {
        throw new X("attribute");
    }
    
    public Iterator getNamespaceAxisIterator(final Object o) throws X {
        throw new X("namespace");
    }
    
    public Iterator getSelfAxisIterator(final Object o) throws X {
        return new A(o);
    }
    
    public Iterator getDescendantOrSelfAxisIterator(final Object o) throws X {
        return new G(o, this);
    }
    
    public Iterator getAncestorOrSelfAxisIterator(final Object o) throws X {
        return new B(o, this);
    }
    
    public Object getDocumentNode(final Object o) {
        return null;
    }
    
    public String translateNamespacePrefixToUri(final String s, final Object o) {
        return null;
    }
    
    public String getProcessingInstructionTarget(final Object o) {
        return null;
    }
    
    public String getProcessingInstructionData(final Object o) {
        return null;
    }
    
    public short getNodeType(final Object o) {
        if (this.isElement(o)) {
            return 1;
        }
        if (this.isAttribute(o)) {
            return 2;
        }
        if (this.isText(o)) {
            return 3;
        }
        if (this.isComment(o)) {
            return 8;
        }
        if (this.isDocument(o)) {
            return 9;
        }
        if (this.isProcessingInstruction(o)) {
            return 7;
        }
        if (this.isNamespace(o)) {
            return 13;
        }
        return 14;
    }
    
    public Object getParentNode(final Object o) throws X {
        final Iterator parentAxisIterator = this.getParentAxisIterator(o);
        if (parentAxisIterator != null && parentAxisIterator.hasNext()) {
            return parentAxisIterator.next();
        }
        return null;
    }
    
    public Object getDocument(final String s) throws org.A.K {
        return null;
    }
    
    public Object getElementById(final Object o, final String s) {
        return null;
    }
}
