// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import java.io.PrintWriter;
import java.io.PrintStream;

public class A extends RuntimeException
{
    private static final long C = -930309761511911193L;
    private Throwable A;
    private boolean B;
    
    public A(final Throwable t) {
        super(t.getMessage());
        this.B = false;
        this.initCause(t);
    }
    
    public A(final String message) {
        super(message);
        this.B = false;
    }
    
    public Throwable getCause() {
        return this.A;
    }
    
    public Throwable initCause(final Throwable a) {
        if (this.B) {
            throw new IllegalStateException("Cause cannot be reset");
        }
        if (a == this) {
            throw new IllegalArgumentException("Exception cannot be its own cause");
        }
        this.B = true;
        this.A = a;
        return this;
    }
    
    public void printStackTrace(final PrintStream printStream) {
        super.printStackTrace(printStream);
        if (S.I < 1.4 && this.getCause() != null) {
            printStream.print("Caused by: ");
            this.getCause().printStackTrace(printStream);
        }
    }
    
    public void printStackTrace(final PrintWriter printWriter) {
        super.printStackTrace(printWriter);
        if (S.I < 1.4 && this.getCause() != null) {
            printWriter.print("Caused by: ");
            this.getCause().printStackTrace(printWriter);
        }
    }
}
