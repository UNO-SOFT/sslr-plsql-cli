// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import java.io.Serializable;

class G implements Serializable
{
    private static final long C = 2734958615642751535L;
    private String B;
    private String A;
    
    G(String b, final String a) {
        if (b == null) {
            b = "";
        }
        this.B = b;
        this.A = a;
    }
    
    public int hashCode() {
        return this.A.hashCode() ^ this.B.hashCode();
    }
    
    public boolean equals(final Object o) {
        final G g = (G)o;
        return this.B.equals(g.B) && g.A.equals(this.A);
    }
    
    String A() {
        if ("".equals(this.B)) {
            return this.A;
        }
        return "{" + this.B + "}" + ":" + this.A;
    }
}
