// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import java.util.HashMap;

public class N implements C
{
    private HashMap A;
    
    public N() {
        this.A = new HashMap();
    }
    
    public void A(final String s, final String s2, final H value) {
        this.A.put(new G(s, s2), value);
    }
    
    public H A(final String s, final String s2, final String s3) throws U {
        final G g = new G(s, s3);
        if (this.A.containsKey(g)) {
            return (H)this.A.get(g);
        }
        throw new U("No Such Function " + g.A());
    }
}
