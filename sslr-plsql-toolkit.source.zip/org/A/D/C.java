// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class C implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 1) {
            return B(list.get(0), p2.D());
        }
        throw new K("boolean() requires one argument");
    }
    
    public static Boolean B(Object value, final E e) {
        if (value instanceof List) {
            final List list = (List)value;
            if (list.size() == 0) {
                return Boolean.FALSE;
            }
            value = list.get(0);
        }
        if (value instanceof Boolean) {
            return (Boolean)value;
        }
        if (value instanceof Number) {
            final double doubleValue = ((Number)value).doubleValue();
            if (doubleValue == 0.0 || Double.isNaN(doubleValue)) {
                return Boolean.FALSE;
            }
            return Boolean.TRUE;
        }
        else {
            if (value instanceof String) {
                return (((String)value).length() > 0) ? Boolean.TRUE : Boolean.FALSE;
            }
            return (value != null) ? Boolean.TRUE : Boolean.FALSE;
        }
    }
}
