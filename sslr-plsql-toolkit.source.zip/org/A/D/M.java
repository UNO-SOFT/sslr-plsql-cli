// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class M implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 0) {
            return A(p2);
        }
        throw new K("last() requires no arguments.");
    }
    
    public static Double A(final P p) {
        return new Double(p.B());
    }
}
