// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import org.A.E;
import java.util.List;
import org.A.P;
import org.A.H;

public class K implements H
{
    public Object A(final P p2, final List list) throws org.A.K {
        if (list.size() == 2) {
            return B(list.get(0), list.get(1), p2.D());
        }
        throw new org.A.K("substring-before() requires two arguments.");
    }
    
    public static String B(final Object o, final Object o2, final E e) {
        final String j = U.J(o, e);
        final int index = j.indexOf(U.J(o2, e));
        if (index < 0) {
            return "";
        }
        return j.substring(0, index);
    }
}
