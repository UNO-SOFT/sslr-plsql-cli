// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class E implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 1) {
            return C(list.get(0), p2.D());
        }
        throw new K("not() requires one argument.");
    }
    
    public static Boolean C(final Object o, final org.A.E e) {
        return ((boolean)C.B(o, e)) ? Boolean.FALSE : Boolean.TRUE;
    }
}
