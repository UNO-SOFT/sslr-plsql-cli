// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class I implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 1) {
            return A(list.get(0));
        }
        throw new K("count() requires one argument.");
    }
    
    public static Double A(final Object o) throws K {
        if (o instanceof List) {
            return new Double(((List)o).size());
        }
        throw new K("count() function can only be used for node-sets");
    }
}
