// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import java.util.Iterator;
import org.A.E;
import org.A.X;
import org.A.K;
import java.util.List;
import org.A.H;

public class P implements H
{
    private static final String B = "lang";
    private static final String A = "http://www.w3.org/XML/1998/namespace";
    
    public Object A(final org.A.P p2, final List list) throws K {
        if (list.size() != 1) {
            throw new K("lang() requires exactly one argument.");
        }
        final Object value = list.get(0);
        try {
            return A(p2.F(), value, p2.D());
        }
        catch (final X x) {
            throw new K("Can't evaluate lang()", x);
        }
    }
    
    private static Boolean A(final List list, final Object o, final E e) throws X {
        return A(list.get(0), U.J(o, e), e) ? Boolean.TRUE : Boolean.FALSE;
    }
    
    private static boolean A(final Object o, final String s, final E e) throws X {
        Object o2 = o;
        if (!e.isElement(o2)) {
            o2 = e.getParentNode(o);
        }
        while (o2 != null && e.isElement(o2)) {
            final Iterator attributeAxisIterator = e.getAttributeAxisIterator(o2);
            while (attributeAxisIterator.hasNext()) {
                final Object next = attributeAxisIterator.next();
                if ("lang".equals(e.getAttributeName(next)) && "http://www.w3.org/XML/1998/namespace".equals(e.getAttributeNamespaceUri(next))) {
                    return A(e.getAttributeStringValue(next), s);
                }
            }
            o2 = e.getParentNode(o2);
        }
        return false;
    }
    
    private static boolean A(final String s, final String s2) {
        if (s.equalsIgnoreCase(s2)) {
            return true;
        }
        final int length = s2.length();
        return s.length() > length && s.charAt(length) == '-' && s.substring(0, length).equalsIgnoreCase(s2);
    }
}
