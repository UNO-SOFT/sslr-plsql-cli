// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D.A;

import org.A.E;
import org.A.K;
import org.A.D.U;
import java.util.List;
import org.A.P;
import org.A.H;

public class A implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 1) {
            final E d = p2.D();
            return A(U.J(list.get(0), d), d);
        }
        throw new K("document() requires one argument.");
    }
    
    public static Object A(final String s, final E e) throws K {
        return e.getDocument(s);
    }
}
