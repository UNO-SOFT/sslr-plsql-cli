// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import java.util.Iterator;
import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class A implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() >= 2) {
            return A(list, p2.D());
        }
        throw new K("concat() requires at least two arguments");
    }
    
    public static String A(final List list, final E e) {
        final StringBuffer sb = new StringBuffer();
        final Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            sb.append(U.J(iterator.next(), e));
        }
        return sb.toString();
    }
}
