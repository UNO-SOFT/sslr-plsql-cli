// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class T implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 1) {
            return I(list.get(0), p2.D());
        }
        throw new K("floor() requires one argument.");
    }
    
    public static Double I(final Object o, final E e) {
        return new Double(Math.floor(_.K(o, e)));
    }
}
