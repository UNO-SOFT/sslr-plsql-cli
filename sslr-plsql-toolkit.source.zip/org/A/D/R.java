// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import java.util.Iterator;
import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class R implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 1) {
            return G(list.get(0), p2.D());
        }
        throw new K("sum() requires one argument.");
    }
    
    public static Double G(final Object o, final E e) throws K {
        double value = 0.0;
        if (o instanceof List) {
            final Iterator iterator = ((List)o).iterator();
            while (iterator.hasNext()) {
                value += _.K(iterator.next(), e);
            }
            return new Double(value);
        }
        throw new K("The argument to the sum function must be a node-set");
    }
}
