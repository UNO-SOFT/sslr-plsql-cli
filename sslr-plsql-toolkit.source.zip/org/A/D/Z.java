// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class Z implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 0) {
            return D(p2.F(), p2.D());
        }
        if (list.size() == 1) {
            return D(list, p2.D());
        }
        throw new K("namespace-uri() requires zero or one argument.");
    }
    
    public static String D(final List list, final E e) throws K {
        if (list.isEmpty()) {
            return "";
        }
        final List value = list.get(0);
        if (value instanceof List) {
            return D(value, e);
        }
        if (e.isElement(value)) {
            return e.getElementNamespaceUri(value);
        }
        if (e.isAttribute(value)) {
            final String attributeNamespaceUri = e.getAttributeNamespaceUri(value);
            if (attributeNamespaceUri == null) {
                return "";
            }
            return attributeNamespaceUri;
        }
        else {
            if (e.isProcessingInstruction(value)) {
                return "";
            }
            if (e.isNamespace(value)) {
                return "";
            }
            if (e.isDocument(value)) {
                return "";
            }
            if (e.isComment(value)) {
                return "";
            }
            if (e.isText(value)) {
                return "";
            }
            throw new K("The argument to the namespace-uri function must be a node-set");
        }
    }
}
