// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import java.util.HashMap;
import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class Y implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 3) {
            return A(list.get(0), list.get(1), list.get(2), p2.D());
        }
        throw new K("translate() requires three arguments.");
    }
    
    public static String A(final Object o, final Object o2, final Object o3, final E e) throws K {
        final String j = U.J(o, e);
        final String i = U.J(o2, e);
        final String k = U.J(o3, e);
        final HashMap hashMap = new HashMap();
        final String[] c = C(i);
        final String[] c2 = C(k);
        final int length = c.length;
        final int length2 = c2.length;
        for (int l = 0; l < length; ++l) {
            final String s = c[l];
            if (!hashMap.containsKey(s)) {
                if (l < length2) {
                    hashMap.put(s, c2[l]);
                }
                else {
                    hashMap.put(s, null);
                }
            }
        }
        final StringBuffer sb = new StringBuffer(j.length());
        for (final String str : C(j)) {
            if (hashMap.containsKey(str)) {
                final String str2 = (String)hashMap.get(str);
                if (str2 != null) {
                    sb.append(str2);
                }
            }
            else {
                sb.append(str);
            }
        }
        return sb.toString();
    }
    
    private static String[] C(final String s) throws K {
        final String[] array = new String[s.length()];
        int n = 0;
        for (int i = 0; i < s.length(); ++i) {
            final char char1 = s.charAt(i);
            Label_0125: {
                if (C(char1)) {
                    try {
                        final char char2 = s.charAt(i + 1);
                        if (B(char2)) {
                            array[n] = (char1 + "" + char2).intern();
                            ++i;
                            break Label_0125;
                        }
                        throw new K("Mismatched surrogate pair in translate function");
                    }
                    catch (final StringIndexOutOfBoundsException ex) {
                        throw new K("High surrogate without low surrogate at end of string passed to translate function");
                    }
                }
                array[n] = String.valueOf(char1).intern();
            }
            ++n;
        }
        if (n == array.length) {
            return array;
        }
        final String[] array2 = new String[n];
        System.arraycopy(array, 0, array2, 0, n);
        return array2;
    }
    
    private static boolean C(final char c) {
        return c >= '\ud800' && c <= '\udbff';
    }
    
    private static boolean B(final char c) {
        return c >= '\udc00' && c <= '\udfff';
    }
}
