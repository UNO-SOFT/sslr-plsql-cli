// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class X implements H
{
    public Object A(final P p2, final List list) throws K {
        final int size = list.size();
        if (size < 2 || size > 3) {
            throw new K("substring() requires two or three arguments.");
        }
        final E d = p2.D();
        final String j = U.J(list.get(0), d);
        if (j == null) {
            return "";
        }
        final int intValue = G.E(list.get(0), d).intValue();
        if (intValue == 0) {
            return "";
        }
        final Double k = _.K(list.get(1), d);
        if (k.isNaN()) {
            return "";
        }
        int beginIndex = org.A.D.H.F(k, d).intValue() - 1;
        int intValue2 = intValue;
        if (size == 3) {
            final Double i = _.K(list.get(2), d);
            if (!i.isNaN()) {
                intValue2 = org.A.D.H.F(i, d).intValue();
            }
            else {
                intValue2 = 0;
            }
        }
        if (intValue2 < 0) {
            return "";
        }
        int endIndex = beginIndex + intValue2;
        if (size == 2) {
            endIndex = intValue;
        }
        if (beginIndex < 0) {
            beginIndex = 0;
        }
        else if (beginIndex > intValue) {
            return "";
        }
        if (endIndex > intValue) {
            endIndex = intValue;
        }
        else if (endIndex < beginIndex) {
            return "";
        }
        if (intValue == j.length()) {
            return j.substring(beginIndex, endIndex);
        }
        return A(j, beginIndex, endIndex);
    }
    
    private static String A(final String s, final int n, final int n2) {
        final StringBuffer sb = new StringBuffer(s.length());
        int n3 = 0;
        for (int i = 0; i < n2; ++i) {
            final char char1 = s.charAt(n3);
            if (i >= n) {
                sb.append(char1);
            }
            if (char1 >= '\ud800') {
                ++n3;
                if (i >= n) {
                    sb.append(s.charAt(n3));
                }
            }
            ++n3;
        }
        return sb.toString();
    }
}
