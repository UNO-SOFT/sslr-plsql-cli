// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Iterator;
import org.A.X;
import org.A.A;
import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import java.text.DecimalFormat;
import org.A.H;

public class U implements H
{
    private static DecimalFormat C;
    
    public Object A(final P p2, final List list) throws K {
        final int size = list.size();
        if (size == 0) {
            return J(p2.F(), p2.D());
        }
        if (size == 1) {
            return J(list.get(0), p2.D());
        }
        throw new K("string() takes at most argument.");
    }
    
    public static String J(Object value, final E e) {
        try {
            if (e != null && e.isText(value)) {
                return e.getTextStringValue(value);
            }
            if (value instanceof List) {
                final List list = (List)value;
                if (list.isEmpty()) {
                    return "";
                }
                value = list.get(0);
            }
            if (e != null) {
                if (e.isElement(value)) {
                    return e.getElementStringValue(value);
                }
                if (e.isAttribute(value)) {
                    return e.getAttributeStringValue(value);
                }
                if (e.isDocument(value)) {
                    final Iterator childAxisIterator = e.getChildAxisIterator(value);
                    while (childAxisIterator.hasNext()) {
                        final Object next = childAxisIterator.next();
                        if (e.isElement(next)) {
                            return e.getElementStringValue(next);
                        }
                    }
                }
                else {
                    if (e.isProcessingInstruction(value)) {
                        return e.getProcessingInstructionData(value);
                    }
                    if (e.isComment(value)) {
                        return e.getCommentStringValue(value);
                    }
                    if (e.isText(value)) {
                        return e.getTextStringValue(value);
                    }
                    if (e.isNamespace(value)) {
                        return e.getNamespaceStringValue(value);
                    }
                }
            }
            if (value instanceof String) {
                return (String)value;
            }
            if (value instanceof Boolean) {
                return A((boolean)value);
            }
            if (value instanceof Number) {
                return A(((Number)value).doubleValue());
            }
        }
        catch (final X x) {
            throw new A(x);
        }
        return "";
    }
    
    private static String A(final double number) {
        if (number == 0.0) {
            return "0";
        }
        String format = null;
        synchronized (U.C) {
            format = U.C.format(number);
        }
        return format;
    }
    
    private static String A(final boolean b) {
        return b ? "true" : "false";
    }
    
    static {
        U.C = (DecimalFormat)NumberFormat.getInstance(Locale.ENGLISH);
        final DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols(Locale.ENGLISH);
        decimalFormatSymbols.setNaN("NaN");
        decimalFormatSymbols.setInfinity("Infinity");
        U.C.setGroupingUsed(false);
        U.C.setMaximumFractionDigits(32);
        U.C.setDecimalFormatSymbols(decimalFormatSymbols);
    }
}
