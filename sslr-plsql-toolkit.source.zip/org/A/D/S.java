// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class S implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 0) {
            return H(p2.F(), p2.D());
        }
        if (list.size() == 1) {
            return H(list.get(0), p2.D());
        }
        throw new K("normalize-space() cannot have more than one argument");
    }
    
    public static String H(final Object o, final E e) {
        final char[] charArray = U.J(o, e).toCharArray();
        int n = 0;
        int count = 0;
        int n2 = 0;
        int i = 0;
        while (i < charArray.length) {
            if (A(charArray[i])) {
                if (n2 != 0) {
                    charArray[n++] = ' ';
                }
                while (++i < charArray.length) {
                    if (!A(charArray[i])) {
                        break;
                    }
                }
            }
            else {
                charArray[n++] = charArray[i++];
                n2 = 1;
                count = n;
            }
        }
        return new String(charArray, 0, count);
    }
    
    private static boolean A(final char c) {
        return c == ' ' || c == '\n' || c == '\r' || c == '\t';
    }
}
