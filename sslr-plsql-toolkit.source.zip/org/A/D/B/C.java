// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D.B;

import org.A.D.U;
import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class C implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 2) {
            return A(list.get(0), list.get(1), p2.D());
        }
        throw new K("ends-with() requires two arguments.");
    }
    
    public static Boolean A(final Object o, final Object o2, final E e) {
        return U.J(o, e).endsWith(U.J(o2, e)) ? Boolean.TRUE : Boolean.FALSE;
    }
}
