// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D.B;

import org.A.D.U;
import java.util.Locale;
import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;

public class B extends A
{
    public Object A(final P p2, final List list) throws K {
        final E d = p2.D();
        final int size = list.size();
        if (size > 0) {
            final Object value = list.get(0);
            Locale a = null;
            if (size > 1) {
                a = this.A(list.get(1), d);
            }
            return A(value, a, d);
        }
        throw new K("upper-case() requires at least one argument.");
    }
    
    public static String A(final Object o, Locale english, final E e) {
        final String j = U.J(o, e);
        if (english == null) {
            english = Locale.ENGLISH;
        }
        return j.toUpperCase(english);
    }
}
