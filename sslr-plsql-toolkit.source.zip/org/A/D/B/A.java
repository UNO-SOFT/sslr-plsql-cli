// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D.B;

import java.util.StringTokenizer;
import org.A.D.U;
import java.util.List;
import java.util.Locale;
import org.A.E;
import org.A.H;

public abstract class A implements H
{
    protected Locale A(final Object o, final E e) {
        if (o instanceof Locale) {
            return (Locale)o;
        }
        if (o instanceof List) {
            final List list = (List)o;
            if (!list.isEmpty()) {
                return this.A(list.get(0), e);
            }
        }
        else {
            final String j = U.J(o, e);
            if (j != null && j.length() > 0) {
                return this.B(j);
            }
        }
        return null;
    }
    
    protected Locale B(final String str) {
        final StringTokenizer stringTokenizer = new StringTokenizer(str, "-");
        if (!stringTokenizer.hasMoreTokens()) {
            return null;
        }
        final String nextToken = stringTokenizer.nextToken();
        if (!stringTokenizer.hasMoreTokens()) {
            return this.A(nextToken);
        }
        final String nextToken2 = stringTokenizer.nextToken();
        if (!stringTokenizer.hasMoreTokens()) {
            return new Locale(nextToken, nextToken2);
        }
        return new Locale(nextToken, nextToken2, stringTokenizer.nextToken());
    }
    
    protected Locale A(final String s) {
        final Locale[] availableLocales = Locale.getAvailableLocales();
        for (int i = 0; i < availableLocales.length; ++i) {
            final Locale locale = availableLocales[i];
            if (s.equals(locale.getLanguage())) {
                final String country = locale.getCountry();
                if (country == null || country.length() == 0) {
                    final String variant = locale.getVariant();
                    if (variant == null || variant.length() == 0) {
                        return locale;
                    }
                }
            }
        }
        return null;
    }
}
