// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D.B;

import org.A.V;
import org.A.F.D;
import org.A.D.U;
import java.util.Collections;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class E implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 1) {
            return A(p2, list.get(0));
        }
        throw new K("evaluate() requires one argument");
    }
    
    public static List A(final P p2, final Object o) throws K {
        if (p2.F().size() == 0) {
            return Collections.EMPTY_LIST;
        }
        final org.A.E d = p2.D();
        String j;
        if (o instanceof String) {
            j = (String)o;
        }
        else {
            j = U.J(o, d);
        }
        try {
            final org.A.D xPath = d.parseXPath(j);
            final V c = p2.C();
            xPath.A(c.A());
            xPath.A(c.C());
            xPath.A(c.B());
            return xPath.C(p2.E());
        }
        catch (final D d2) {
            throw new K(d2.toString());
        }
    }
}
