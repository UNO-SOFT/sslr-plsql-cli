// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import java.util.Iterator;
import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class _ implements H
{
    private static final Double D;
    
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 1) {
            return K(list.get(0), p2.D());
        }
        if (list.size() == 0) {
            return K(p2.F(), p2.D());
        }
        throw new K("number() takes at most one argument.");
    }
    
    public static Double K(final Object o, final E e) {
        if (o instanceof Double) {
            return (Double)o;
        }
        if (o instanceof String) {
            final String s = (String)o;
            try {
                return new Double(s);
            }
            catch (final NumberFormatException ex) {
                return _.D;
            }
        }
        if (o instanceof List || o instanceof Iterator) {
            return K(U.J(o, e), e);
        }
        if (e.isElement(o) || e.isAttribute(o) || e.isText(o) || e.isComment(o) || e.isProcessingInstruction(o) || e.isDocument(o) || e.isNamespace(o)) {
            return K(U.J(o, e), e);
        }
        if (!(o instanceof Boolean)) {
            return _.D;
        }
        if (o == Boolean.TRUE) {
            return new Double(1.0);
        }
        return new Double(0.0);
    }
    
    public static boolean B(final double v) {
        return Double.isNaN(v);
    }
    
    public static boolean A(final Double n) {
        return n.equals(_.D);
    }
    
    static {
        D = new Double(Double.NaN);
    }
}
