// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class F implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 1) {
            return D(list.get(0), p2.D());
        }
        throw new K("ceiling() requires one argument.");
    }
    
    public static Double D(final Object o, final E e) {
        return new Double(Math.ceil(_.K(o, e)));
    }
}
