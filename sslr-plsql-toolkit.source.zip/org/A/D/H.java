// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;

public class H implements org.A.H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 1) {
            return F(list.get(0), p2.D());
        }
        throw new K("round() requires one argument.");
    }
    
    public static Double F(final Object o, final E e) {
        final Double k = _.K(o, e);
        if (k.isNaN() || k.isInfinite()) {
            return k;
        }
        return new Double((double)Math.round(k));
    }
}
