// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Collections;
import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class Q implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 1) {
            return B(p2.F(), list.get(0), p2.D());
        }
        throw new K("id() requires one argument");
    }
    
    public static List B(final List list, final Object o, final E e) {
        if (list.size() == 0) {
            return Collections.EMPTY_LIST;
        }
        final ArrayList list2 = new ArrayList();
        final Object value = list.get(0);
        if (o instanceof List) {
            final Iterator iterator = ((List)o).iterator();
            while (iterator.hasNext()) {
                list2.addAll(B(list, U.J(iterator.next(), e), e));
            }
        }
        else {
            final StringTokenizer stringTokenizer = new StringTokenizer(U.J(o, e), " \t\n\r");
            while (stringTokenizer.hasMoreTokens()) {
                final Object elementById = e.getElementById(value, stringTokenizer.nextToken());
                if (elementById != null) {
                    list2.add(elementById);
                }
            }
        }
        return list2;
    }
}
