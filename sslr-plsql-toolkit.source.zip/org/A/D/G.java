// 
// Decompiled by Procyon v0.6.0
// 

package org.A.D;

import org.A.E;
import org.A.K;
import java.util.List;
import org.A.P;
import org.A.H;

public class G implements H
{
    public Object A(final P p2, final List list) throws K {
        if (list.size() == 0) {
            return E(p2.F(), p2.D());
        }
        if (list.size() == 1) {
            return E(list.get(0), p2.D());
        }
        throw new K("string-length() requires one argument.");
    }
    
    public static Double E(final Object o, final E e) throws K {
        final String j = U.J(o, e);
        final char[] charArray = j.toCharArray();
        int n = 0;
        for (int i = 0; i < charArray.length; ++i) {
            final char c = charArray[i];
            ++n;
            if (c >= '\ud800' && c <= '\udfff') {
                try {
                    final char c2 = charArray[i + 1];
                    if (c2 < '\udc00' || c2 > '\udfff') {
                        throw new K("Bad surrogate pair in string " + j);
                    }
                    ++i;
                }
                catch (final ArrayIndexOutOfBoundsException ex) {
                    throw new K("Bad surrogate pair in string " + j);
                }
            }
        }
        return new Double(n);
    }
}
