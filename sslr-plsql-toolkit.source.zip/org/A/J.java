// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import java.util.Iterator;

public interface J extends E
{
    Iterator A(final Object p0, final String p1, final String p2, final String p3) throws X;
    
    Iterator B(final Object p0, final String p1, final String p2, final String p3) throws X;
}
