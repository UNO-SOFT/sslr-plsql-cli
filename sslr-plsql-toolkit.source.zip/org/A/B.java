// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import org.A.F.F;

public class B extends S
{
    private static final long M = 1980601567207604059L;
    private String L;
    private int K;
    
    public B(final F f) {
        super(f);
        this.L = f.B();
        this.K = f.D();
    }
    
    public B(final String l, final int k, final String s) {
        super(s);
        this.L = l;
        this.K = k;
    }
    
    public int H() {
        return this.K;
    }
    
    public String F() {
        return this.L;
    }
    
    public String G() {
        final StringBuffer sb = new StringBuffer();
        for (int h = this.H(), i = 0; i < h; ++i) {
            sb.append(" ");
        }
        sb.append("^");
        return sb.toString();
    }
    
    public String E() {
        final StringBuffer sb = new StringBuffer(this.getMessage());
        sb.append("\n");
        sb.append(this.F());
        sb.append("\n");
        sb.append(this.G());
        return sb.toString();
    }
}
