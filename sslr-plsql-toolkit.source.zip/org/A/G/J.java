// 
// Decompiled by Procyon v0.6.0
// 

package org.A.G;

import org.A.P;

public class J extends B
{
    public static final J b;
    
    public boolean A(final Object o, final P p2) {
        return p2.D().isText(o);
    }
    
    public double F() {
        return -0.5;
    }
    
    public short D() {
        return 3;
    }
    
    public String B() {
        return "text()";
    }
    
    static {
        b = new J();
    }
}
