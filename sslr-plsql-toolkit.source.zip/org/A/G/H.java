// 
// Decompiled by Procyon v0.6.0
// 

package org.A.G;

import java.util.Iterator;
import org.A.E.E;
import org.A.P;
import org.A.S;
import java.util.ArrayList;
import org.A.J.r;
import java.util.List;

public class H extends G
{
    private B V;
    private G T;
    private G S;
    private List U;
    private boolean W;
    
    public H() {
        this.V = org.A.G.K.M();
    }
    
    public H(final B v) {
        this.V = org.A.G.K.M();
        this.V = v;
    }
    
    public G C() {
        if (this.T != null) {
            this.T = this.T.C();
        }
        if (this.S != null) {
            this.S = this.S.C();
        }
        if (this.U == null) {
            if (this.T == null && this.S == null) {
                return this.V;
            }
            if (this.T != null && this.S == null && this.V instanceof K) {
                return this.T;
            }
        }
        return this;
    }
    
    public void A(final r r) {
        if (this.U == null) {
            this.U = new ArrayList();
        }
        this.U.add(r);
    }
    
    public void D(final G t) {
        this.T = t;
    }
    
    public void C(final G s) {
        this.S = s;
    }
    
    public void A(final B b) throws S {
        if (this.V instanceof K) {
            this.V = b;
            return;
        }
        throw new S("Attempt to overwrite nodeTest: " + this.V + " with: " + b);
    }
    
    public boolean A(final Object o, final P p2) throws S {
        final org.A.E d = p2.D();
        if (!this.V.A(o, p2)) {
            return false;
        }
        if (this.T != null) {
            final Object parentNode = d.getParentNode(o);
            if (parentNode == null) {
                return false;
            }
            if (!this.T.A(parentNode, p2)) {
                return false;
            }
        }
        if (this.S != null) {
            for (Object o2 = d.getParentNode(o); !this.S.A(o2, p2); o2 = d.getParentNode(o2)) {
                if (o2 == null) {
                    return false;
                }
                if (d.isDocument(o2)) {
                    return false;
                }
            }
        }
        if (this.U != null) {
            final E e = new E(o);
            p2.A(e);
            boolean b = true;
            final Iterator iterator = this.U.iterator();
            while (iterator.hasNext()) {
                if (!((r)iterator.next()).B(p2)) {
                    b = false;
                    break;
                }
            }
            p2.A(e);
            return b;
        }
        return true;
    }
    
    public double F() {
        if (this.U != null) {
            return 0.5;
        }
        return this.V.F();
    }
    
    public short D() {
        return this.V.D();
    }
    
    public String B() {
        final StringBuffer sb = new StringBuffer();
        if (this.W) {
            sb.append("/");
        }
        if (this.S != null) {
            final String b = this.S.B();
            if (b.length() > 0) {
                sb.append(b);
                sb.append("//");
            }
        }
        if (this.T != null) {
            final String b2 = this.T.B();
            if (b2.length() > 0) {
                sb.append(b2);
                sb.append("/");
            }
        }
        sb.append(this.V.B());
        if (this.U != null) {
            sb.append("[");
            final Iterator iterator = this.U.iterator();
            while (iterator.hasNext()) {
                sb.append(((r)iterator.next()).A());
            }
            sb.append("]");
        }
        return sb.toString();
    }
    
    public String toString() {
        return super.toString() + "[ absolute: " + this.W + " parent: " + this.T + " ancestor: " + this.S + " filters: " + this.U + " nodeTest: " + this.V + " ]";
    }
    
    public boolean K() {
        return this.W;
    }
    
    public void A(final boolean w) {
        this.W = w;
    }
    
    public boolean J() {
        return this.V instanceof K;
    }
}
