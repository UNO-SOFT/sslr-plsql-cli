// 
// Decompiled by Procyon v0.6.0
// 

package org.A.G;

import org.A.P;

public class C extends B
{
    private static C X;
    
    public static C L() {
        return C.X;
    }
    
    public boolean A(final Object o, final P p2) {
        final short nodeType = p2.D().getNodeType(o);
        return nodeType == 1 || nodeType == 3 || nodeType == 8 || nodeType == 7;
    }
    
    public double F() {
        return -0.5;
    }
    
    public short D() {
        return 0;
    }
    
    public String B() {
        return "*";
    }
    
    static {
        C.X = new C();
    }
}
