// 
// Decompiled by Procyon v0.6.0
// 

package org.A.G;

import org.A.J.u;
import org.A.J.r;
import org.A.S;
import java.util.LinkedList;

public class I extends org.A.I
{
    private org.A.G.G E;
    
    public org.A.G.G k() {
        return this.E(true);
    }
    
    public org.A.G.G E(final boolean b) {
        if (b && !this.D) {
            this.E.C();
            this.D = true;
        }
        return this.E;
    }
    
    public void T() {
        this.E = (org.A.G.G)this.a();
        System.out.println("stack is: " + this.A);
        this.d();
    }
    
    public void M() {
        final LinkedList d = this.d();
        System.out.println("endPathExpr(): " + d);
        this.A(d.removeFirst());
    }
    
    public void Q() {
        this.c();
        this.A(this.m());
    }
    
    public void F() throws S {
        this.g();
    }
    
    public void N() {
        this.c();
        this.A(this.l());
    }
    
    public void D() throws S {
        this.g();
    }
    
    protected void g() throws S {
        final LinkedList d = this.d();
        System.out.println("endLocationPath: " + d);
        H h = d.removeFirst();
        this.A(h);
        int n = 0;
        while (!d.isEmpty()) {
            final Object removeFirst = d.removeFirst();
            if (removeFirst instanceof B) {
                if (n != 0) {
                    final H h2 = new H((B)removeFirst);
                    h.D(h2);
                    h = h2;
                    n = 0;
                }
                else {
                    h.A((B)removeFirst);
                }
            }
            else if (removeFirst instanceof r) {
                h.A((r)removeFirst);
            }
            else {
                if (!(removeFirst instanceof H)) {
                    continue;
                }
                final H h3 = (H)removeFirst;
                h.D(h3);
                h = h3;
                n = 0;
            }
        }
    }
    
    public void A(final int n, final String s, final String s2) {
        this.c();
        short n2 = 1;
        switch (n) {
            case 9: {
                n2 = 2;
                break;
            }
            case 10: {
                n2 = 13;
                break;
            }
        }
        if (s != null && s.length() > 0 && !s.equals("*")) {
            this.A(new F(s, n2));
        }
        if (s2 != null && s2.length() > 0 && !s2.equals("*")) {
            this.A(new E(s2, n2));
        }
    }
    
    public void C(final int n) {
        this.c();
        this.A(new M((short)3));
    }
    
    public void B(final int n) {
        this.c();
        this.A(new M((short)8));
    }
    
    public void E(final int n) {
        this.c();
        this.A(K.M());
    }
    
    public void A(final int n, final String s) {
        this.c();
        this.A(new M((short)7));
    }
    
    protected void b() {
        final LinkedList d = this.d();
        if (!d.isEmpty()) {
            this.A(d.removeFirst());
            if (!d.isEmpty()) {
                System.out.println("List should now be empty!" + d);
            }
        }
    }
    
    public void U() {
    }
    
    public void C(final boolean b) throws S {
        if (b) {
            this.A(this.f().B((u)this.a(), (u)this.a()));
        }
    }
    
    protected org.A.G.G m() {
        return new H(M.g);
    }
    
    protected org.A.G.G l() {
        return new H();
    }
}
