// 
// Decompiled by Procyon v0.6.0
// 

package org.A.G;

import org.A.S;
import org.A.P;

public class D extends G
{
    private G Q;
    private G R;
    private short P;
    private String O;
    
    public D() {
        this.P = 0;
        this.O = null;
    }
    
    public D(final G q, final G r) {
        this.P = 0;
        this.O = null;
        this.Q = q;
        this.R = r;
        this.I();
    }
    
    public G G() {
        return this.Q;
    }
    
    public void B(final G q) {
        this.Q = q;
        this.I();
    }
    
    public G H() {
        return this.R;
    }
    
    public void A(final G r) {
        this.R = r;
        this.I();
    }
    
    public boolean A(final Object o, final P p2) throws S {
        return this.Q.A(o, p2) || this.R.A(o, p2);
    }
    
    public G[] E() {
        return new G[] { this.Q, this.R };
    }
    
    public short D() {
        return this.P;
    }
    
    public String A() {
        return this.O;
    }
    
    public G C() {
        this.Q = this.Q.C();
        this.R = this.R.C();
        this.I();
        return this;
    }
    
    public String B() {
        return this.Q.B() + " | " + this.R.B();
    }
    
    public String toString() {
        return super.toString() + "[ lhs: " + this.Q + " rhs: " + this.R + " ]";
    }
    
    private void I() {
        final short d = this.Q.D();
        this.P = (short)((d == this.R.D()) ? d : false);
        final String a = this.Q.A();
        final String a2 = this.R.A();
        this.O = null;
        if (a != null && a2 != null && a.equals(a2)) {
            this.O = a;
        }
    }
}
