// 
// Decompiled by Procyon v0.6.0
// 

package org.A.G;

import org.A.P;

public class M extends B
{
    public static final M g;
    public static final M h;
    public static final M k;
    public static final M e;
    public static final M i;
    public static final M j;
    public static final M f;
    private short d;
    
    public M(final short d) {
        this.d = d;
    }
    
    public boolean A(final Object o, final P p2) {
        return this.d == p2.D().getNodeType(o);
    }
    
    public double F() {
        return -0.5;
    }
    
    public short D() {
        return this.d;
    }
    
    public String B() {
        switch (this.d) {
            case 1: {
                return "child()";
            }
            case 2: {
                return "@*";
            }
            case 13: {
                return "namespace()";
            }
            case 9: {
                return "/";
            }
            case 8: {
                return "comment()";
            }
            case 3: {
                return "text()";
            }
            case 7: {
                return "processing-instruction()";
            }
            default: {
                return "";
            }
        }
    }
    
    public String toString() {
        return super.toString() + "[ type: " + this.d + " ]";
    }
    
    static {
        g = new M((short)9);
        h = new M((short)1);
        k = new M((short)2);
        e = new M((short)8);
        i = new M((short)3);
        j = new M((short)7);
        f = new M((short)13);
    }
}
