// 
// Decompiled by Procyon v0.6.0
// 

package org.A.G;

import java.util.Iterator;
import org.A.J.q;
import org.A.J.g;
import org.A.J._;
import org.A.J.R;
import org.A.J.$A;
import org.A.J.MA;
import java.util.ListIterator;
import java.util.List;
import org.A.J.i;
import org.A.J.Q;
import org.A.J.LA;
import org.A.J.NA;
import org.A.J.r;
import org.A.J.h;
import org.A.J.u;
import org.A.F.D;
import org.A.S;
import org.A.J.e;
import org.A.J.M;
import org.A.I;
import org.A.F.A.A;

public class L
{
    private static final boolean B = false;
    private static final boolean A = false;
    
    public static G A(final String s) throws S, D {
        final org.A.F.A a = org.A.F.A.A.A();
        final I i = new I();
        i.A(new M());
        a.A(i);
        a.A(s);
        return A(i.i().C()).C();
    }
    
    protected static G A(final u u) throws S {
        if (u instanceof h) {
            return A((h)u);
        }
        if (u instanceof r) {
            final H h = new H();
            h.A((r)u);
            return h;
        }
        if (u instanceof NA) {
            final NA na = (NA)u;
            return new org.A.G.D(A(na.X()), A(na.Y()));
        }
        final H h2 = new H();
        h2.A(new Q(u, new LA()));
        return h2;
    }
    
    protected static H A(final h h) throws S {
        final H h2 = new H();
        final List h3 = h.H();
        H h4 = h2;
        int n = 1;
        final ListIterator listIterator = h3.listIterator(h3.size());
        while (listIterator.hasPrevious()) {
            final i i = (i)listIterator.previous();
            if (n != 0) {
                n = 0;
                h4 = A(h4, i);
            }
            else {
                if (A(i)) {
                    final H h5 = new H();
                    final int p = i.P();
                    if (p == 2 || p == 12) {
                        h4.C(h5);
                    }
                    else {
                        h4.D(h5);
                    }
                    h4 = h5;
                }
                h4 = A(h4, i);
            }
        }
        if (h.I()) {
            h4.D(new H(org.A.G.M.g));
        }
        return h2;
    }
    
    protected static H A(final H h, final i obj) throws S {
        if (obj instanceof MA) {
            if (obj.P() == 9) {
                h.A(org.A.G.M.k);
            }
            else {
                h.A(org.A.G.M.h);
            }
        }
        else if (obj instanceof $A) {
            h.A(org.A.G.M.e);
        }
        else if (obj instanceof org.A.J.I) {
            h.A(org.A.G.M.j);
        }
        else if (obj instanceof R) {
            h.A(J.b);
        }
        else if (obj instanceof $A) {
            h.A(org.A.G.M.e);
        }
        else {
            if (obj instanceof _) {
                final _ _ = (_)obj;
                final String t = _.T();
                final String u = _.U();
                final int p2 = _.P();
                short n = 1;
                if (p2 == 9) {
                    n = 2;
                }
                if (_.V()) {
                    if (u.length() == 0 || u.equals("*")) {
                        if (p2 == 9) {
                            h.A(org.A.G.M.k);
                        }
                        else {
                            h.A(org.A.G.M.h);
                        }
                    }
                    else {
                        h.A(new F(u, n));
                    }
                }
                else {
                    h.A(new E(t, n));
                }
                return A(h, _);
            }
            if (obj instanceof g) {
                return A(h, (g)obj);
            }
            throw new S("Cannot convert: " + obj + " to a Pattern");
        }
        return h;
    }
    
    protected static H A(final H h, final g g) throws S {
        final List k = g.K();
        if (!k.isEmpty()) {
            final Q q = new Q(new LA());
            final Iterator iterator = k.iterator();
            while (iterator.hasNext()) {
                q.A((q)iterator.next());
            }
            h.A(q);
        }
        return h;
    }
    
    protected static boolean A(final i i) {
        return i instanceof _ || !i.getClass().equals(g.class) || !i.K().isEmpty();
    }
}
