// 
// Decompiled by Procyon v0.6.0
// 

package org.A.G;

import org.A.E;
import org.A.P;

public class F extends B
{
    private String a;
    private short _;
    
    public F(String a, final short _) {
        if (a == null) {
            a = "";
        }
        this.a = a;
        this._ = _;
    }
    
    public boolean A(final Object o, final P p2) {
        final E d = p2.D();
        final String b = this.B(o, p2);
        if (this._ == 1) {
            return d.isElement(o) && b.equals(d.getElementNamespaceUri(o));
        }
        return this._ == 2 && d.isAttribute(o) && b.equals(d.getAttributeNamespaceUri(o));
    }
    
    public double F() {
        return -0.25;
    }
    
    public short D() {
        return this._;
    }
    
    public String B() {
        return this.a + ":";
    }
    
    public String toString() {
        return super.toString() + "[ prefix: " + this.a + " type: " + this._ + " ]";
    }
    
    protected String B(final Object o, final P p2) {
        String s = p2.D().translateNamespacePrefixToUri(this.a, o);
        if (s == null) {
            s = p2.C().A(this.a);
        }
        if (s == null) {
            s = "";
        }
        return s;
    }
}
