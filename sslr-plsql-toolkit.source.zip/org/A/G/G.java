// 
// Decompiled by Procyon v0.6.0
// 

package org.A.G;

import org.A.S;
import org.A.P;

public abstract class G
{
    public static final short E = 1;
    public static final short N = 2;
    public static final short C = 3;
    public static final short J = 4;
    public static final short L = 5;
    public static final short F = 7;
    public static final short A = 8;
    public static final short G = 9;
    public static final short D = 10;
    public static final short K = 13;
    public static final short B = 14;
    public static final short I = 14;
    public static final short M = 0;
    public static final short H = 14;
    
    public abstract boolean A(final Object p0, final P p1) throws S;
    
    public double F() {
        return 0.5;
    }
    
    public G[] E() {
        return null;
    }
    
    public short D() {
        return 0;
    }
    
    public String A() {
        return null;
    }
    
    public G C() {
        return this;
    }
    
    public abstract String B();
}
