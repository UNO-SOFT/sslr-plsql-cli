// 
// Decompiled by Procyon v0.6.0
// 

package org.A.G;

public abstract class B extends G
{
}
