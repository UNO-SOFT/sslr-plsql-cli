// 
// Decompiled by Procyon v0.6.0
// 

package org.A.G;

import org.A.P;

public class E extends B
{
    private String Z;
    private short Y;
    
    public E(final String z, final short y) {
        this.Z = z;
        this.Y = y;
    }
    
    public boolean A(final Object o, final P p2) {
        final org.A.E d = p2.D();
        if (this.Y == 1) {
            return d.isElement(o) && this.Z.equals(d.getElementName(o));
        }
        if (this.Y == 2) {
            return d.isAttribute(o) && this.Z.equals(d.getAttributeName(o));
        }
        if (d.isElement(o)) {
            return this.Z.equals(d.getElementName(o));
        }
        return d.isAttribute(o) && this.Z.equals(d.getAttributeName(o));
    }
    
    public double F() {
        return 0.0;
    }
    
    public short D() {
        return this.Y;
    }
    
    public String B() {
        if (this.Y == 2) {
            return "@" + this.Z;
        }
        return this.Z;
    }
    
    public String toString() {
        return super.toString() + "[ name: " + this.Z + " type: " + this.Y + " ]";
    }
}
