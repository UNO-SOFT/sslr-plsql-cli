// 
// Decompiled by Procyon v0.6.0
// 

package org.A.G;

import org.A.P;

public class K extends B
{
    private static K c;
    
    public static K M() {
        return K.c;
    }
    
    private K() {
    }
    
    public boolean A(final Object o, final P p2) {
        return true;
    }
    
    public double F() {
        return -0.5;
    }
    
    public short D() {
        return 0;
    }
    
    public String B() {
        return "*";
    }
    
    static {
        K.c = new K();
    }
}
