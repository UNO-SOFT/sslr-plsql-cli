// 
// Decompiled by Procyon v0.6.0
// 

package org.A.G;

import org.A.P;

public class A extends B
{
    private static A l;
    
    public static A N() {
        return A.l;
    }
    
    public boolean A(final Object o, final P p2) {
        return false;
    }
    
    public double F() {
        return -0.5;
    }
    
    public short D() {
        return 14;
    }
    
    public String B() {
        return "";
    }
    
    static {
        A.l = new A();
    }
}
