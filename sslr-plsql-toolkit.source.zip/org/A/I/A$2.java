// 
// Decompiled by Procyon v0.6.0
// 

package org.A.I;

import nu.xom.ParentNode;

class A$2 extends _A {
    public Object A(final Object o, final int n) {
        return ((ParentNode)o).getChild(n);
    }
}