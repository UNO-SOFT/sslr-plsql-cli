// 
// Decompiled by Procyon v0.6.0
// 

package org.A.I;

import java.util.Iterator;

private abstract static class _A implements Iterator
{
    private Object B;
    private int C;
    private int A;
    
    public _A(final Object b, final int c, final int a) {
        this.B = null;
        this.C = 0;
        this.A = -1;
        this.B = b;
        this.C = c;
        this.A = a;
    }
    
    public boolean hasNext() {
        return this.C < this.A;
    }
    
    public abstract Object A(final Object p0, final int p1);
    
    public Object next() {
        return this.A(this.B, this.C++);
    }
    
    public void remove() {
        throw new UnsupportedOperationException();
    }
}
