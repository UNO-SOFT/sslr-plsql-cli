// 
// Decompiled by Procyon v0.6.0
// 

package org.A.I;

import nu.xom.Element;

class A$1 extends _A {
    public Object A(final Object o, final int n) {
        return ((Element)o).getAttribute(n);
    }
}