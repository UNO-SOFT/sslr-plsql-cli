// 
// Decompiled by Procyon v0.6.0
// 

package org.A.I;

import org.A.S;
import org.A.E;
import org.A.F;

public class B extends F
{
    private static final long I = -5332108546921857671L;
    
    public B(final String s) throws S {
        super(s, new A());
    }
}
