// 
// Decompiled by Procyon v0.6.0
// 

package org.A.I;

import java.util.HashMap;
import java.util.Map;
import org.A.E;
import org.A.D;
import org.A.X;
import org.A.E.F;
import org.A.M;
import java.util.Iterator;
import nu.xom.ParentNode;
import org.A.K;
import nu.xom.Builder;
import nu.xom.NodeFactory;
import nu.xom.Node;
import nu.xom.Text;
import nu.xom.ProcessingInstruction;
import nu.xom.Element;
import nu.xom.Document;
import nu.xom.Comment;
import nu.xom.Attribute;
import org.A.L;

public class A extends L
{
    private static final long G = 3159311338575942877L;
    
    public boolean isAttribute(final Object o) {
        return o instanceof Attribute;
    }
    
    public boolean isComment(final Object o) {
        return o instanceof Comment;
    }
    
    public boolean isDocument(final Object o) {
        return o instanceof Document;
    }
    
    public boolean isElement(final Object o) {
        return o instanceof Element;
    }
    
    public boolean isNamespace(final Object o) {
        return o instanceof _B;
    }
    
    public boolean isProcessingInstruction(final Object o) {
        return o instanceof ProcessingInstruction;
    }
    
    public boolean isText(final Object o) {
        return o instanceof Text;
    }
    
    public String getAttributeName(final Object o) {
        return this.isAttribute(o) ? ((Attribute)o).getLocalName() : null;
    }
    
    public String getAttributeNamespaceUri(final Object o) {
        return this.isAttribute(o) ? ((Attribute)o).getNamespaceURI() : null;
    }
    
    public String getAttributeQName(final Object o) {
        return this.isAttribute(o) ? ((Attribute)o).getQualifiedName() : null;
    }
    
    public String getAttributeStringValue(final Object o) {
        return this.isAttribute(o) ? ((Attribute)o).getValue() : null;
    }
    
    public String getCommentStringValue(final Object o) {
        return this.isComment(o) ? ((Comment)o).getValue() : null;
    }
    
    public String getElementName(final Object o) {
        return this.isElement(o) ? ((Element)o).getLocalName() : null;
    }
    
    public String getElementNamespaceUri(final Object o) {
        return this.isElement(o) ? ((Element)o).getNamespaceURI() : null;
    }
    
    public String getElementQName(final Object o) {
        return this.isElement(o) ? ((Element)o).getQualifiedName() : null;
    }
    
    public String getElementStringValue(final Object o) {
        return (o instanceof Node) ? ((Node)o).getValue() : null;
    }
    
    public String getNamespacePrefix(final Object o) {
        if (this.isElement(o)) {
            return ((Element)o).getNamespacePrefix();
        }
        if (this.isAttribute(o)) {
            return ((Attribute)o).getNamespacePrefix();
        }
        if (o instanceof _B) {
            return ((_B)o).A();
        }
        return null;
    }
    
    public String getNamespaceStringValue(final Object o) {
        if (this.isElement(o)) {
            return ((Element)o).getNamespaceURI();
        }
        if (this.isAttribute(o)) {
            return ((Attribute)o).getNamespaceURI();
        }
        if (o instanceof _B) {
            return ((_B)o).C();
        }
        return null;
    }
    
    public String getTextStringValue(final Object o) {
        return (o instanceof Text) ? ((Text)o).getValue() : null;
    }
    
    public Object getDocument(final String s) throws K {
        try {
            return new Builder(new NodeFactory()).build(s);
        }
        catch (final Exception ex) {
            throw new K(ex);
        }
    }
    
    public Object getDocumentNode(final Object o) {
        ParentNode parent = null;
        if (o instanceof ParentNode) {
            parent = (ParentNode)o;
        }
        else if (o instanceof Node) {
            parent = ((Node)o).getParent();
        }
        return parent.getDocument();
    }
    
    public Iterator getAttributeAxisIterator(final Object o) {
        if (this.isElement(o)) {
            return new _A(o, 0, ((Element)o).getAttributeCount()) {
                public Object A(final Object o, final int n) {
                    return ((Element)o).getAttribute(n);
                }
            };
        }
        return M.B;
    }
    
    public Iterator getChildAxisIterator(final Object o) {
        if (this.isElement(o) || o instanceof Document) {
            return new _A(o, 0, ((ParentNode)o).getChildCount()) {
                public Object A(final Object o, final int n) {
                    return ((ParentNode)o).getChild(n);
                }
            };
        }
        return M.B;
    }
    
    public Iterator getParentAxisIterator(final Object o) {
        Object o2 = null;
        if (o instanceof Node) {
            o2 = ((Node)o).getParent();
        }
        else if (this.isNamespace(o)) {
            o2 = ((_B)o).B();
        }
        return (o2 != null) ? new F(o2) : null;
    }
    
    public Object getParentNode(final Object o) {
        return (o instanceof Node) ? ((Node)o).getParent() : null;
    }
    
    public Iterator getPrecedingAxisIterator(final Object o) throws X {
        return super.getPrecedingAxisIterator(o);
    }
    
    public Iterator getPrecedingSiblingAxisIterator(final Object o) throws X {
        return super.getPrecedingSiblingAxisIterator(o);
    }
    
    public String getProcessingInstructionData(final Object o) {
        return (o instanceof ProcessingInstruction) ? ((ProcessingInstruction)o).getValue() : null;
    }
    
    public String getProcessingInstructionTarget(final Object o) {
        return (o instanceof ProcessingInstruction) ? ((ProcessingInstruction)o).getTarget() : null;
    }
    
    public String translateNamespacePrefixToUri(final String s, final Object o) {
        Element b = null;
        if (o instanceof Element) {
            b = (Element)o;
        }
        else if (!(o instanceof ParentNode)) {
            if (o instanceof Node) {
                b = (Element)((Node)o).getParent();
            }
            else if (o instanceof _B) {
                b = ((_B)o).B();
            }
        }
        if (b != null) {
            return b.getNamespaceURI(s);
        }
        return null;
    }
    
    public D parseXPath(final String s) throws org.A.F.D {
        return new org.A.F(s, this);
    }
    
    private boolean A(final Element element, final String s, final String s2, final Map map) {
        if (s != null && s.length() > 0 && !map.containsKey(s2)) {
            map.put(s2, new _B(element, s, s2));
            return true;
        }
        return false;
    }
    
    public Iterator getNamespaceAxisIterator(final Object o) {
        if (!this.isElement(o)) {
            return M.B;
        }
        final HashMap hashMap = new HashMap();
        ParentNode parent;
        Object o2;
        for (o2 = (parent = (ParentNode)o); parent instanceof Element; parent = ((Element)o2).getParent()) {
            o2 = parent;
            this.A((Element)o2, ((Element)o2).getNamespaceURI(), ((Element)o2).getNamespacePrefix(), hashMap);
            for (int namespaceDeclarationCount = ((Element)o2).getNamespaceDeclarationCount(), i = 0; i < namespaceDeclarationCount; ++i) {
                final String namespacePrefix = ((Element)o2).getNamespacePrefix(i);
                this.A((Element)o2, ((Element)o2).getNamespaceURI(namespacePrefix), namespacePrefix, hashMap);
            }
        }
        this.A((Element)o2, "http://www.w3.org/XML/1998/namespace", "xml", hashMap);
        return hashMap.values().iterator();
    }
    
    private static class _B
    {
        private Element A;
        private String B;
        private String C;
        
        public _B(final Element a, final String b, final String c) {
            this.A = a;
            this.B = b;
            this.C = c;
        }
        
        public Element B() {
            return this.A;
        }
        
        public String C() {
            return this.B;
        }
        
        public String A() {
            return this.C;
        }
        
        public String toString() {
            return "[xmlns:" + this.C + "=\"" + this.B + "\", element=" + this.A.getLocalName() + "]";
        }
    }
    
    private abstract static class _A implements Iterator
    {
        private Object B;
        private int C;
        private int A;
        
        public _A(final Object b, final int c, final int a) {
            this.B = null;
            this.C = 0;
            this.A = -1;
            this.B = b;
            this.C = c;
            this.A = a;
        }
        
        public boolean hasNext() {
            return this.C < this.A;
        }
        
        public abstract Object A(final Object p0, final int p1);
        
        public Object next() {
            return this.A(this.B, this.C++);
        }
        
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}
