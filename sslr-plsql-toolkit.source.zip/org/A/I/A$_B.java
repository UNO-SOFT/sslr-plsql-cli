// 
// Decompiled by Procyon v0.6.0
// 

package org.A.I;

import nu.xom.Element;

private static class _B
{
    private Element A;
    private String B;
    private String C;
    
    public _B(final Element a, final String b, final String c) {
        this.A = a;
        this.B = b;
        this.C = c;
    }
    
    public Element B() {
        return this.A;
    }
    
    public String C() {
        return this.B;
    }
    
    public String A() {
        return this.C;
    }
    
    public String toString() {
        return "[xmlns:" + this.C + "=\"" + this.B + "\", element=" + this.A.getLocalName() + "]";
    }
}
