// 
// Decompiled by Procyon v0.6.0
// 

package org.A;

import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.io.Serializable;

public class R implements O, Serializable
{
    private static final long B = -808928409643497762L;
    private Map A;
    
    public R() {
        this.A = new HashMap();
    }
    
    public R(final Map m) {
        final Iterator iterator = m.entrySet().iterator();
        while (iterator.hasNext()) {
            final Map.Entry entry = (Map.Entry)iterator.next();
            if (!(entry.getKey() instanceof String) || !(entry.getValue() instanceof String)) {
                throw new ClassCastException("Non-string namespace binding");
            }
        }
        this.A = new HashMap(m);
    }
    
    public void A(final E e, final Object o) throws X {
        final Iterator namespaceAxisIterator = e.getNamespaceAxisIterator(o);
        while (namespaceAxisIterator.hasNext()) {
            final Object next = namespaceAxisIterator.next();
            final String namespacePrefix = e.getNamespacePrefix(next);
            final String namespaceStringValue = e.getNamespaceStringValue(next);
            if (this.A(namespacePrefix) == null) {
                this.A(namespacePrefix, namespaceStringValue);
            }
        }
    }
    
    public void A(final String s, final String s2) {
        this.A.put(s, s2);
    }
    
    public String A(final String s) {
        if (this.A.containsKey(s)) {
            return this.A.get(s);
        }
        return null;
    }
}
