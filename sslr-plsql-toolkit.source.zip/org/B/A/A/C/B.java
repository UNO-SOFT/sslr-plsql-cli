// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.C;

import java.io.IOException;

@FunctionalInterface
public interface B<T>
{
    T A() throws IOException;
}
