// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.C;

import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.function.Function;
import java.util.Objects;
import java.io.IOException;

@FunctionalInterface
public interface C<T, R>
{
    R B(final T p0) throws IOException;
    
    default <V> C<V, R> B(final C<? super V, ? extends T> obj) {
        Objects.requireNonNull(obj, "before");
        return (C<V, R>)(o -> this.B(c.B(o)));
    }
    
    default <V> C<V, R> A(final Function<? super V, ? extends T> obj) {
        Objects.requireNonNull(obj, "before");
        return (C<V, R>)(o -> this.B(function.apply(o)));
    }
    
    default B<R> B(final B<? extends T> obj) {
        Objects.requireNonNull(obj, "before");
        return (B<R>)(() -> this.B(b.A()));
    }
    
    default B<R> B(final Supplier<? extends T> obj) {
        Objects.requireNonNull(obj, "before");
        return (B<R>)(() -> this.B(supplier.get()));
    }
    
    default <V> C<T, V> A(final C<? super R, ? extends V> obj) {
        Objects.requireNonNull(obj, "after");
        return o -> c.B(this.B(o));
    }
    
    default <V> C<T, V> B(final Function<? super R, ? extends V> obj) {
        Objects.requireNonNull(obj, "after");
        return o -> function.apply(this.B(o));
    }
    
    default A<T> A(final A<? super R> obj) {
        Objects.requireNonNull(obj, "after");
        return o -> a.B(this.B(o));
    }
    
    default A<T> A(final Consumer<? super R> obj) {
        Objects.requireNonNull(obj, "after");
        return o -> consumer.accept(this.B(o));
    }
    
    default <T> C<T, T> A() {
        return (C<T, T>)(o -> o);
    }
}
