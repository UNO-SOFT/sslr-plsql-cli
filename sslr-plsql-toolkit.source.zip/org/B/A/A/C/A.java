// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.C;

import java.util.Objects;
import java.io.IOException;

@FunctionalInterface
public interface A<T>
{
    public static final A<?> A = p0 -> {};
    
    default <T> A<T> A() {
        return (A<T>)org.B.A.A.C.A.A;
    }
    
    void B(final T p0) throws IOException;
    
    default A<T> A(final A<? super T> obj) {
        Objects.requireNonNull(obj, "after");
        return o -> {
            this.B(o);
            a.B(o);
        };
    }
}
