// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.InputStream;

public class G extends F
{
    public static G A(final InputStream inputStream) {
        return new G(inputStream);
    }
    
    @Deprecated
    public G(final InputStream inputStream) {
        super(inputStream);
    }
    
    @Override
    public void close() {
        this.in = P.A;
    }
}
