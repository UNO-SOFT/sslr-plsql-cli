// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.IOException;
import java.io.InputStream;

public class C extends InputStream
{
    private boolean A;
    private boolean B;
    private boolean D;
    private final InputStream E;
    private final boolean C;
    
    public C(final InputStream e, final boolean c) {
        this.E = e;
        this.C = c;
    }
    
    private int A() throws IOException {
        final int read = this.E.read();
        this.D = (read == -1);
        if (this.D) {
            return read;
        }
        this.A = (read == 10);
        this.B = (read == 13);
        return read;
    }
    
    @Override
    public int read() throws IOException {
        final boolean b = this.B;
        if (this.D) {
            return this.A(b);
        }
        final int a = this.A();
        if (this.D) {
            return this.A(b);
        }
        if (this.B) {
            return 10;
        }
        if (b && this.A) {
            return this.read();
        }
        return a;
    }
    
    private int A(final boolean b) {
        if (b || !this.C) {
            return -1;
        }
        if (!this.A) {
            this.A = true;
            return 10;
        }
        return -1;
    }
    
    @Override
    public void close() throws IOException {
        super.close();
        this.E.close();
    }
    
    @Override
    public synchronized void mark(final int n) {
        throw u.B();
    }
}
