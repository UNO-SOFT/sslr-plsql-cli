// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F.A;

import java.io.IOException;
import java.util.Objects;
import java.io.InputStream;

public class B extends C
{
    public B(final InputStream inputStream, final int n) {
        super(inputStream, n);
    }
    
    public B(final InputStream inputStream) {
        super(inputStream);
    }
    
    public boolean A(final byte[] obj) throws IOException {
        Objects.requireNonNull(obj, "sourceBuffer");
        return this.A(obj, 0, obj.length);
    }
    
    public boolean A(final byte[] obj, final int n, final int n2) throws IOException {
        Objects.requireNonNull(obj, "sourceBuffer");
        if (obj.length > this.D) {
            throw new IllegalArgumentException("Peek request size of " + obj.length + " bytes exceeds buffer size of " + this.D + " bytes");
        }
        if (this.C.A() < obj.length) {
            this.A();
        }
        return this.C.A(obj, n, n2);
    }
}
