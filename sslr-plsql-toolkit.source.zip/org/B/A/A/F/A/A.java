// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F.A;

import java.util.Objects;
import org.B.A.A.W;

public class A
{
    private final byte[] B;
    private int A;
    private int C;
    private int D;
    
    public A(final int n) {
        this.B = W.B(n);
        this.A = 0;
        this.C = 0;
        this.D = 0;
    }
    
    public A() {
        this(8192);
    }
    
    public byte F() {
        if (this.D <= 0) {
            throw new IllegalStateException("No bytes available.");
        }
        final byte b = this.B[this.A];
        --this.D;
        if (++this.A == this.B.length) {
            this.A = 0;
        }
        return b;
    }
    
    public void B(final byte[] obj, final int i, final int n) {
        Objects.requireNonNull(obj, "targetBuffer");
        if (i < 0 || i >= obj.length) {
            throw new IllegalArgumentException("Invalid offset: " + i);
        }
        if (n < 0 || n > this.B.length) {
            throw new IllegalArgumentException("Invalid length: " + n);
        }
        if (i + n > obj.length) {
            throw new IllegalArgumentException("The supplied byte array contains only " + obj.length + " bytes, but offset, and length would require " + (i + n - 1));
        }
        if (this.D < n) {
            throw new IllegalStateException("Currently, there are only " + this.D + "in the buffer, not " + n);
        }
        int n2 = i;
        for (int j = 0; j < n; ++j) {
            obj[n2++] = this.B[this.A];
            --this.D;
            if (++this.A == this.B.length) {
                this.A = 0;
            }
        }
    }
    
    public void A(final byte b) {
        if (this.D >= this.B.length) {
            throw new IllegalStateException("No space available");
        }
        this.B[this.C] = b;
        ++this.D;
        if (++this.C == this.B.length) {
            this.C = 0;
        }
    }
    
    public boolean A(final byte[] obj, final int i, final int j) {
        Objects.requireNonNull(obj, "Buffer");
        if (i < 0 || i >= obj.length) {
            throw new IllegalArgumentException("Invalid offset: " + i);
        }
        if (j < 0 || j > this.B.length) {
            throw new IllegalArgumentException("Invalid length: " + j);
        }
        if (j < this.D) {
            return false;
        }
        int a = this.A;
        for (int k = 0; k < j; ++k) {
            if (this.B[a] != obj[k + i]) {
                return false;
            }
            if (++a == this.B.length) {
                a = 0;
            }
        }
        return true;
    }
    
    public void C(final byte[] obj, final int i, final int j) {
        Objects.requireNonNull(obj, "Buffer");
        if (i < 0 || i >= obj.length) {
            throw new IllegalArgumentException("Invalid offset: " + i);
        }
        if (j < 0) {
            throw new IllegalArgumentException("Invalid length: " + j);
        }
        if (this.D + j > this.B.length) {
            throw new IllegalStateException("No space available");
        }
        for (int k = 0; k < j; ++k) {
            this.B[this.C] = obj[i + k];
            if (++this.C == this.B.length) {
                this.C = 0;
            }
        }
        this.D += j;
    }
    
    public boolean E() {
        return this.D < this.B.length;
    }
    
    public boolean A(final int n) {
        return this.D + n <= this.B.length;
    }
    
    public boolean D() {
        return this.D > 0;
    }
    
    public int C() {
        return this.B.length - this.D;
    }
    
    public int A() {
        return this.D;
    }
    
    public void B() {
        this.A = 0;
        this.C = 0;
        this.D = 0;
    }
}
