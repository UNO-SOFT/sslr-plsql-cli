// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F.A;

import java.io.IOException;
import org.B.A.A.W;
import java.util.Objects;
import java.io.InputStream;

public class C extends InputStream
{
    protected final InputStream A;
    protected final A C;
    protected final int D;
    private boolean B;
    
    public C(final InputStream obj, final int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("Invalid bufferSize: " + n);
        }
        this.A = Objects.requireNonNull(obj, "inputStream");
        this.C = new A(n);
        this.D = n;
        this.B = false;
    }
    
    public C(final InputStream inputStream) {
        this(inputStream, 8192);
    }
    
    protected void A() throws IOException {
        if (this.B) {
            return;
        }
        int i = this.C.C();
        final byte[] b = W.B(i);
        while (i > 0) {
            final int read = this.A.read(b, 0, i);
            if (read == -1) {
                this.B = true;
                return;
            }
            if (read <= 0) {
                continue;
            }
            this.C.C(b, 0, read);
            i -= read;
        }
    }
    
    protected boolean A(final int n) throws IOException {
        if (this.C.A() < n) {
            this.A();
        }
        return this.C.D();
    }
    
    @Override
    public int read() throws IOException {
        if (!this.A(1)) {
            return -1;
        }
        return this.C.F() & 0xFF;
    }
    
    @Override
    public int read(final byte[] array) throws IOException {
        return this.read(array, 0, array.length);
    }
    
    @Override
    public int read(final byte[] obj, final int n, final int a) throws IOException {
        Objects.requireNonNull(obj, "targetBuffer");
        if (n < 0) {
            throw new IllegalArgumentException("Offset must not be negative");
        }
        if (a < 0) {
            throw new IllegalArgumentException("Length must not be negative");
        }
        if (!this.A(a)) {
            return -1;
        }
        final int min = Math.min(a, this.C.A());
        for (int i = 0; i < min; ++i) {
            obj[n + i] = this.C.F();
        }
        return min;
    }
    
    @Override
    public void close() throws IOException {
        this.A.close();
        this.B = true;
        this.C.B();
    }
}
