// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.IOException;
import java.io.InputStream;

public class X extends InputStream
{
    private boolean C;
    private boolean A;
    private boolean B;
    private boolean E;
    private final InputStream F;
    private final boolean D;
    
    public X(final InputStream f, final boolean d) {
        this.F = f;
        this.D = d;
    }
    
    private int A() throws IOException {
        final int read = this.F.read();
        this.E = (read == -1);
        if (this.E) {
            return read;
        }
        this.C = (read == 13);
        this.A = (read == 10);
        return read;
    }
    
    @Override
    public int read() throws IOException {
        if (this.E) {
            return this.B();
        }
        if (this.B) {
            this.B = false;
            return 10;
        }
        final boolean c = this.C;
        final int a = this.A();
        if (this.E) {
            return this.B();
        }
        if (a == 10 && !c) {
            this.B = true;
            return 13;
        }
        return a;
    }
    
    private int B() {
        if (!this.D) {
            return -1;
        }
        if (!this.A && !this.C) {
            this.C = true;
            return 13;
        }
        if (!this.A) {
            this.C = false;
            this.A = true;
            return 10;
        }
        return -1;
    }
    
    @Override
    public void close() throws IOException {
        super.close();
        this.F.close();
    }
    
    @Override
    public synchronized void mark(final int n) {
        throw u.B();
    }
}
