// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.util.Collection;
import java.util.HashSet;
import java.util.Arrays;
import java.io.Reader;
import java.util.Collections;
import java.util.function.IntPredicate;
import java.util.Set;

public class V extends R
{
    private static IntPredicate A(final Set<Integer> s2) {
        if (s2 == null) {
            return V.B;
        }
        return i -> {
            Collections.unmodifiableSet((Set<?>)s2);
            return set.contains(i);
        };
    }
    
    public V(final Reader reader, final Integer... a) {
        this(reader, new HashSet<Integer>(Arrays.asList(a)));
    }
    
    public V(final Reader reader, final Set<Integer> set) {
        super(reader, A(set));
    }
}
