// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

public class Q extends h
{
    public Q(final byte[] array) {
        super(array, -1L);
    }
}
