// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.lang.reflect.Proxy;
import java.io.ObjectStreamClass;
import java.io.StreamCorruptedException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;

public class D extends ObjectInputStream
{
    private final ClassLoader A;
    
    public D(final ClassLoader a, final InputStream in) throws IOException, StreamCorruptedException {
        super(in);
        this.A = a;
    }
    
    @Override
    protected Class<?> resolveClass(final ObjectStreamClass desc) throws IOException, ClassNotFoundException {
        try {
            return Class.forName(desc.getName(), false, this.A);
        }
        catch (final ClassNotFoundException ex) {
            return super.resolveClass(desc);
        }
    }
    
    @Override
    protected Class<?> resolveProxyClass(final String[] interfaces) throws IOException, ClassNotFoundException {
        final Class[] interfaces2 = new Class[interfaces.length];
        for (int i = 0; i < interfaces.length; ++i) {
            interfaces2[i] = Class.forName(interfaces[i], false, this.A);
        }
        try {
            return Proxy.getProxyClass(this.A, (Class<?>[])interfaces2);
        }
        catch (final IllegalArgumentException ex) {
            return super.resolveProxyClass(interfaces);
        }
    }
}
