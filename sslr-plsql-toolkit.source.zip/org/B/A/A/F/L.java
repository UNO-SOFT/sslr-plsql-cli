// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import org.B.A.A.S;
import java.io.FileNotFoundException;
import java.io.RandomAccessFile;
import org.B.A.A.W;
import java.io.File;
import java.nio.charset.Charset;

public class L implements Runnable
{
    private static final int B = 1000;
    private static final String A = "r";
    private static final Charset J;
    private final byte[] G;
    private final File D;
    private final Charset F;
    private final long I;
    private final boolean H;
    private final v C;
    private final boolean K;
    private volatile boolean E;
    
    public L(final File file, final v v) {
        this(file, v, 1000L);
    }
    
    public L(final File file, final v v, final long n) {
        this(file, v, n, false);
    }
    
    public L(final File file, final v v, final long n, final boolean b) {
        this(file, v, n, b, 8192);
    }
    
    public L(final File file, final v v, final long n, final boolean b, final boolean b2) {
        this(file, v, n, b, b2, 8192);
    }
    
    public L(final File file, final v v, final long n, final boolean b, final int n2) {
        this(file, v, n, b, false, n2);
    }
    
    public L(final File file, final v v, final long n, final boolean b, final boolean b2, final int n2) {
        this(file, L.J, v, n, b, b2, n2);
    }
    
    public L(final File d, final Charset f, final v c, final long i, final boolean h, final boolean k, final int n) {
        this.E = true;
        this.D = d;
        this.I = i;
        this.H = h;
        this.G = W.B(n);
        (this.C = c).A(this);
        this.K = k;
        this.F = f;
    }
    
    public static L A(final File file, final v v, final long n, final boolean b, final int n2) {
        return A(file, v, n, b, false, n2);
    }
    
    public static L A(final File file, final v v, final long n, final boolean b, final boolean b2, final int n2) {
        return A(file, L.J, v, n, b, b2, n2);
    }
    
    public static L A(final File file, final Charset charset, final v v, final long n, final boolean b, final boolean b2, final int n2) {
        final L target = new L(file, charset, v, n, b, b2, n2);
        final Thread thread = new Thread(target);
        thread.setDaemon(true);
        thread.start();
        return target;
    }
    
    public static L A(final File file, final v v, final long n, final boolean b) {
        return A(file, v, n, b, 8192);
    }
    
    public static L A(final File file, final v v, final long n, final boolean b, final boolean b2) {
        return A(file, v, n, b, b2, 8192);
    }
    
    public static L A(final File file, final v v, final long n) {
        return A(file, v, n, false);
    }
    
    public static L A(final File file, final v v) {
        return A(file, v, 1000L, false);
    }
    
    public File C() {
        return this.D;
    }
    
    protected boolean A() {
        return this.E;
    }
    
    public long B() {
        return this.I;
    }
    
    @Override
    public void run() {
        RandomAccessFile randomAccessFile = null;
        try {
            long n = 0L;
            long n2 = 0L;
            while (this.A() && randomAccessFile == null) {
                try {
                    randomAccessFile = new RandomAccessFile(this.D, "r");
                }
                catch (final FileNotFoundException ex) {
                    this.C.A();
                }
                if (randomAccessFile == null) {
                    Thread.sleep(this.I);
                }
                else {
                    n2 = (this.H ? this.D.length() : 0L);
                    n = S.K(this.D);
                    randomAccessFile.seek(n2);
                }
            }
            while (this.A()) {
                final boolean b = S.B(this.D, n);
                final long length = this.D.length();
                if (length < n2) {
                    this.C.B();
                    try (final RandomAccessFile randomAccessFile2 = randomAccessFile) {
                        randomAccessFile = new RandomAccessFile(this.D, "r");
                        try {
                            this.A(randomAccessFile2);
                        }
                        catch (final IOException ex2) {
                            this.C.A(ex2);
                        }
                        n2 = 0L;
                    }
                    catch (final FileNotFoundException ex3) {
                        this.C.A();
                        Thread.sleep(this.I);
                    }
                }
                else {
                    if (length > n2) {
                        n2 = this.A(randomAccessFile);
                        n = S.K(this.D);
                    }
                    else if (b) {
                        randomAccessFile.seek(0L);
                        n2 = this.A(randomAccessFile);
                        n = S.K(this.D);
                    }
                    if (this.K && randomAccessFile != null) {
                        randomAccessFile.close();
                    }
                    Thread.sleep(this.I);
                    if (!this.A() || !this.K) {
                        continue;
                    }
                    randomAccessFile = new RandomAccessFile(this.D, "r");
                    randomAccessFile.seek(n2);
                }
            }
        }
        catch (final InterruptedException ex4) {
            Thread.currentThread().interrupt();
            this.C.A(ex4);
        }
        catch (final Exception ex5) {
            this.C.A(ex5);
        }
        finally {
            try {
                if (randomAccessFile != null) {
                    randomAccessFile.close();
                }
            }
            catch (final IOException ex6) {
                this.C.A(ex6);
            }
            this.D();
        }
    }
    
    public void D() {
        this.E = false;
    }
    
    private long A(final RandomAccessFile randomAccessFile) throws IOException {
        try (final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(64)) {
            long filePointer2;
            long filePointer = filePointer2 = randomAccessFile.getFilePointer();
            int n = 0;
            int read;
            while (this.A() && (read = randomAccessFile.read(this.G)) != -1) {
                for (int i = 0; i < read; ++i) {
                    final byte b = this.G[i];
                    switch (b) {
                        case 10: {
                            n = 0;
                            this.C.A(new String(byteArrayOutputStream.toByteArray(), this.F));
                            byteArrayOutputStream.reset();
                            filePointer2 = filePointer + i + 1L;
                            break;
                        }
                        case 13: {
                            if (n != 0) {
                                byteArrayOutputStream.write(13);
                            }
                            n = 1;
                            break;
                        }
                        default: {
                            if (n != 0) {
                                n = 0;
                                this.C.A(new String(byteArrayOutputStream.toByteArray(), this.F));
                                byteArrayOutputStream.reset();
                                filePointer2 = filePointer + i + 1L;
                            }
                            byteArrayOutputStream.write(b);
                            break;
                        }
                    }
                }
                filePointer = randomAccessFile.getFilePointer();
            }
            randomAccessFile.seek(filePointer2);
            if (this.C instanceof H) {
                ((H)this.C).C();
            }
            return filePointer2;
        }
    }
    
    static {
        J = Charset.defaultCharset();
    }
}
