// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.InputStream;

public class P extends InputStream
{
    public static final P A;
    
    @Override
    public int read() {
        return -1;
    }
    
    static {
        A = new P();
    }
}
