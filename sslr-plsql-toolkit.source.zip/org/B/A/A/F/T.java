// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.nio.CharBuffer;
import org.B.A.A.W;
import java.io.IOException;
import java.io.Reader;
import java.io.FilterReader;

public abstract class T extends FilterReader
{
    public T(final Reader in) {
        super(in);
    }
    
    @Override
    public int read() throws IOException {
        try {
            this.B(1);
            final int read = this.in.read();
            this.A((read != -1) ? 1 : -1);
            return read;
        }
        catch (final IOException ex) {
            this.A(ex);
            return -1;
        }
    }
    
    @Override
    public int read(final char[] cbuf) throws IOException {
        try {
            this.B(W.A(cbuf));
            final int read = this.in.read(cbuf);
            this.A(read);
            return read;
        }
        catch (final IOException ex) {
            this.A(ex);
            return -1;
        }
    }
    
    @Override
    public int read(final char[] array, final int n, final int n2) throws IOException {
        try {
            this.B(n2);
            final int read = this.in.read(array, n, n2);
            this.A(read);
            return read;
        }
        catch (final IOException ex) {
            this.A(ex);
            return -1;
        }
    }
    
    @Override
    public int read(final CharBuffer target) throws IOException {
        try {
            this.B(W.B(target));
            final int read = this.in.read(target);
            this.A(read);
            return read;
        }
        catch (final IOException ex) {
            this.A(ex);
            return -1;
        }
    }
    
    @Override
    public long skip(final long n) throws IOException {
        try {
            return this.in.skip(n);
        }
        catch (final IOException ex) {
            this.A(ex);
            return 0L;
        }
    }
    
    @Override
    public boolean ready() throws IOException {
        try {
            return this.in.ready();
        }
        catch (final IOException ex) {
            this.A(ex);
            return false;
        }
    }
    
    @Override
    public void close() throws IOException {
        try {
            this.in.close();
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public synchronized void mark(final int readAheadLimit) throws IOException {
        try {
            this.in.mark(readAheadLimit);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public synchronized void reset() throws IOException {
        try {
            this.in.reset();
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public boolean markSupported() {
        return this.in.markSupported();
    }
    
    protected void B(final int n) throws IOException {
    }
    
    protected void A(final int n) throws IOException {
    }
    
    protected void A(final IOException ex) throws IOException {
        throw ex;
    }
}
