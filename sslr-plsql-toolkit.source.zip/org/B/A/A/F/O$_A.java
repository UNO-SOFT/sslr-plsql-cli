// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import org.B.A.A.W;
import java.io.IOException;
import java.nio.ByteBuffer;

private class _A
{
    private final long E;
    private final byte[] C;
    private byte[] D;
    private int B;
    
    private _A(final long e, final int length, final byte[] array) throws IOException {
        this.E = e;
        this.C = new byte[length + ((array != null) ? array.length : 0)];
        final long n = (e - 1L) * O.A(O.this);
        if (e > 0L) {
            O.B(O.this).position(n);
            if (O.B(O.this).read(ByteBuffer.wrap(this.C, 0, length)) != length) {
                throw new IllegalStateException("Count of requested bytes and actually read bytes don't match");
            }
        }
        if (array != null) {
            System.arraycopy(array, 0, this.C, length, array.length);
        }
        this.B = this.C.length - 1;
        this.D = null;
    }
    
    private void B() {
        final int n = this.B + 1;
        if (n > 0) {
            this.D = W.B(n);
            System.arraycopy(this.C, 0, this.D, 0, n);
        }
        else {
            this.D = null;
        }
        this.B = -1;
    }
    
    private int A(final byte[] array, final int n) {
        for (final byte[] array2 : O.F(O.this)) {
            boolean b = true;
            for (int j = array2.length - 1; j >= 0; --j) {
                final int n2 = n + j - (array2.length - 1);
                b &= (n2 >= 0 && array[n2] == array2[j]);
            }
            if (b) {
                return array2.length;
            }
        }
        return 0;
    }
    
    private String C() {
        String s = null;
        final boolean b = this.E == 1L;
        int i = this.B;
        while (i > -1) {
            if (!b && i < O.E(O.this)) {
                this.B();
                break;
            }
            final int a;
            if ((a = this.A(this.C, i)) > 0) {
                final int n = i + 1;
                final int j = this.B - n + 1;
                if (j < 0) {
                    throw new IllegalStateException("Unexpected negative line length=" + j);
                }
                final byte[] b2 = W.B(j);
                System.arraycopy(this.C, n, b2, 0, j);
                s = new String(b2, O.D(O.this));
                this.B = i - a;
                break;
            }
            else {
                i -= O.C(O.this);
                if (i < 0) {
                    this.B();
                    break;
                }
                continue;
            }
        }
        if (b && this.D != null) {
            s = new String(this.D, O.D(O.this));
            this.D = null;
        }
        return s;
    }
    
    private _A A() throws IOException {
        if (this.B > -1) {
            throw new IllegalStateException("Current currentLastCharPos unexpectedly positive... last readLine() should have returned something! currentLastCharPos=" + this.B);
        }
        if (this.E > 1L) {
            return new _A(this.E - 1L, O.A(O.this), this.D);
        }
        if (this.D != null) {
            throw new IllegalStateException("Unexpected leftover of the last block: leftOverOfThisFilePart=" + new String(this.D, O.D(O.this)));
        }
        return null;
    }
}
