// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.Closeable;
import org.B.A.A.W;
import java.io.IOException;
import java.io.InputStream;
import java.io.FilterInputStream;

public abstract class F extends FilterInputStream
{
    public F(final InputStream in) {
        super(in);
    }
    
    @Override
    public int read() throws IOException {
        try {
            this.B(1);
            final int read = this.in.read();
            this.A((read != -1) ? 1 : -1);
            return read;
        }
        catch (final IOException ex) {
            this.A(ex);
            return -1;
        }
    }
    
    @Override
    public int read(final byte[] b) throws IOException {
        try {
            this.B(W.B(b));
            final int read = this.in.read(b);
            this.A(read);
            return read;
        }
        catch (final IOException ex) {
            this.A(ex);
            return -1;
        }
    }
    
    @Override
    public int read(final byte[] b, final int off, final int len) throws IOException {
        try {
            this.B(len);
            final int read = this.in.read(b, off, len);
            this.A(read);
            return read;
        }
        catch (final IOException ex) {
            this.A(ex);
            return -1;
        }
    }
    
    @Override
    public long skip(final long n) throws IOException {
        try {
            return this.in.skip(n);
        }
        catch (final IOException ex) {
            this.A(ex);
            return 0L;
        }
    }
    
    @Override
    public int available() throws IOException {
        try {
            return super.available();
        }
        catch (final IOException ex) {
            this.A(ex);
            return 0;
        }
    }
    
    @Override
    public void close() throws IOException {
        W.A(this.in, this::A);
    }
    
    @Override
    public synchronized void mark(final int readlimit) {
        this.in.mark(readlimit);
    }
    
    @Override
    public synchronized void reset() throws IOException {
        try {
            this.in.reset();
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public boolean markSupported() {
        return this.in.markSupported();
    }
    
    protected void B(final int n) throws IOException {
    }
    
    protected void A(final int n) throws IOException {
    }
    
    protected void A(final IOException ex) throws IOException {
        throw ex;
    }
}
