// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

static synthetic class O$1 {}