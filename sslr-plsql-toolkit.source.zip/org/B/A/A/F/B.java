// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.io.InputStream;
import java.security.MessageDigest;

public class B extends e
{
    private final MessageDigest O;
    
    public B(final InputStream inputStream, final MessageDigest o) {
        super(inputStream, new e._A[] { new _A(o) });
        this.O = o;
    }
    
    public B(final InputStream inputStream, final String algorithm) throws NoSuchAlgorithmException {
        this(inputStream, MessageDigest.getInstance(algorithm));
    }
    
    public B(final InputStream inputStream) throws NoSuchAlgorithmException {
        this(inputStream, MessageDigest.getInstance("MD5"));
    }
    
    public MessageDigest O() {
        return this.O;
    }
    
    public static class _A extends e._A
    {
        private final MessageDigest C;
        
        public _A(final MessageDigest c) {
            this.C = c;
        }
        
        @Override
        public void A(final int n) throws IOException {
            this.C.update((byte)n);
        }
        
        @Override
        public void A(final byte[] input, final int offset, final int len) throws IOException {
            this.C.update(input, offset, len);
        }
    }
}
