// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.IOException;
import java.io.Reader;

public class Z extends Reader
{
    private static final int C = -1;
    private final Reader F;
    private int B;
    private int E;
    private int A;
    private final int D;
    
    public Z(final Reader f, final int d) {
        this.E = -1;
        this.F = f;
        this.D = d;
    }
    
    @Override
    public void close() throws IOException {
        this.F.close();
    }
    
    @Override
    public void reset() throws IOException {
        this.B = this.E;
        this.F.reset();
    }
    
    @Override
    public void mark(final int readAheadLimit) throws IOException {
        this.A = readAheadLimit - this.B;
        this.E = this.B;
        this.F.mark(readAheadLimit);
    }
    
    @Override
    public int read() throws IOException {
        if (this.B >= this.D) {
            return -1;
        }
        if (this.E >= 0 && this.B - this.E >= this.A) {
            return -1;
        }
        ++this.B;
        return this.F.read();
    }
    
    @Override
    public int read(final char[] array, final int n, final int n2) throws IOException {
        for (int i = 0; i < n2; ++i) {
            final int read = this.read();
            if (read == -1) {
                return (i == 0) ? -1 : i;
            }
            array[n + i] = (char)read;
        }
        return n2;
    }
}
