// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.IOException;
import java.io.InputStream;

public class U extends F
{
    public U(final InputStream inputStream) {
        super(inputStream);
    }
    
    @Override
    public void mark(final int n) {
    }
    
    @Override
    public boolean markSupported() {
        return false;
    }
    
    @Override
    public void reset() throws IOException {
        throw u.A();
    }
}
