// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.IOException;
import java.io.InputStream;

public class A extends InputStream
{
    private final InputStream C;
    private final long B;
    private long E;
    private long D;
    private boolean A;
    
    public A(final InputStream c, final long b) {
        this.D = -1L;
        this.A = true;
        this.B = b;
        this.C = c;
    }
    
    public A(final InputStream inputStream) {
        this(inputStream, -1L);
    }
    
    @Override
    public int read() throws IOException {
        if (this.B >= 0L && this.E >= this.B) {
            return -1;
        }
        final int read = this.C.read();
        ++this.E;
        return read;
    }
    
    @Override
    public int read(final byte[] array) throws IOException {
        return this.read(array, 0, array.length);
    }
    
    @Override
    public int read(final byte[] b, final int off, final int n) throws IOException {
        if (this.B >= 0L && this.E >= this.B) {
            return -1;
        }
        final int read = this.C.read(b, off, (int)((this.B >= 0L) ? Math.min(n, this.B - this.E) : n));
        if (read == -1) {
            return -1;
        }
        this.E += read;
        return read;
    }
    
    @Override
    public long skip(final long a) throws IOException {
        final long skip = this.C.skip((this.B >= 0L) ? Math.min(a, this.B - this.E) : a);
        this.E += skip;
        return skip;
    }
    
    @Override
    public int available() throws IOException {
        if (this.B >= 0L && this.E >= this.B) {
            return 0;
        }
        return this.C.available();
    }
    
    @Override
    public String toString() {
        return this.C.toString();
    }
    
    @Override
    public void close() throws IOException {
        if (this.A) {
            this.C.close();
        }
    }
    
    @Override
    public synchronized void reset() throws IOException {
        this.C.reset();
        this.E = this.D;
    }
    
    @Override
    public synchronized void mark(final int readlimit) {
        this.C.mark(readlimit);
        this.D = this.E;
    }
    
    @Override
    public boolean markSupported() {
        return this.C.markSupported();
    }
    
    public boolean A() {
        return this.A;
    }
    
    public void A(final boolean a) {
        this.A = a;
    }
}
