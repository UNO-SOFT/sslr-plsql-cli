// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.IOException;
import java.security.MessageDigest;

public static class _A extends e._A
{
    private final MessageDigest C;
    
    public _A(final MessageDigest c) {
        this.C = c;
    }
    
    @Override
    public void A(final int n) throws IOException {
        this.C.update((byte)n);
    }
    
    @Override
    public void A(final byte[] input, final int offset, final int len) throws IOException {
        this.C.update(input, offset, len);
    }
}
