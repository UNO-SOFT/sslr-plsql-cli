// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

public class J extends InputStream
{
    private final long C;
    private long A;
    private long G;
    private long E;
    private boolean B;
    private final boolean F;
    private final boolean D;
    
    public J() {
        this(0L, true, false);
    }
    
    public J(final long n) {
        this(n, true, false);
    }
    
    public J(final long c, final boolean d, final boolean f) {
        this.G = -1L;
        this.C = c;
        this.D = d;
        this.F = f;
    }
    
    public long C() {
        return this.A;
    }
    
    public long D() {
        return this.C;
    }
    
    @Override
    public int available() {
        final long n = this.C - this.A;
        if (n <= 0L) {
            return 0;
        }
        if (n > 2147483647L) {
            return Integer.MAX_VALUE;
        }
        return (int)n;
    }
    
    @Override
    public void close() throws IOException {
        this.B = false;
        this.A = 0L;
        this.G = -1L;
    }
    
    @Override
    public synchronized void mark(final int n) {
        if (!this.D) {
            throw u.B();
        }
        this.G = this.A;
        this.E = n;
    }
    
    @Override
    public boolean markSupported() {
        return this.D;
    }
    
    @Override
    public int read() throws IOException {
        if (this.B) {
            throw new IOException("Read after end of file");
        }
        if (this.A == this.C) {
            return this.B();
        }
        ++this.A;
        return this.A();
    }
    
    @Override
    public int read(final byte[] array) throws IOException {
        return this.read(array, 0, array.length);
    }
    
    @Override
    public int read(final byte[] array, final int n, final int n2) throws IOException {
        if (this.B) {
            throw new IOException("Read after end of file");
        }
        if (this.A == this.C) {
            return this.B();
        }
        this.A += n2;
        int n3 = n2;
        if (this.A > this.C) {
            n3 = n2 - (int)(this.A - this.C);
            this.A = this.C;
        }
        this.A(array, n, n3);
        return n3;
    }
    
    @Override
    public synchronized void reset() throws IOException {
        if (!this.D) {
            throw u.A();
        }
        if (this.G < 0L) {
            throw new IOException("No position has been marked");
        }
        if (this.A > this.G + this.E) {
            throw new IOException("Marked position [" + this.G + "] is no longer valid - passed the read limit [" + this.E + "]");
        }
        this.A = this.G;
        this.B = false;
    }
    
    @Override
    public long skip(final long n) throws IOException {
        if (this.B) {
            throw new IOException("Skip after end of file");
        }
        if (this.A == this.C) {
            return this.B();
        }
        this.A += n;
        long n2 = n;
        if (this.A > this.C) {
            n2 = n - (this.A - this.C);
            this.A = this.C;
        }
        return n2;
    }
    
    protected int A() {
        return 0;
    }
    
    protected void A(final byte[] array, final int n, final int n2) {
    }
    
    private int B() throws EOFException {
        this.B = true;
        if (this.F) {
            throw new EOFException();
        }
        return -1;
    }
}
