// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.IOException;

public class E extends IOException
{
    private static final long F = 1L;
    private final String E;
    private final String B;
    private final String A;
    private final String D;
    private final String C;
    
    public E(final String s, final String s2, final String s3, final String s4) {
        this(s, null, null, s2, s3, s4);
    }
    
    public E(final String message, final String d, final String c, final String e, final String b, final String a) {
        super(message);
        this.D = d;
        this.C = c;
        this.E = e;
        this.B = b;
        this.A = a;
    }
    
    public String C() {
        return this.E;
    }
    
    public String B() {
        return this.B;
    }
    
    public String A() {
        return this.A;
    }
    
    public String E() {
        return this.D;
    }
    
    public String D() {
        return this.C;
    }
}
