// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.EOFException;
import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;
import java.io.IOException;
import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import java.nio.ByteBuffer;
import java.util.concurrent.locks.ReentrantLock;
import java.io.InputStream;

public class S extends InputStream
{
    private static final ThreadLocal<byte[]> J;
    private final ReentrantLock L;
    private ByteBuffer E;
    private ByteBuffer N;
    private boolean F;
    private boolean P;
    private boolean H;
    private Throwable O;
    private boolean D;
    private boolean K;
    private boolean M;
    private final AtomicBoolean I;
    private final InputStream B;
    private final ExecutorService Q;
    private final boolean G;
    private final Condition C;
    static final /* synthetic */ boolean A;
    
    private static ExecutorService E() {
        return Executors.newSingleThreadExecutor(S::A);
    }
    
    private static Thread A(final Runnable target) {
        final Thread thread = new Thread(target, "commons-io-read-ahead");
        thread.setDaemon(true);
        return thread;
    }
    
    public S(final InputStream inputStream, final int n) {
        this(inputStream, n, E(), true);
    }
    
    public S(final InputStream inputStream, final int n, final ExecutorService executorService) {
        this(inputStream, n, executorService, false);
    }
    
    private S(final InputStream obj, final int capacity, final ExecutorService obj2, final boolean g) {
        this.L = new ReentrantLock();
        this.I = new AtomicBoolean(false);
        this.C = this.L.newCondition();
        if (capacity <= 0) {
            throw new IllegalArgumentException("bufferSizeInBytes should be greater than 0, but the value is " + capacity);
        }
        this.Q = Objects.requireNonNull(obj2, "executorService");
        this.B = Objects.requireNonNull(obj, "inputStream");
        this.G = g;
        this.E = ByteBuffer.allocate(capacity);
        this.N = ByteBuffer.allocate(capacity);
        this.E.flip();
        this.N.flip();
    }
    
    @Override
    public int available() throws IOException {
        this.L.lock();
        try {
            return (int)Math.min(2147483647L, this.E.remaining() + (long)this.N.remaining());
        }
        finally {
            this.L.unlock();
        }
    }
    
    private void G() throws IOException {
        if (!this.H) {
            return;
        }
        if (this.O instanceof IOException) {
            throw (IOException)this.O;
        }
        throw new IOException(this.O);
    }
    
    @Override
    public void close() throws IOException {
        boolean b = false;
        this.L.lock();
        try {
            if (this.D) {
                return;
            }
            this.D = true;
            if (!this.M) {
                b = true;
                this.K = true;
            }
        }
        finally {
            this.L.unlock();
        }
        if (this.G) {
            try {
                this.Q.shutdownNow();
                this.Q.awaitTermination(Long.MAX_VALUE, TimeUnit.SECONDS);
            }
            catch (final InterruptedException cause) {
                final InterruptedIOException ex = new InterruptedIOException(cause.getMessage());
                ex.initCause(cause);
                throw ex;
            }
            finally {
                if (b) {
                    this.B.close();
                }
            }
        }
    }
    
    private void C() {
        boolean b = false;
        this.L.lock();
        try {
            this.M = false;
            if (this.D && !this.K) {
                b = true;
            }
        }
        finally {
            this.L.unlock();
        }
        if (b) {
            try {
                this.B.close();
            }
            catch (final IOException ex) {}
        }
    }
    
    private boolean H() {
        return !this.E.hasRemaining() && !this.N.hasRemaining() && this.F;
    }
    
    @Override
    public int read() throws IOException {
        if (this.E.hasRemaining()) {
            return this.E.get() & 0xFF;
        }
        final byte[] array = S.J.get();
        return (this.read(array, 0, 1) == -1) ? -1 : (array[0] & 0xFF);
    }
    
    @Override
    public int read(final byte[] dst, final int offset, int min) throws IOException {
        if (offset < 0 || min < 0 || min > dst.length - offset) {
            throw new IndexOutOfBoundsException();
        }
        if (min == 0) {
            return 0;
        }
        if (!this.E.hasRemaining()) {
            this.L.lock();
            try {
                this.B();
                if (!this.N.hasRemaining()) {
                    this.F();
                    this.B();
                    if (this.H()) {
                        return -1;
                    }
                }
                this.D();
                this.F();
            }
            finally {
                this.L.unlock();
            }
        }
        min = Math.min(min, this.E.remaining());
        this.E.get(dst, offset, min);
        return min;
    }
    
    private void F() throws IOException {
        this.L.lock();
        try {
            this.N.array();
            if (this.F || this.P) {
                return;
            }
            this.G();
            this.N.position(0);
            this.N.flip();
            this.P = true;
        }
        finally {
            this.L.unlock();
        }
        this.Q.execute(() -> {
            this.L.lock();
            try {
                if (this.D) {
                    this.P = false;
                    return;
                }
                else {
                    this.M = true;
                }
            }
            finally {
                this.L.unlock();
            }
            int length = b.length;
            try {
                do {
                    final int off;
                    this.B.read(b, off, length);
                    final int n;
                    if (n <= 0) {
                        break;
                    }
                    else {
                        length -= n;
                    }
                } while (length > 0 && !this.I.get());
            }
            catch (final Throwable t) {
                if (t instanceof Error) {
                    throw (Error)t;
                }
            }
            finally {
                this.L.lock();
                try {
                    final int off;
                    this.N.limit(off);
                    final int n;
                    final Throwable o;
                    if (n < 0 || o instanceof EOFException) {
                        this.F = true;
                    }
                    else if (o != null) {
                        this.H = true;
                        this.O = o;
                    }
                    this.P = false;
                    this.A();
                }
                finally {
                    this.L.unlock();
                }
                this.C();
            }
        });
    }
    
    private void A() {
        this.L.lock();
        try {
            this.C.signalAll();
        }
        finally {
            this.L.unlock();
        }
    }
    
    @Override
    public long skip(final long n) throws IOException {
        if (n <= 0L) {
            return 0L;
        }
        if (n <= this.E.remaining()) {
            this.E.position((int)n + this.E.position());
            return n;
        }
        this.L.lock();
        long a;
        try {
            a = this.A(n);
        }
        finally {
            this.L.unlock();
        }
        return a;
    }
    
    private long A(final long n) throws IOException {
        if (!S.A && !this.L.isLocked()) {
            throw new AssertionError();
        }
        this.B();
        if (this.H()) {
            return 0L;
        }
        if (this.available() < n) {
            final int available = this.available();
            final long n2 = n - available;
            this.E.position(0);
            this.E.flip();
            this.N.position(0);
            this.N.flip();
            final long skip = this.B.skip(n2);
            this.F();
            return available + skip;
        }
        final int n3 = (int)n - this.E.remaining();
        if (!S.A && n3 <= 0) {
            throw new AssertionError();
        }
        this.E.position(0);
        this.E.flip();
        this.N.position(n3 + this.N.position());
        this.D();
        this.F();
        return n;
    }
    
    private void D() {
        final ByteBuffer e = this.E;
        this.E = this.N;
        this.N = e;
    }
    
    private void B() throws IOException {
        this.L.lock();
        try {
            this.I.set(true);
            while (this.P) {
                this.C.await();
            }
        }
        catch (final InterruptedException cause) {
            final InterruptedIOException ex = new InterruptedIOException(cause.getMessage());
            ex.initCause(cause);
            throw ex;
        }
        finally {
            this.I.set(false);
            this.L.unlock();
        }
        this.G();
    }
    
    static {
        A = !S.class.desiredAssertionStatus();
        J = ThreadLocal.withInitial(() -> new byte[1]);
    }
}
