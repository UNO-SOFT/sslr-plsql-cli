// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.IOException;
import java.io.Reader;
import java.util.function.IntPredicate;
import java.io.FilterReader;

public abstract class R extends FilterReader
{
    protected static final IntPredicate B;
    private final IntPredicate A;
    
    protected R(final Reader reader) {
        this(reader, R.B);
    }
    
    protected R(final Reader in, final IntPredicate intPredicate) {
        super(in);
        this.A = ((intPredicate == null) ? R.B : intPredicate);
    }
    
    protected boolean B(final int n) {
        return this.A.test(n);
    }
    
    @Override
    public int read() throws IOException {
        int read;
        do {
            read = this.in.read();
        } while (read != -1 && this.B(read));
        return read;
    }
    
    @Override
    public int read(final char[] cbuf, final int off, final int len) throws IOException {
        final int read = super.read(cbuf, off, len);
        if (read == -1) {
            return -1;
        }
        int n = off - 1;
        for (int i = off; i < off + read; ++i) {
            if (!this.B(cbuf[i])) {
                if (++n < i) {
                    cbuf[n] = cbuf[i];
                }
            }
        }
        return n - off + 1;
    }
    
    static {
        B = (p0 -> false);
    }
}
