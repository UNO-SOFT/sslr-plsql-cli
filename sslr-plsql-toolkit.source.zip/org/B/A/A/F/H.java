// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

public class H implements v
{
    @Override
    public void A(final L l) {
    }
    
    @Override
    public void A() {
    }
    
    @Override
    public void B() {
    }
    
    @Override
    public void A(final String s) {
    }
    
    @Override
    public void A(final Exception ex) {
    }
    
    public void C() {
    }
}
