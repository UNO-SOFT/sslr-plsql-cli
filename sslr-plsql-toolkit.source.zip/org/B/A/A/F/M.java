// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.util.Iterator;
import java.io.IOException;
import java.util.Arrays;
import org.B.A.A.W;
import java.io.InputStream;
import java.util.Comparator;
import org.B.A.A.K;
import java.util.List;

public class M extends F
{
    private final boolean A;
    private final List<K> E;
    private K C;
    private int[] D;
    private int B;
    private int G;
    private int I;
    private boolean H;
    private static final Comparator<K> F;
    
    public M(final InputStream inputStream) {
        this(inputStream, false, new K[] { K.E });
    }
    
    public M(final InputStream inputStream, final boolean b) {
        this(inputStream, b, new K[] { K.E });
    }
    
    public M(final InputStream inputStream, final K... array) {
        this(inputStream, false, array);
    }
    
    public M(final InputStream inputStream, final boolean a, final K... a2) {
        super(inputStream);
        if (W.A(a2) == 0) {
            throw new IllegalArgumentException("No BOMs specified");
        }
        this.A = a;
        final List<K> list = Arrays.asList(a2);
        list.sort(M.F);
        this.E = list;
    }
    
    public boolean D() throws IOException {
        return this.A() != null;
    }
    
    public boolean A(final K obj) throws IOException {
        if (!this.E.contains(obj)) {
            throw new IllegalArgumentException("Stream not configure to detect " + obj);
        }
        this.A();
        return this.C != null && this.C.equals(obj);
    }
    
    public K A() throws IOException {
        if (this.D == null) {
            this.B = 0;
            this.D = new int[this.E.get(0).C()];
            for (int i = 0; i < this.D.length; ++i) {
                this.D[i] = this.in.read();
                ++this.B;
                if (this.D[i] < 0) {
                    break;
                }
            }
            this.C = this.C();
            if (this.C != null && !this.A) {
                if (this.C.C() < this.D.length) {
                    this.G = this.C.C();
                }
                else {
                    this.B = 0;
                }
            }
        }
        return this.C;
    }
    
    public String B() throws IOException {
        this.A();
        return (this.C == null) ? null : this.C.A();
    }
    
    private int E() throws IOException {
        this.A();
        return (this.G < this.B) ? this.D[this.G++] : -1;
    }
    
    private K C() {
        for (final K k : this.E) {
            if (this.B(k)) {
                return k;
            }
        }
        return null;
    }
    
    private boolean B(final K k) {
        for (int i = 0; i < k.C(); ++i) {
            if (k.A(i) != this.D[i]) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public int read() throws IOException {
        final int e = this.E();
        return (e >= 0) ? e : this.in.read();
    }
    
    @Override
    public int read(final byte[] b, int off, int len) throws IOException {
        int n = 0;
        for (int e = 0; len > 0 && e >= 0; --len, ++n) {
            e = this.E();
            if (e >= 0) {
                b[off++] = (byte)(e & 0xFF);
            }
        }
        final int read = this.in.read(b, off, len);
        return (read < 0) ? ((n > 0) ? n : -1) : (n + read);
    }
    
    @Override
    public int read(final byte[] array) throws IOException {
        return this.read(array, 0, array.length);
    }
    
    @Override
    public synchronized void mark(final int readlimit) {
        this.I = this.G;
        this.H = (this.D == null);
        this.in.mark(readlimit);
    }
    
    @Override
    public synchronized void reset() throws IOException {
        this.G = this.I;
        if (this.H) {
            this.D = null;
        }
        this.in.reset();
    }
    
    @Override
    public long skip(final long n) throws IOException {
        int n2;
        for (n2 = 0; n > n2 && this.E() >= 0; ++n2) {}
        return this.in.skip(n - n2) + n2;
    }
    
    static {
        F = ((k, i) -> Integer.compare(i.C(), k.C()));
    }
}
