// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.util.Objects;
import java.io.IOException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.Charset;
import java.nio.charset.CoderResult;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharsetEncoder;
import java.io.Reader;
import java.io.InputStream;

public class W extends InputStream
{
    private static final int G = 1024;
    private final Reader A;
    private final CharsetEncoder E;
    private final CharBuffer C;
    private final ByteBuffer F;
    private CoderResult D;
    private boolean B;
    
    public W(final Reader reader, final CharsetEncoder charsetEncoder) {
        this(reader, charsetEncoder, 1024);
    }
    
    public W(final Reader a, final CharsetEncoder e, final int capacity) {
        this.A = a;
        this.E = e;
        (this.C = CharBuffer.allocate(capacity)).flip();
        (this.F = ByteBuffer.allocate(128)).flip();
    }
    
    public W(final Reader reader, final Charset charset, final int n) {
        this(reader, charset.newEncoder().onMalformedInput(CodingErrorAction.REPLACE).onUnmappableCharacter(CodingErrorAction.REPLACE), n);
    }
    
    public W(final Reader reader, final Charset charset) {
        this(reader, charset, 1024);
    }
    
    public W(final Reader reader, final String charsetName, final int n) {
        this(reader, Charset.forName(charsetName), n);
    }
    
    public W(final Reader reader, final String s) {
        this(reader, s, 1024);
    }
    
    @Deprecated
    public W(final Reader reader) {
        this(reader, Charset.defaultCharset());
    }
    
    private void A() throws IOException {
        if (!this.B && (this.D == null || this.D.isUnderflow())) {
            this.C.compact();
            final int position = this.C.position();
            final int read = this.A.read(this.C.array(), position, this.C.remaining());
            if (read == -1) {
                this.B = true;
            }
            else {
                this.C.position(position + read);
            }
            this.C.flip();
        }
        this.F.compact();
        this.D = this.E.encode(this.C, this.F, this.B);
        this.F.flip();
    }
    
    @Override
    public int read(final byte[] array, int n, int i) throws IOException {
        Objects.requireNonNull(array, "array");
        if (i < 0 || n < 0 || n + i > array.length) {
            throw new IndexOutOfBoundsException("Array Size=" + array.length + ", offset=" + n + ", length=" + i);
        }
        int n2 = 0;
        if (i == 0) {
            return 0;
        }
        while (i > 0) {
            if (this.F.hasRemaining()) {
                final int min = Math.min(this.F.remaining(), i);
                this.F.get(array, n, min);
                n += min;
                i -= min;
                n2 += min;
            }
            else {
                this.A();
                if (this.B && !this.F.hasRemaining()) {
                    break;
                }
                continue;
            }
        }
        return (n2 == 0 && this.B) ? -1 : n2;
    }
    
    @Override
    public int read(final byte[] array) throws IOException {
        return this.read(array, 0, array.length);
    }
    
    @Override
    public int read() throws IOException {
        while (!this.F.hasRemaining()) {
            this.A();
            if (this.B && !this.F.hasRemaining()) {
                return -1;
            }
        }
        return this.F.get() & 0xFF;
    }
    
    @Override
    public void close() throws IOException {
        this.A.close();
    }
}
