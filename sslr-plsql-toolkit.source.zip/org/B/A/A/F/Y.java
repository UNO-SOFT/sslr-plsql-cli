// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.IOException;
import org.B.A.A.G;
import java.util.UUID;
import java.io.InputStream;
import java.io.Serializable;

public class Y extends F
{
    private final Serializable J;
    
    public Y(final InputStream inputStream) {
        super(inputStream);
        this.J = UUID.randomUUID();
    }
    
    public boolean B(final Throwable t) {
        return G.A(t, this.J);
    }
    
    public void A(final Throwable t) throws IOException {
        G.B(t, this.J);
    }
    
    @Override
    protected void A(final IOException ex) throws IOException {
        throw new G(ex, this.J);
    }
}
