// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.IOException;
import java.util.Objects;
import java.io.RandomAccessFile;
import java.io.InputStream;

public class _ extends InputStream
{
    private final boolean A;
    private final RandomAccessFile B;
    
    public _(final RandomAccessFile randomAccessFile) {
        this(randomAccessFile, false);
    }
    
    public _(final RandomAccessFile obj, final boolean a) {
        this.B = Objects.requireNonNull(obj, "file");
        this.A = a;
    }
    
    @Override
    public int available() throws IOException {
        final long a = this.A();
        if (a > 2147483647L) {
            return Integer.MAX_VALUE;
        }
        return (int)a;
    }
    
    public long A() throws IOException {
        return this.B.length() - this.B.getFilePointer();
    }
    
    @Override
    public void close() throws IOException {
        super.close();
        if (this.A) {
            this.B.close();
        }
    }
    
    public RandomAccessFile B() {
        return this.B;
    }
    
    public boolean C() {
        return this.A;
    }
    
    @Override
    public int read() throws IOException {
        return this.B.read();
    }
    
    @Override
    public int read(final byte[] b) throws IOException {
        return this.B.read(b);
    }
    
    @Override
    public int read(final byte[] b, final int off, final int len) throws IOException {
        return this.B.read(b, off, len);
    }
    
    private void A(final long pos) throws IOException {
        this.B.seek(pos);
    }
    
    @Override
    public long skip(final long n) throws IOException {
        if (n <= 0L) {
            return 0L;
        }
        final long filePointer = this.B.getFilePointer();
        final long length = this.B.length();
        if (filePointer >= length) {
            return 0L;
        }
        final long n2 = filePointer + n;
        final long n3 = (n2 > length) ? (length - 1L) : n2;
        if (n3 > 0L) {
            this.A(n3);
        }
        return this.B.getFilePointer() - filePointer;
    }
}
