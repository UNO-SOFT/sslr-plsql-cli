// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.IOException;
import java.io.Reader;

public class K extends Reader
{
    public static final K A;
    
    @Override
    public int read(final char[] array, final int n, final int n2) {
        return -1;
    }
    
    @Override
    public void close() throws IOException {
    }
    
    static {
        A = new K();
    }
}
