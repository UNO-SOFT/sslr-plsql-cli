// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import org.B.A.A.W;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.nio.file.OpenOption;
import org.B.A.A.V;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import org.B.A.A.X;
import java.nio.file.Path;
import java.io.IOException;
import java.io.File;
import java.nio.channels.SeekableByteChannel;
import java.nio.charset.Charset;
import java.io.Closeable;

public class O implements Closeable
{
    private static final String B = "";
    private static final int F = 8192;
    private final int J;
    private final Charset E;
    private final SeekableByteChannel H;
    private final long A;
    private final long C;
    private final byte[][] G;
    private final int I;
    private final int L;
    private _A D;
    private boolean K;
    
    @Deprecated
    public O(final File file) throws IOException {
        this(file, 8192, Charset.defaultCharset());
    }
    
    public O(final File file, final Charset charset) throws IOException {
        this(file.toPath(), charset);
    }
    
    public O(final File file, final int n, final Charset charset) throws IOException {
        this(file.toPath(), n, charset);
    }
    
    public O(final File file, final int n, final String s) throws IOException {
        this(file.toPath(), n, s);
    }
    
    public O(final Path path, final Charset charset) throws IOException {
        this(path, 8192, charset);
    }
    
    public O(final Path path, final int j, final Charset obj) throws IOException {
        this.J = j;
        this.E = X.A(obj);
        if (this.E.newEncoder().maxBytesPerChar() == 1.0f) {
            this.L = 1;
        }
        else if (this.E == StandardCharsets.UTF_8) {
            this.L = 1;
        }
        else if (this.E == Charset.forName("Shift_JIS") || this.E == Charset.forName("windows-31j") || this.E == Charset.forName("x-windows-949") || this.E == Charset.forName("gbk") || this.E == Charset.forName("x-windows-950")) {
            this.L = 1;
        }
        else if (this.E == StandardCharsets.UTF_16BE || this.E == StandardCharsets.UTF_16LE) {
            this.L = 2;
        }
        else {
            if (this.E == StandardCharsets.UTF_16) {
                throw new UnsupportedEncodingException("For UTF-16, you need to specify the byte order (use UTF-16BE or UTF-16LE)");
            }
            throw new UnsupportedEncodingException("Encoding " + obj + " is not supported yet (feel free to submit a patch)");
        }
        this.G = new byte[][] { V.B.A(this.E), V.D.A(this.E), V.E.A(this.E) };
        this.I = this.G[0].length;
        this.H = Files.newByteChannel(path, StandardOpenOption.READ);
        this.A = this.H.size();
        int n = (int)(this.A % j);
        if (n > 0) {
            this.C = this.A / j + 1L;
        }
        else {
            this.C = this.A / j;
            if (this.A > 0L) {
                n = j;
            }
        }
        this.D = new _A(this.C, n, (byte[])null);
    }
    
    public O(final Path path, final int n, final String s) throws IOException {
        this(path, n, X.A(s));
    }
    
    @Override
    public void close() throws IOException {
        this.H.close();
    }
    
    public String A() throws IOException {
        String anObject;
        for (anObject = this.D.C(); anObject == null; anObject = this.D.C()) {
            this.D = this.D.A();
            if (this.D == null) {
                break;
            }
        }
        if ("".equals(anObject) && !this.K) {
            this.K = true;
            anObject = this.A();
        }
        return anObject;
    }
    
    public List<String> B(final int initialCapacity) throws IOException {
        if (initialCapacity < 0) {
            throw new IllegalArgumentException("lineCount < 0");
        }
        final ArrayList list = new ArrayList(initialCapacity);
        for (int i = 0; i < initialCapacity; ++i) {
            final String a = this.A();
            if (a == null) {
                return list;
            }
            list.add(a);
        }
        return list;
    }
    
    public String A(final int n) throws IOException {
        final List<String> b = this.B(n);
        Collections.reverse(b);
        return b.isEmpty() ? "" : (String.join(System.lineSeparator(), b) + System.lineSeparator());
    }
    
    private class _A
    {
        private final long E;
        private final byte[] C;
        private byte[] D;
        private int B;
        
        private _A(final long e, final int length, final byte[] array) throws IOException {
            this.E = e;
            this.C = new byte[length + ((array != null) ? array.length : 0)];
            final long n = (e - 1L) * O.this.J;
            if (e > 0L) {
                O.this.H.position(n);
                if (O.this.H.read(ByteBuffer.wrap(this.C, 0, length)) != length) {
                    throw new IllegalStateException("Count of requested bytes and actually read bytes don't match");
                }
            }
            if (array != null) {
                System.arraycopy(array, 0, this.C, length, array.length);
            }
            this.B = this.C.length - 1;
            this.D = null;
        }
        
        private void B() {
            final int n = this.B + 1;
            if (n > 0) {
                this.D = W.B(n);
                System.arraycopy(this.C, 0, this.D, 0, n);
            }
            else {
                this.D = null;
            }
            this.B = -1;
        }
        
        private int A(final byte[] array, final int n) {
            for (final byte[] array2 : O.this.G) {
                boolean b = true;
                for (int j = array2.length - 1; j >= 0; --j) {
                    final int n2 = n + j - (array2.length - 1);
                    b &= (n2 >= 0 && array[n2] == array2[j]);
                }
                if (b) {
                    return array2.length;
                }
            }
            return 0;
        }
        
        private String C() {
            String s = null;
            final boolean b = this.E == 1L;
            int i = this.B;
            while (i > -1) {
                if (!b && i < O.this.I) {
                    this.B();
                    break;
                }
                final int a;
                if ((a = this.A(this.C, i)) > 0) {
                    final int n = i + 1;
                    final int j = this.B - n + 1;
                    if (j < 0) {
                        throw new IllegalStateException("Unexpected negative line length=" + j);
                    }
                    final byte[] b2 = W.B(j);
                    System.arraycopy(this.C, n, b2, 0, j);
                    s = new String(b2, O.this.E);
                    this.B = i - a;
                    break;
                }
                else {
                    i -= O.this.L;
                    if (i < 0) {
                        this.B();
                        break;
                    }
                    continue;
                }
            }
            if (b && this.D != null) {
                s = new String(this.D, O.this.E);
                this.D = null;
            }
            return s;
        }
        
        private _A A() throws IOException {
            if (this.B > -1) {
                throw new IllegalStateException("Current currentLastCharPos unexpectedly positive... last readLine() should have returned something! currentLastCharPos=" + this.B);
            }
            if (this.E > 1L) {
                return new _A(this.E - 1L, O.this.J, this.D);
            }
            if (this.D != null) {
                throw new IllegalStateException("Unexpected leftover of the last block: leftOverOfThisFilePart=" + new String(this.D, O.this.E));
            }
            return null;
        }
    }
}
