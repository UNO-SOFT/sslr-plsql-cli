// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.io.IOException;
import java.io.InputStream;

public class N extends F
{
    public N(final InputStream inputStream) {
        super(inputStream);
    }
    
    @Override
    public void close() throws IOException {
        this.in.close();
        this.in = P.A;
    }
    
    @Override
    protected void A(final int n) throws IOException {
        if (n == -1) {
            this.close();
        }
    }
    
    @Override
    protected void finalize() throws Throwable {
        this.close();
        super.finalize();
    }
}
