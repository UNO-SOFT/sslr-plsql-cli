// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.F;

import java.util.Objects;
import java.io.Serializable;
import java.io.Reader;

public class I extends Reader implements Serializable
{
    private static final long F = 3724187752191401220L;
    private final CharSequence C;
    private int A;
    private int E;
    private final int D;
    private final Integer B;
    
    public I(final CharSequence charSequence) {
        this(charSequence, 0);
    }
    
    public I(final CharSequence charSequence, final int n) {
        this(charSequence, n, Integer.MAX_VALUE);
    }
    
    public I(final CharSequence charSequence, final int e, final int n) {
        if (e < 0) {
            throw new IllegalArgumentException("Start index is less than zero: " + e);
        }
        if (n < e) {
            throw new IllegalArgumentException("End index is less than start " + e + ": " + n);
        }
        this.C = ((charSequence != null) ? charSequence : "");
        this.D = e;
        this.B = n;
        this.A = e;
        this.E = e;
    }
    
    private int A() {
        return Math.min(this.C.length(), this.D);
    }
    
    private int B() {
        return Math.min(this.C.length(), (this.B == null) ? Integer.MAX_VALUE : ((int)this.B));
    }
    
    @Override
    public void close() {
        this.A = this.D;
        this.E = this.D;
    }
    
    @Override
    public boolean ready() {
        return this.A < this.B();
    }
    
    @Override
    public void mark(final int n) {
        this.E = this.A;
    }
    
    @Override
    public boolean markSupported() {
        return true;
    }
    
    @Override
    public int read() {
        if (this.A >= this.B()) {
            return -1;
        }
        return this.C.charAt(this.A++);
    }
    
    @Override
    public int read(final char[] dst, final int dstBegin, final int n) {
        if (this.A >= this.B()) {
            return -1;
        }
        Objects.requireNonNull(dst, "array");
        if (n < 0 || dstBegin < 0 || dstBegin + n > dst.length) {
            throw new IndexOutOfBoundsException("Array Size=" + dst.length + ", offset=" + dstBegin + ", length=" + n);
        }
        if (this.C instanceof String) {
            final int min = Math.min(n, this.B() - this.A);
            ((String)this.C).getChars(this.A, this.A + min, dst, dstBegin);
            this.A += min;
            return min;
        }
        if (this.C instanceof StringBuilder) {
            final int min2 = Math.min(n, this.B() - this.A);
            ((StringBuilder)this.C).getChars(this.A, this.A + min2, dst, dstBegin);
            this.A += min2;
            return min2;
        }
        if (this.C instanceof StringBuffer) {
            final int min3 = Math.min(n, this.B() - this.A);
            ((StringBuffer)this.C).getChars(this.A, this.A + min3, dst, dstBegin);
            this.A += min3;
            return min3;
        }
        int n2 = 0;
        for (int i = 0; i < n; ++i) {
            final int read = this.read();
            if (read == -1) {
                return n2;
            }
            dst[dstBegin + i] = (char)read;
            ++n2;
        }
        return n2;
    }
    
    @Override
    public void reset() {
        this.A = this.E;
    }
    
    @Override
    public long skip(final long lng) {
        if (lng < 0L) {
            throw new IllegalArgumentException("Number of characters to skip is less than zero: " + lng);
        }
        if (this.A >= this.B()) {
            return 0L;
        }
        final int a = (int)Math.min(this.B(), this.A + lng);
        final int n = a - this.A;
        this.A = a;
        return n;
    }
    
    @Override
    public String toString() {
        return this.C.subSequence(this.A(), this.B()).toString();
    }
}
