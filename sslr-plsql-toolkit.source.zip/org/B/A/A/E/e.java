// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.Closeable;
import org.B.A.A.W;
import java.io.IOException;
import java.io.Writer;
import java.io.FilterWriter;

public class e extends FilterWriter
{
    public e(final Writer out) {
        super(out);
    }
    
    @Override
    public Writer append(final char c) throws IOException {
        try {
            this.A(1);
            this.out.append(c);
            this.B(1);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
        return this;
    }
    
    @Override
    public Writer append(final CharSequence csq, final int start, final int end) throws IOException {
        try {
            this.A(end - start);
            this.out.append(csq, start, end);
            this.B(end - start);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
        return this;
    }
    
    @Override
    public Writer append(final CharSequence csq) throws IOException {
        try {
            final int b = W.B(csq);
            this.A(b);
            this.out.append(csq);
            this.B(b);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
        return this;
    }
    
    @Override
    public void write(final int c) throws IOException {
        try {
            this.A(1);
            this.out.write(c);
            this.B(1);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void write(final char[] cbuf) throws IOException {
        try {
            final int a = W.A(cbuf);
            this.A(a);
            this.out.write(cbuf);
            this.B(a);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void write(final char[] array, final int n, final int n2) throws IOException {
        try {
            this.A(n2);
            this.out.write(array, n, n2);
            this.B(n2);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void write(final String str) throws IOException {
        try {
            final int b = W.B((CharSequence)str);
            this.A(b);
            this.out.write(str);
            this.B(b);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void write(final String str, final int off, final int len) throws IOException {
        try {
            this.A(len);
            this.out.write(str, off, len);
            this.B(len);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void flush() throws IOException {
        try {
            this.out.flush();
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void close() throws IOException {
        W.A(this.out, this::A);
    }
    
    protected void A(final int n) throws IOException {
    }
    
    protected void B(final int n) throws IOException {
    }
    
    protected void A(final IOException ex) throws IOException {
        throw ex;
    }
}
