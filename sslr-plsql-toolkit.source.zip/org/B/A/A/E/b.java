// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import org.B.A.A.F.m;
import java.util.regex.Matcher;
import java.util.Locale;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.File;
import java.util.regex.Pattern;
import java.io.StringWriter;
import java.io.OutputStream;
import java.io.Writer;

public class b extends Writer
{
    private static final int F = 8192;
    private final OutputStream A;
    private final String E;
    private StringWriter B;
    private Writer G;
    private String D;
    static final Pattern C;
    
    public b(final OutputStream outputStream) {
        this(outputStream, null);
    }
    
    public b(final OutputStream a, final String s) {
        this.B = new StringWriter(8192);
        this.A = a;
        this.E = ((s != null) ? s : "UTF-8");
    }
    
    public b(final File file) throws FileNotFoundException {
        this(file, null);
    }
    
    public b(final File file, final String s) throws FileNotFoundException {
        this(new FileOutputStream(file), s);
    }
    
    public String A() {
        return this.D;
    }
    
    public String B() {
        return this.E;
    }
    
    @Override
    public void close() throws IOException {
        if (this.G == null) {
            this.D = this.E;
            (this.G = new OutputStreamWriter(this.A, this.D)).write(this.B.toString());
        }
        this.G.close();
    }
    
    @Override
    public void flush() throws IOException {
        if (this.G != null) {
            this.G.flush();
        }
    }
    
    private void A(final char[] cbuf, final int off, final int n) throws IOException {
        int len = n;
        final StringBuffer buffer = this.B.getBuffer();
        if (buffer.length() + n > 8192) {
            len = 8192 - buffer.length();
        }
        this.B.write(cbuf, off, len);
        if (buffer.length() >= 5) {
            if (buffer.substring(0, 5).equals("<?xml")) {
                final int index = buffer.indexOf("?>");
                if (index > 0) {
                    final Matcher matcher = b.C.matcher(buffer.substring(0, index));
                    if (matcher.find()) {
                        this.D = matcher.group(1).toUpperCase(Locale.ROOT);
                        this.D = this.D.substring(1, this.D.length() - 1);
                    }
                    else {
                        this.D = this.E;
                    }
                }
                else if (buffer.length() >= 8192) {
                    this.D = this.E;
                }
            }
            else {
                this.D = this.E;
            }
            if (this.D != null) {
                this.B = null;
                (this.G = new OutputStreamWriter(this.A, this.D)).write(buffer.toString());
                if (n > len) {
                    this.G.write(cbuf, off + len, n - len);
                }
            }
        }
    }
    
    @Override
    public void write(final char[] array, final int n, final int n2) throws IOException {
        if (this.B != null) {
            this.A(array, n, n2);
        }
        else {
            this.G.write(array, n, n2);
        }
    }
    
    static {
        C = m.C;
    }
}
