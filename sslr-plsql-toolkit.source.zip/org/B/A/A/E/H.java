// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.Writer;

public class H extends e
{
    public static H A(final Writer writer) {
        return new H(writer);
    }
    
    @Deprecated
    public H(final Writer writer) {
        super(writer);
    }
    
    @Override
    public void close() {
        this.out = N.A;
    }
}
