// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.Enumeration;
import java.io.SequenceInputStream;
import java.util.Collection;
import java.util.Collections;
import org.B.A.A.F.P;
import java.util.Iterator;
import java.io.IOException;
import java.io.InputStream;
import org.B.A.A.W;
import java.util.ArrayList;
import java.util.List;
import java.io.OutputStream;

public abstract class B extends OutputStream
{
    static final int C = 1024;
    private final List<byte[]> B;
    private int D;
    private int F;
    private byte[] G;
    protected int E;
    private boolean A;
    
    public B() {
        this.B = new ArrayList<byte[]>();
        this.A = true;
    }
    
    protected void A(final int n) {
        if (this.D < this.B.size() - 1) {
            this.F += this.G.length;
            ++this.D;
            this.G = this.B.get(this.D);
        }
        else {
            int max;
            if (this.G == null) {
                max = n;
                this.F = 0;
            }
            else {
                max = Math.max(this.G.length << 1, n - this.F);
                this.F += this.G.length;
            }
            ++this.D;
            this.G = W.B(max);
            this.B.add(this.G);
        }
    }
    
    @Override
    public abstract void write(final byte[] p0, final int p1, final int p2);
    
    protected void A(final byte[] array, final int n, final int n2) {
        final int e = this.E + n2;
        int i = n2;
        int n3 = this.E - this.F;
        while (i > 0) {
            final int min = Math.min(i, this.G.length - n3);
            System.arraycopy(array, n + n2 - i, this.G, n3, min);
            i -= min;
            if (i > 0) {
                this.A(e);
                n3 = 0;
            }
        }
        this.E = e;
    }
    
    @Override
    public abstract void write(final int p0);
    
    protected void B(final int n) {
        int n2 = this.E - this.F;
        if (n2 == this.G.length) {
            this.A(this.E + 1);
            n2 = 0;
        }
        this.G[n2] = (byte)n;
        ++this.E;
    }
    
    public abstract int A(final InputStream p0) throws IOException;
    
    protected int B(final InputStream inputStream) throws IOException {
        int n = 0;
        for (int n2 = this.E - this.F, i = inputStream.read(this.G, n2, this.G.length - n2); i != -1; i = inputStream.read(this.G, n2, this.G.length - n2)) {
            n += i;
            n2 += i;
            this.E += i;
            if (n2 == this.G.length) {
                this.A(this.G.length);
                n2 = 0;
            }
        }
        return n;
    }
    
    public abstract int D();
    
    @Override
    public void close() throws IOException {
    }
    
    public abstract void A();
    
    protected void C() {
        this.E = 0;
        this.F = 0;
        this.D = 0;
        if (this.A) {
            this.G = this.B.get(this.D);
        }
        else {
            this.G = null;
            final int length = this.B.get(0).length;
            this.B.clear();
            this.A(length);
            this.A = true;
        }
    }
    
    public abstract void A(final OutputStream p0) throws IOException;
    
    protected void B(final OutputStream outputStream) throws IOException {
        int e = this.E;
        for (final byte[] b : this.B) {
            final int min = Math.min(b.length, e);
            outputStream.write(b, 0, min);
            e -= min;
            if (e == 0) {
                break;
            }
        }
    }
    
    public abstract InputStream B();
    
    protected <T extends InputStream> InputStream A(final _A<T> a) {
        int e = this.E;
        if (e == 0) {
            return P.A;
        }
        final ArrayList c = new ArrayList(this.B.size());
        for (final byte[] array : this.B) {
            final int min = Math.min(array.length, e);
            c.add(a.A(array, 0, min));
            e -= min;
            if (e == 0) {
                break;
            }
        }
        this.A = false;
        return new SequenceInputStream((Enumeration<? extends InputStream>)Collections.enumeration((Collection<Object>)c));
    }
    
    public abstract byte[] F();
    
    protected byte[] E() {
        int e = this.E;
        if (e == 0) {
            return W.I;
        }
        final byte[] b = W.B(e);
        int n = 0;
        for (final byte[] array : this.B) {
            final int min = Math.min(array.length, e);
            System.arraycopy(array, 0, b, n, min);
            n += min;
            e -= min;
            if (e == 0) {
                break;
            }
        }
        return b;
    }
    
    @Deprecated
    @Override
    public String toString() {
        return new String(this.F(), Charset.defaultCharset());
    }
    
    public String A(final String charsetName) throws UnsupportedEncodingException {
        return new String(this.F(), charsetName);
    }
    
    public String A(final Charset charset) {
        return new String(this.F(), charset);
    }
    
    @FunctionalInterface
    protected interface _A<T extends InputStream>
    {
        T A(final byte[] p0, final int p1, final int p2);
    }
}
