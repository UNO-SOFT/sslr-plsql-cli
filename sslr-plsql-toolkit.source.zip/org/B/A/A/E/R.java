// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import org.B.A.A.G;
import java.util.UUID;
import java.io.OutputStream;
import java.io.Serializable;

public class R extends X
{
    private final Serializable B;
    
    public R(final OutputStream outputStream) {
        super(outputStream);
        this.B = UUID.randomUUID();
    }
    
    public boolean B(final Exception ex) {
        return G.A(ex, this.B);
    }
    
    public void A(final Exception ex) throws IOException {
        G.B(ex, this.B);
    }
    
    @Override
    protected void A(final IOException ex) throws IOException {
        throw new G(ex, this.B);
    }
}
