// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import org.B.A.A.G;
import java.util.UUID;
import java.io.Writer;
import java.io.Serializable;

public class F extends e
{
    private final Serializable A;
    
    public F(final Writer writer) {
        super(writer);
        this.A = UUID.randomUUID();
    }
    
    public boolean B(final Exception ex) {
        return G.A(ex, this.A);
    }
    
    public void A(final Exception ex) throws IOException {
        G.B(ex, this.A);
    }
    
    @Override
    protected void A(final IOException ex) throws IOException {
        throw new G(ex, this.A);
    }
}
