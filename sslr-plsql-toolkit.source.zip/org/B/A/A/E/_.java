// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import java.io.Serializable;
import java.io.Writer;

public class _ extends Writer implements Serializable
{
    private static final long B = -146927496096066153L;
    private final StringBuilder A;
    
    public _() {
        this.A = new StringBuilder();
    }
    
    public _(final int capacity) {
        this.A = new StringBuilder(capacity);
    }
    
    public _(final StringBuilder sb) {
        this.A = ((sb != null) ? sb : new StringBuilder());
    }
    
    @Override
    public Writer append(final char c) {
        this.A.append(c);
        return this;
    }
    
    @Override
    public Writer append(final CharSequence s) {
        this.A.append(s);
        return this;
    }
    
    @Override
    public Writer append(final CharSequence s, final int start, final int end) {
        this.A.append(s, start, end);
        return this;
    }
    
    @Override
    public void close() {
    }
    
    @Override
    public void flush() {
    }
    
    @Override
    public void write(final String str) {
        if (str != null) {
            this.A.append(str);
        }
    }
    
    @Override
    public void write(final char[] str, final int offset, final int len) {
        if (str != null) {
            this.A.append(str, offset, len);
        }
    }
    
    public StringBuilder A() {
        return this.A;
    }
    
    @Override
    public String toString() {
        return this.A.toString();
    }
}
