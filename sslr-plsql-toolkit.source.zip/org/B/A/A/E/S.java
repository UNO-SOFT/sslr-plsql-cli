// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import java.io.OutputStream;

public class S extends X
{
    protected OutputStream C;
    
    public S(final OutputStream outputStream, final OutputStream c) {
        super(outputStream);
        this.C = c;
    }
    
    @Override
    public synchronized void write(final byte[] b) throws IOException {
        super.write(b);
        this.C.write(b);
    }
    
    @Override
    public synchronized void write(final byte[] b, final int off, final int len) throws IOException {
        super.write(b, off, len);
        this.C.write(b, off, len);
    }
    
    @Override
    public synchronized void write(final int n) throws IOException {
        super.write(n);
        this.C.write(n);
    }
    
    @Override
    public void flush() throws IOException {
        super.flush();
        this.C.flush();
    }
    
    @Override
    public void close() throws IOException {
        try {
            super.close();
        }
        finally {
            this.C.close();
        }
    }
}
