// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import org.B.A.A.W;
import java.io.IOException;
import java.io.Writer;
import java.util.Collection;

public class I extends J
{
    public I(final Collection<Writer> collection) {
        super(collection);
    }
    
    public I(final Writer... array) {
        super(array);
    }
    
    protected void B(final int n) throws IOException {
    }
    
    @Override
    public Writer append(final char c) throws IOException {
        try {
            this.A(1);
            super.append(c);
            this.B(1);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
        return this;
    }
    
    @Override
    public Writer append(final CharSequence charSequence) throws IOException {
        try {
            final int b = W.B(charSequence);
            this.A(b);
            super.append(charSequence);
            this.B(b);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
        return this;
    }
    
    @Override
    public Writer append(final CharSequence charSequence, final int n, final int n2) throws IOException {
        try {
            this.A(n2 - n);
            super.append(charSequence, n, n2);
            this.B(n2 - n);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
        return this;
    }
    
    protected void A(final int n) throws IOException {
    }
    
    @Override
    public void close() throws IOException {
        try {
            super.close();
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void flush() throws IOException {
        try {
            super.flush();
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    protected void A(final IOException ex) throws IOException {
        throw ex;
    }
    
    @Override
    public void write(final char[] array) throws IOException {
        try {
            final int a = W.A(array);
            this.A(a);
            super.write(array);
            this.B(a);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void write(final char[] array, final int n, final int n2) throws IOException {
        try {
            this.A(n2);
            super.write(array, n, n2);
            this.B(n2);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void write(final int n) throws IOException {
        try {
            this.A(1);
            super.write(n);
            this.B(1);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void write(final String s) throws IOException {
        try {
            final int b = W.B((CharSequence)s);
            this.A(b);
            super.write(s);
            this.B(b);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void write(final String s, final int n, final int n2) throws IOException {
        try {
            this.A(n2);
            super.write(s, n, n2);
            this.B(n2);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
}
