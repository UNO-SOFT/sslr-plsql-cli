// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.nio.charset.CoderResult;
import java.io.IOException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.Charset;
import java.nio.CharBuffer;
import java.nio.ByteBuffer;
import java.nio.charset.CharsetDecoder;
import java.io.Writer;
import java.io.OutputStream;

public class W extends OutputStream
{
    private static final int C = 1024;
    private final Writer E;
    private final CharsetDecoder F;
    private final boolean B;
    private final ByteBuffer D;
    private final CharBuffer A;
    
    public W(final Writer writer, final CharsetDecoder charsetDecoder) {
        this(writer, charsetDecoder, 1024, false);
    }
    
    public W(final Writer e, final CharsetDecoder f, final int capacity, final boolean b) {
        this.D = ByteBuffer.allocate(128);
        A(f.charset());
        this.E = e;
        this.F = f;
        this.B = b;
        this.A = CharBuffer.allocate(capacity);
    }
    
    public W(final Writer writer, final Charset charset, final int n, final boolean b) {
        this(writer, charset.newDecoder().onMalformedInput(CodingErrorAction.REPLACE).onUnmappableCharacter(CodingErrorAction.REPLACE).replaceWith("?"), n, b);
    }
    
    public W(final Writer writer, final Charset charset) {
        this(writer, charset, 1024, false);
    }
    
    public W(final Writer writer, final String charsetName, final int n, final boolean b) {
        this(writer, Charset.forName(charsetName), n, b);
    }
    
    public W(final Writer writer, final String s) {
        this(writer, s, 1024, false);
    }
    
    @Deprecated
    public W(final Writer writer) {
        this(writer, Charset.defaultCharset(), 1024, false);
    }
    
    @Override
    public void write(final byte[] src, int offset, int i) throws IOException {
        while (i > 0) {
            final int min = Math.min(i, this.D.remaining());
            this.D.put(src, offset, min);
            this.A(false);
            i -= min;
            offset += min;
        }
        if (this.B) {
            this.A();
        }
    }
    
    @Override
    public void write(final byte[] array) throws IOException {
        this.write(array, 0, array.length);
    }
    
    @Override
    public void write(final int n) throws IOException {
        this.write(new byte[] { (byte)n }, 0, 1);
    }
    
    @Override
    public void flush() throws IOException {
        this.A();
        this.E.flush();
    }
    
    @Override
    public void close() throws IOException {
        this.A(true);
        this.A();
        this.E.close();
    }
    
    private void A(final boolean endOfInput) throws IOException {
        this.D.flip();
        CoderResult decode;
        while (true) {
            decode = this.F.decode(this.D, this.A, endOfInput);
            if (!decode.isOverflow()) {
                break;
            }
            this.A();
        }
        if (decode.isUnderflow()) {
            this.D.compact();
            return;
        }
        throw new IOException("Unexpected coder result");
    }
    
    private void A() throws IOException {
        if (this.A.position() > 0) {
            this.E.write(this.A.array(), 0, this.A.position());
            this.A.rewind();
        }
    }
    
    private static void A(final Charset charset) {
        if (!"UTF-16".equals(charset.name())) {
            return;
        }
        final byte[] bytes = "v\u00e9s".getBytes(charset);
        final CharsetDecoder decoder = charset.newDecoder();
        final ByteBuffer allocate = ByteBuffer.allocate(16);
        final CharBuffer allocate2 = CharBuffer.allocate("v\u00e9s".length());
        for (int length = bytes.length, i = 0; i < length; ++i) {
            allocate.put(bytes[i]);
            allocate.flip();
            try {
                decoder.decode(allocate, allocate2, i == length - 1);
            }
            catch (final IllegalArgumentException ex) {
                throw new UnsupportedOperationException("UTF-16 requested when running on an IBM JDK with broken UTF-16 support. Please find a JDK that supports UTF-16 if you intend to use UF-16 with WriterOutputStream");
            }
            allocate.compact();
        }
        allocate2.rewind();
        if (!"v\u00e9s".equals(allocate2.toString())) {
            throw new UnsupportedOperationException("UTF-16 requested when running on an IBM JDK with broken UTF-16 support. Please find a JDK that supports UTF-16 if you intend to use UF-16 with WriterOutputStream");
        }
    }
}
