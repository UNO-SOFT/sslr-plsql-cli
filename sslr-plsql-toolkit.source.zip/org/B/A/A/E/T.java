// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.OutputStream;
import org.B.A.A.S;
import java.io.Closeable;
import org.B.A.A.W;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.nio.file.OpenOption;
import java.util.Objects;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.Charset;
import java.io.IOException;
import java.io.File;
import java.io.Writer;

public class T extends Writer
{
    private final Writer A;
    
    public T(final String pathname, final String s) throws IOException {
        this(new File(pathname), s, false);
    }
    
    public T(final String pathname, final String s, final boolean b) throws IOException {
        this(new File(pathname), s, b);
    }
    
    public T(final String pathname, final Charset charset) throws IOException {
        this(new File(pathname), charset, false);
    }
    
    public T(final String pathname, final Charset charset, final boolean b) throws IOException {
        this(new File(pathname), charset, b);
    }
    
    public T(final String pathname, final CharsetEncoder charsetEncoder) throws IOException {
        this(new File(pathname), charsetEncoder, false);
    }
    
    public T(final String pathname, final CharsetEncoder charsetEncoder, final boolean b) throws IOException {
        this(new File(pathname), charsetEncoder, b);
    }
    
    public T(final File file, final String s) throws IOException {
        this(file, s, false);
    }
    
    public T(final File file, final String s, final boolean b) throws IOException {
        this.A = A(file, s, b);
    }
    
    public T(final File file, final Charset charset) throws IOException {
        this(file, charset, false);
    }
    
    public T(final File file, final Charset charset, final boolean b) throws IOException {
        this.A = A(file, charset, b);
    }
    
    public T(final File file, final CharsetEncoder charsetEncoder) throws IOException {
        this(file, charsetEncoder, false);
    }
    
    public T(final File file, final CharsetEncoder charsetEncoder, final boolean b) throws IOException {
        this.A = A(file, charsetEncoder, b);
    }
    
    private static Writer A(final File obj, final Object obj2, final boolean b) throws IOException {
        Objects.requireNonNull(obj, "file");
        Objects.requireNonNull(obj2, "encoding");
        OutputStream outputStream = null;
        final boolean exists = obj.exists();
        try {
            outputStream = Files.newOutputStream(obj.toPath(), b ? StandardOpenOption.APPEND : StandardOpenOption.CREATE);
            if (obj2 instanceof Charset) {
                return new OutputStreamWriter(outputStream, (Charset)obj2);
            }
            if (obj2 instanceof CharsetEncoder) {
                return new OutputStreamWriter(outputStream, (CharsetEncoder)obj2);
            }
            return new OutputStreamWriter(outputStream, (String)obj2);
        }
        catch (final IOException | RuntimeException ex) {
            try {
                W.B((Closeable)outputStream);
            }
            catch (final IOException exception) {
                ((Throwable)ex).addSuppressed(exception);
            }
            if (!exists) {
                S.A(obj);
            }
            throw ex;
        }
    }
    
    @Override
    public void write(final int c) throws IOException {
        this.A.write(c);
    }
    
    @Override
    public void write(final char[] cbuf) throws IOException {
        this.A.write(cbuf);
    }
    
    @Override
    public void write(final char[] array, final int n, final int n2) throws IOException {
        this.A.write(array, n, n2);
    }
    
    @Override
    public void write(final String str) throws IOException {
        this.A.write(str);
    }
    
    @Override
    public void write(final String str, final int off, final int len) throws IOException {
        this.A.write(str, off, len);
    }
    
    @Override
    public void flush() throws IOException {
        this.A.flush();
    }
    
    @Override
    public void close() throws IOException {
        this.A.close();
    }
}
