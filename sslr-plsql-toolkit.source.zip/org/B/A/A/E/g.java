// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import java.io.OutputStream;

public class g<T extends Appendable> extends OutputStream
{
    private final T A;
    
    public g(final T a) {
        this.A = a;
    }
    
    @Override
    public void write(final int n) throws IOException {
        this.A.append((char)n);
    }
    
    public T A() {
        return this.A;
    }
}
