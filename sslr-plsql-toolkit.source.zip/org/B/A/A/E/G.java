// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import java.io.OutputStream;

public class G extends OutputStream
{
    public static final G A;
    
    @Override
    public void write(final int i) throws IOException {
        throw new IOException("write(" + i + ") failed: stream is closed");
    }
    
    @Override
    public void flush() throws IOException {
        throw new IOException("flush() failed: stream is closed");
    }
    
    static {
        A = new G();
    }
}
