// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import java.io.OutputStream;

public class Y extends OutputStream
{
    private final IOException A;
    
    public Y(final IOException a) {
        this.A = a;
    }
    
    public Y() {
        this(new IOException("Broken output stream"));
    }
    
    @Override
    public void write(final int n) throws IOException {
        throw this.A;
    }
    
    @Override
    public void flush() throws IOException {
        throw this.A;
    }
    
    @Override
    public void close() throws IOException {
        throw this.A;
    }
}
