// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import org.B.A.A.W;
import java.io.Closeable;
import java.io.OutputStream;

public class a extends OutputStream
{
    private final InheritableThreadLocal<OutputStream> A;
    
    public a() {
        this.A = new InheritableThreadLocal<OutputStream>();
    }
    
    public OutputStream A(final OutputStream value) {
        final OutputStream outputStream = this.A.get();
        this.A.set(value);
        return outputStream;
    }
    
    @Override
    public void close() throws IOException {
        W.B(this.A.get());
    }
    
    @Override
    public void flush() throws IOException {
        final OutputStream outputStream = this.A.get();
        if (null != outputStream) {
            outputStream.flush();
        }
    }
    
    @Override
    public void write(final int n) throws IOException {
        final OutputStream outputStream = this.A.get();
        if (null != outputStream) {
            outputStream.write(n);
        }
    }
}
