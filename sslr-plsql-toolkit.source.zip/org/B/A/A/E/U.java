// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import org.B.A.A.W;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import org.B.A.A.S;
import java.io.IOException;
import java.io.File;
import java.io.OutputStream;

public class U extends A
{
    private c M;
    private OutputStream I;
    private File L;
    private final String J;
    private final String K;
    private final File G;
    private boolean H;
    
    public U(final int n, final File file) {
        this(n, file, null, null, null, 1024);
    }
    
    private U(final int n, final File l, final String j, final String k, final File g, final int n2) {
        super(n);
        this.L = l;
        this.J = j;
        this.K = k;
        this.G = g;
        this.M = new c(n2);
        this.I = this.M;
    }
    
    public U(final int n, final int n2, final File file) {
        this(n, file, null, null, null, n2);
        if (n2 < 0) {
            throw new IllegalArgumentException("Initial buffer size must be atleast 0.");
        }
    }
    
    public U(final int n, final int n2, final String s, final String s2, final File file) {
        this(n, null, s, s2, file, n2);
        if (s == null) {
            throw new IllegalArgumentException("Temporary file prefix is missing");
        }
        if (n2 < 0) {
            throw new IllegalArgumentException("Initial buffer size must be atleast 0.");
        }
    }
    
    public U(final int n, final String s, final String s2, final File file) {
        this(n, null, s, s2, file, 1024);
        if (s == null) {
            throw new IllegalArgumentException("Temporary file prefix is missing");
        }
    }
    
    @Override
    public void close() throws IOException {
        super.close();
        this.H = true;
    }
    
    public byte[] G() {
        return (byte[])((this.M != null) ? this.M.F() : null);
    }
    
    public File I() {
        return this.L;
    }
    
    @Override
    protected OutputStream D() throws IOException {
        return this.I;
    }
    
    public boolean H() {
        return !this.B();
    }
    
    @Override
    protected void F() throws IOException {
        if (this.J != null) {
            this.L = File.createTempFile(this.J, this.K, this.G);
        }
        S.Y(this.L);
        final OutputStream outputStream = Files.newOutputStream(this.L.toPath(), new OpenOption[0]);
        try {
            this.M.A(outputStream);
        }
        catch (final IOException ex) {
            outputStream.close();
            throw ex;
        }
        this.I = outputStream;
        this.M = null;
    }
    
    public InputStream J() throws IOException {
        if (!this.H) {
            throw new IOException("Stream not closed");
        }
        if (this.H()) {
            return this.M.B();
        }
        return Files.newInputStream(this.L.toPath(), new OpenOption[0]);
    }
    
    public void A(final OutputStream outputStream) throws IOException {
        if (!this.H) {
            throw new IOException("Stream not closed");
        }
        if (this.H()) {
            this.M.A(outputStream);
        }
        else {
            try (final InputStream inputStream = Files.newInputStream(this.L.toPath(), new OpenOption[0])) {
                W.B(inputStream, outputStream);
            }
        }
    }
}
