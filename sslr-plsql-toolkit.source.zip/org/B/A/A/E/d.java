// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import org.B.A.A.F.q;
import java.io.OutputStream;
import java.io.IOException;
import java.io.InputStream;

public final class d extends B
{
    public d() {
        this(1024);
    }
    
    public d(final int i) {
        if (i < 0) {
            throw new IllegalArgumentException("Negative initial size: " + i);
        }
        this.A(i);
    }
    
    @Override
    public void write(final byte[] array, final int i, final int j) {
        if (i < 0 || i > array.length || j < 0 || i + j > array.length || i + j < 0) {
            throw new IndexOutOfBoundsException(String.format("offset=%,d, length=%,d", i, j));
        }
        if (j == 0) {
            return;
        }
        this.A(array, i, j);
    }
    
    @Override
    public void write(final int n) {
        this.B(n);
    }
    
    @Override
    public int A(final InputStream inputStream) throws IOException {
        return this.B(inputStream);
    }
    
    @Override
    public int D() {
        return this.E;
    }
    
    @Override
    public void A() {
        this.C();
    }
    
    @Override
    public void A(final OutputStream outputStream) throws IOException {
        this.B(outputStream);
    }
    
    public static InputStream D(final InputStream inputStream) throws IOException {
        return B(inputStream, 1024);
    }
    
    public static InputStream B(final InputStream inputStream, final int n) throws IOException {
        try (final d d = new d(n)) {
            d.A(inputStream);
            return d.B();
        }
    }
    
    @Override
    public InputStream B() {
        return this.A(q::new);
    }
    
    @Override
    public byte[] F() {
        return this.E();
    }
}
