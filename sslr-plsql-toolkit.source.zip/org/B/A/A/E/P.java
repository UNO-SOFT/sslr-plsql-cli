// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.OutputStream;
import java.io.PrintStream;

public class P extends PrintStream
{
    public static final P A;
    
    public P() {
        super(f.A);
    }
    
    static {
        A = new P();
    }
}
