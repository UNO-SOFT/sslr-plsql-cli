// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import java.io.Writer;

public class L extends Writer
{
    private final IOException A;
    
    public L(final IOException a) {
        this.A = a;
    }
    
    public L() {
        this(new IOException("Broken writer"));
    }
    
    @Override
    public void write(final char[] array, final int n, final int n2) throws IOException {
        throw this.A;
    }
    
    @Override
    public void flush() throws IOException {
        throw this.A;
    }
    
    @Override
    public void close() throws IOException {
        throw this.A;
    }
}
