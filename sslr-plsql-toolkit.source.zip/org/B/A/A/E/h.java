// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.Writer;
import java.util.Collection;

public class h extends I
{
    public h(final Collection<Writer> collection) {
        super(collection);
    }
    
    public h(final Writer... array) {
        super(array);
    }
}
