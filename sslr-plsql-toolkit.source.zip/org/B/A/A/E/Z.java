// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import org.B.A.A.X;
import org.B.A.A.S;
import java.nio.charset.Charset;
import java.io.IOException;
import java.io.File;
import java.io.Writer;

public class Z extends Writer
{
    private static final String C = ".lck";
    private final Writer A;
    private final File B;
    
    public Z(final String s) throws IOException {
        this(s, false, null);
    }
    
    public Z(final String s, final boolean b) throws IOException {
        this(s, b, null);
    }
    
    public Z(final String pathname, final boolean b, final String s) throws IOException {
        this(new File(pathname), b, s);
    }
    
    public Z(final File file) throws IOException {
        this(file, false, null);
    }
    
    public Z(final File file, final boolean b) throws IOException {
        this(file, b, null);
    }
    
    @Deprecated
    public Z(final File file, final boolean b, final String s) throws IOException {
        this(file, Charset.defaultCharset(), b, s);
    }
    
    public Z(final File file, final Charset charset) throws IOException {
        this(file, charset, false, null);
    }
    
    public Z(final File file, final String s) throws IOException {
        this(file, s, false, null);
    }
    
    public Z(File absoluteFile, final Charset charset, final boolean b, String property) throws IOException {
        absoluteFile = absoluteFile.getAbsoluteFile();
        if (absoluteFile.getParentFile() != null) {
            S.a(absoluteFile.getParentFile());
        }
        if (absoluteFile.isDirectory()) {
            throw new IOException("File specified is a directory");
        }
        if (property == null) {
            property = System.getProperty("java.io.tmpdir");
        }
        final File parent = new File(property);
        S.a(parent);
        this.A(parent);
        this.B = new File(parent, absoluteFile.getName() + ".lck");
        this.A();
        this.A = this.A(absoluteFile, charset, b);
    }
    
    public Z(final File file, final String s, final boolean b, final String s2) throws IOException {
        this(file, X.A(s), b, s2);
    }
    
    private void A(final File file) throws IOException {
        if (!file.exists()) {
            throw new IOException("Could not find lockDir: " + file.getAbsolutePath());
        }
        if (!file.canWrite()) {
            throw new IOException("Could not write to lockDir: " + file.getAbsolutePath());
        }
    }
    
    private void A() throws IOException {
        synchronized (Z.class) {
            if (!this.B.createNewFile()) {
                throw new IOException("Can't write file, lock " + this.B.getAbsolutePath() + " exists");
            }
            this.B.deleteOnExit();
        }
    }
    
    private Writer A(final File file, final Charset charset, final boolean append) throws IOException {
        final boolean exists = file.exists();
        try {
            return new OutputStreamWriter(new FileOutputStream(file.getAbsolutePath(), append), X.A(charset));
        }
        catch (final IOException | RuntimeException ex) {
            S.A(this.B);
            if (!exists) {
                S.A(file);
            }
            throw ex;
        }
    }
    
    @Override
    public void close() throws IOException {
        try {
            this.A.close();
        }
        finally {
            S.H(this.B);
        }
    }
    
    @Override
    public void write(final int c) throws IOException {
        this.A.write(c);
    }
    
    @Override
    public void write(final char[] cbuf) throws IOException {
        this.A.write(cbuf);
    }
    
    @Override
    public void write(final char[] array, final int n, final int n2) throws IOException {
        this.A.write(array, n, n2);
    }
    
    @Override
    public void write(final String str) throws IOException {
        this.A.write(str);
    }
    
    @Override
    public void write(final String str, final int off, final int len) throws IOException {
        this.A.write(str, off, len);
    }
    
    @Override
    public void flush() throws IOException {
        this.A.flush();
    }
}
