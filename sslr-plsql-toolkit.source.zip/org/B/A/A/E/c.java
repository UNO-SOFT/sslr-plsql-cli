// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.io.InputStream;

public class c extends B
{
    public c() {
        this(1024);
    }
    
    public c(final int i) {
        if (i < 0) {
            throw new IllegalArgumentException("Negative initial size: " + i);
        }
        synchronized (this) {
            this.A(i);
        }
    }
    
    @Override
    public void write(final byte[] array, final int n, final int n2) {
        if (n < 0 || n > array.length || n2 < 0 || n + n2 > array.length || n + n2 < 0) {
            throw new IndexOutOfBoundsException();
        }
        if (n2 == 0) {
            return;
        }
        synchronized (this) {
            this.A(array, n, n2);
        }
    }
    
    @Override
    public synchronized void write(final int n) {
        this.B(n);
    }
    
    @Override
    public synchronized int A(final InputStream inputStream) throws IOException {
        return this.B(inputStream);
    }
    
    @Override
    public synchronized int D() {
        return this.E;
    }
    
    @Override
    public synchronized void A() {
        this.C();
    }
    
    @Override
    public synchronized void A(final OutputStream outputStream) throws IOException {
        this.B(outputStream);
    }
    
    public static InputStream C(final InputStream inputStream) throws IOException {
        return A(inputStream, 1024);
    }
    
    public static InputStream A(final InputStream inputStream, final int n) throws IOException {
        try (final c c = new c(n)) {
            c.A(inputStream);
            return c.B();
        }
    }
    
    @Override
    public synchronized InputStream B() {
        return this.A(ByteArrayInputStream::new);
    }
    
    @Override
    public synchronized byte[] F() {
        return this.E();
    }
}
