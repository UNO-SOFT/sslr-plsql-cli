// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.util.Iterator;
import org.B.A.A.H;
import org.B.A.A.U;
import java.util.ArrayList;
import java.io.IOException;
import java.util.List;
import java.util.Arrays;
import java.util.Collections;
import java.util.Collection;
import java.io.Writer;

public class J extends Writer
{
    protected final Collection<Writer> B;
    protected final Collection<Writer> A;
    
    protected J(final Collection<Writer> collection) {
        this.B = (Collection<Writer>)Collections.emptyList();
        this.A = ((collection == null) ? this.B : collection);
    }
    
    protected J(final Writer... a) {
        this.B = (Collection<Writer>)Collections.emptyList();
        this.A = ((a == null) ? this.B : Arrays.asList(a));
    }
    
    private List<Exception> A(List<Exception> list, final int n, final IOException ex) {
        if (list == null) {
            list = new ArrayList<U>();
        }
        list.add(new U(n, ex));
        return (List<Exception>)list;
    }
    
    @Override
    public Writer append(final char c) throws IOException {
        List<Exception> a = null;
        int n = 0;
        for (final Writer writer : this.A) {
            if (writer != null) {
                try {
                    writer.append(c);
                }
                catch (final IOException ex) {
                    a = this.A(a, n, ex);
                }
            }
            ++n;
        }
        if (this.A(a)) {
            throw new H("append", a);
        }
        return this;
    }
    
    @Override
    public Writer append(final CharSequence csq) throws IOException {
        List<Exception> a = null;
        int n = 0;
        for (final Writer writer : this.A) {
            if (writer != null) {
                try {
                    writer.append(csq);
                }
                catch (final IOException ex) {
                    a = this.A(a, n, ex);
                }
            }
            ++n;
        }
        if (this.A(a)) {
            throw new H("append", a);
        }
        return this;
    }
    
    @Override
    public Writer append(final CharSequence csq, final int start, final int end) throws IOException {
        List<Exception> a = null;
        int n = 0;
        for (final Writer writer : this.A) {
            if (writer != null) {
                try {
                    writer.append(csq, start, end);
                }
                catch (final IOException ex) {
                    a = this.A(a, n, ex);
                }
            }
            ++n;
        }
        if (this.A(a)) {
            throw new H("append", a);
        }
        return this;
    }
    
    @Override
    public void close() throws IOException {
        List<Exception> a = null;
        int n = 0;
        for (final Writer writer : this.A) {
            if (writer != null) {
                try {
                    writer.close();
                }
                catch (final IOException ex) {
                    a = this.A(a, n, ex);
                }
            }
            ++n;
        }
        if (this.A(a)) {
            throw new H("close", a);
        }
    }
    
    @Override
    public void flush() throws IOException {
        List<Exception> a = null;
        int n = 0;
        for (final Writer writer : this.A) {
            if (writer != null) {
                try {
                    writer.flush();
                }
                catch (final IOException ex) {
                    a = this.A(a, n, ex);
                }
            }
            ++n;
        }
        if (this.A(a)) {
            throw new H("flush", a);
        }
    }
    
    private boolean A(final List<Exception> list) {
        return list != null && !list.isEmpty();
    }
    
    @Override
    public void write(final char[] cbuf) throws IOException {
        List<Exception> a = null;
        int n = 0;
        for (final Writer writer : this.A) {
            if (writer != null) {
                try {
                    writer.write(cbuf);
                }
                catch (final IOException ex) {
                    a = this.A(a, n, ex);
                }
            }
            ++n;
        }
        if (this.A(a)) {
            throw new H("write", a);
        }
    }
    
    @Override
    public void write(final char[] array, final int n, final int n2) throws IOException {
        List<Exception> a = null;
        int n3 = 0;
        for (final Writer writer : this.A) {
            if (writer != null) {
                try {
                    writer.write(array, n, n2);
                }
                catch (final IOException ex) {
                    a = this.A(a, n3, ex);
                }
            }
            ++n3;
        }
        if (this.A(a)) {
            throw new H("write", a);
        }
    }
    
    @Override
    public void write(final int c) throws IOException {
        List<Exception> a = null;
        int n = 0;
        for (final Writer writer : this.A) {
            if (writer != null) {
                try {
                    writer.write(c);
                }
                catch (final IOException ex) {
                    a = this.A(a, n, ex);
                }
            }
            ++n;
        }
        if (this.A(a)) {
            throw new H("write", a);
        }
    }
    
    @Override
    public void write(final String str) throws IOException {
        List<Exception> a = null;
        int n = 0;
        for (final Writer writer : this.A) {
            if (writer != null) {
                try {
                    writer.write(str);
                }
                catch (final IOException ex) {
                    a = this.A(a, n, ex);
                }
            }
            ++n;
        }
        if (this.A(a)) {
            throw new H("write", a);
        }
    }
    
    @Override
    public void write(final String str, final int off, final int len) throws IOException {
        List<Exception> a = null;
        int n = 0;
        for (final Writer writer : this.A) {
            if (writer != null) {
                try {
                    writer.write(str, off, len);
                }
                catch (final IOException ex) {
                    a = this.A(a, n, ex);
                }
            }
            ++n;
        }
        if (this.A(a)) {
            throw new H("write", a);
        }
    }
}
