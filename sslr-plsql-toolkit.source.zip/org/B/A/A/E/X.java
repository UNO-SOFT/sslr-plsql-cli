// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.Closeable;
import org.B.A.A.W;
import java.io.IOException;
import java.io.OutputStream;
import java.io.FilterOutputStream;

public class X extends FilterOutputStream
{
    public X(final OutputStream out) {
        super(out);
    }
    
    @Override
    public void write(final int n) throws IOException {
        try {
            this.A(1);
            this.out.write(n);
            this.B(1);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void write(final byte[] b) throws IOException {
        try {
            final int b2 = W.B(b);
            this.A(b2);
            this.out.write(b);
            this.B(b2);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void write(final byte[] b, final int off, final int len) throws IOException {
        try {
            this.A(len);
            this.out.write(b, off, len);
            this.B(len);
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void flush() throws IOException {
        try {
            this.out.flush();
        }
        catch (final IOException ex) {
            this.A(ex);
        }
    }
    
    @Override
    public void close() throws IOException {
        W.A(this.out, this::A);
    }
    
    protected void A(final int n) throws IOException {
    }
    
    protected void B(final int n) throws IOException {
    }
    
    protected void A(final IOException ex) throws IOException {
        throw ex;
    }
}
