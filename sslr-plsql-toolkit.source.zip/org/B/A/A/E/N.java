// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import java.io.Writer;

public class N extends Writer
{
    public static final N A;
    
    @Override
    public void write(final char[] value, final int i, final int j) throws IOException {
        throw new IOException("write(" + new String(value) + ", " + i + ", " + j + ") failed: stream is closed");
    }
    
    @Override
    public void flush() throws IOException {
        throw new IOException("flush() failed: stream is closed");
    }
    
    @Override
    public void close() throws IOException {
    }
    
    static {
        A = new N();
    }
}
