// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.OutputStream;

public class D extends X
{
    public static D A(final OutputStream outputStream) {
        return new D(outputStream);
    }
    
    @Deprecated
    public D(final OutputStream outputStream) {
        super(outputStream);
    }
    
    @Override
    public void close() {
        this.out = G.A;
    }
}
