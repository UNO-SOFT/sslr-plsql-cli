// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import java.io.Writer;
import java.io.FilterWriter;

public class M extends FilterWriter
{
    private static final int A = 4096;
    private final int B;
    
    public M(final Writer out, final int b) {
        super(out);
        if (b <= 0) {
            throw new IllegalArgumentException();
        }
        this.B = b;
    }
    
    public M(final Writer writer) {
        this(writer, 4096);
    }
    
    @Override
    public void write(final char[] array, final int n, final int n2) throws IOException {
        int min;
        for (int i = n2, n3 = n; i > 0; i -= min, n3 += min) {
            min = Math.min(i, this.B);
            this.out.write(array, n3, min);
        }
    }
}
