// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.InputStream;

@FunctionalInterface
protected interface _A<T extends InputStream>
{
    T A(final byte[] p0, final int p1, final int p2);
}
