// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import java.io.OutputStream;

public class f extends OutputStream
{
    public static final f A;
    
    @Deprecated
    public f() {
    }
    
    @Override
    public void write(final byte[] array, final int n, final int n2) {
    }
    
    @Override
    public void write(final int n) {
    }
    
    @Override
    public void write(final byte[] array) throws IOException {
    }
    
    static {
        A = new f();
    }
}
