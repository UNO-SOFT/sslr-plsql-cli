// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import org.B.A.A.C.C;
import java.io.OutputStream;

public class A extends OutputStream
{
    private static final C<A, OutputStream> E;
    private final int B;
    private final org.B.A.A.C.A<A> D;
    private final C<A, OutputStream> A;
    private long C;
    private boolean F;
    
    public A(final int n) {
        this(n, org.B.A.A.C.A.A(), org.B.A.A.E.A.E);
    }
    
    public A(final int b, final org.B.A.A.C.A<A> a, final C<A, OutputStream> c) {
        this.B = b;
        this.D = ((a == null) ? org.B.A.A.C.A.A() : a);
        this.A = ((c == null) ? org.B.A.A.E.A.E : c);
    }
    
    protected void A(final int n) throws IOException {
        if (!this.F && this.C + n > this.B) {
            this.F = true;
            this.F();
        }
    }
    
    @Override
    public void close() throws IOException {
        try {
            this.flush();
        }
        catch (final IOException ex) {}
        this.D().close();
    }
    
    @Override
    public void flush() throws IOException {
        this.D().flush();
    }
    
    public long C() {
        return this.C;
    }
    
    protected OutputStream D() throws IOException {
        return this.A.B(this);
    }
    
    public int A() {
        return this.B;
    }
    
    public boolean B() {
        return this.C > this.B;
    }
    
    protected void E() {
        this.F = false;
        this.C = 0L;
    }
    
    protected void A(final long c) {
        this.C = c;
    }
    
    protected void F() throws IOException {
        this.D.B(this);
    }
    
    @Override
    public void write(final byte[] b) throws IOException {
        this.A(b.length);
        this.D().write(b);
        this.C += b.length;
    }
    
    @Override
    public void write(final byte[] b, final int off, final int len) throws IOException {
        this.A(len);
        this.D().write(b, off, len);
        this.C += len;
    }
    
    @Override
    public void write(final int n) throws IOException {
        this.A(1);
        this.D().write(n);
        ++this.C;
    }
    
    static {
        E = (p0 -> f.A);
    }
}
