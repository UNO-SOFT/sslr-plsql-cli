// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;

public class C implements Appendable
{
    public static final C A;
    
    private C() {
    }
    
    @Override
    public Appendable append(final char c) throws IOException {
        return this;
    }
    
    @Override
    public Appendable append(final CharSequence charSequence) throws IOException {
        return this;
    }
    
    @Override
    public Appendable append(final CharSequence charSequence, final int n, final int n2) throws IOException {
        return this;
    }
    
    static {
        A = new C();
    }
}
