// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.InterruptedIOException;
import org.B.A.A.F.n;
import java.util.Objects;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.io.OutputStream;

public class V extends OutputStream
{
    private final BlockingQueue<Integer> A;
    
    public V() {
        this(new LinkedBlockingQueue<Integer>());
    }
    
    public V(final BlockingQueue<Integer> obj) {
        this.A = Objects.requireNonNull(obj, "blockingQueue");
    }
    
    public n A() {
        return new n(this.A);
    }
    
    @Override
    public void write(final int n) throws InterruptedIOException {
        try {
            this.A.put(0xFF & n);
        }
        catch (final InterruptedException cause) {
            Thread.currentThread().interrupt();
            final InterruptedIOException ex = new InterruptedIOException();
            ex.initCause(cause);
            throw ex;
        }
    }
}
