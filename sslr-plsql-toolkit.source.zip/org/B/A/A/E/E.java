// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.OutputStream;

public class E extends X
{
    private long A;
    
    public E(final OutputStream outputStream) {
        super(outputStream);
    }
    
    @Override
    protected synchronized void A(final int n) {
        this.A += n;
    }
    
    public int C() {
        final long d = this.D();
        if (d > 2147483647L) {
            throw new ArithmeticException("The byte count " + d + " is too large to be converted to an int");
        }
        return (int)d;
    }
    
    public int A() {
        final long b = this.B();
        if (b > 2147483647L) {
            throw new ArithmeticException("The byte count " + b + " is too large to be converted to an int");
        }
        return (int)b;
    }
    
    public synchronized long D() {
        return this.A;
    }
    
    public synchronized long B() {
        final long a = this.A;
        this.A = 0L;
        return a;
    }
}
