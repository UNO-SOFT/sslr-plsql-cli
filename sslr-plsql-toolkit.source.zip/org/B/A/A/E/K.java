// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.io.IOException;
import java.io.OutputStream;
import java.io.FilterOutputStream;

public class K extends FilterOutputStream
{
    private static final int A = 4096;
    private final int B;
    
    public K(final OutputStream out, final int b) {
        super(out);
        if (b <= 0) {
            throw new IllegalArgumentException();
        }
        this.B = b;
    }
    
    public K(final OutputStream outputStream) {
        this(outputStream, 4096);
    }
    
    @Override
    public void write(final byte[] b, final int n, final int n2) throws IOException {
        int min;
        for (int i = n2, off = n; i > 0; i -= min, off += min) {
            min = Math.min(i, this.B);
            this.out.write(b, off, min);
        }
    }
}
