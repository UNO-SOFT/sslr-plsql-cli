// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.E;

import java.util.Objects;
import java.io.IOException;
import java.io.Writer;

public class Q<T extends Appendable> extends Writer
{
    private final T A;
    
    public Q(final T a) {
        this.A = a;
    }
    
    @Override
    public Writer append(final char c) throws IOException {
        this.A.append(c);
        return this;
    }
    
    @Override
    public Writer append(final CharSequence charSequence) throws IOException {
        this.A.append(charSequence);
        return this;
    }
    
    @Override
    public Writer append(final CharSequence charSequence, final int n, final int n2) throws IOException {
        this.A.append(charSequence, n, n2);
        return this;
    }
    
    @Override
    public void close() throws IOException {
    }
    
    @Override
    public void flush() throws IOException {
    }
    
    public T A() {
        return this.A;
    }
    
    @Override
    public void write(final char[] obj, final int i, final int j) throws IOException {
        Objects.requireNonNull(obj, "Character array is missing");
        if (j < 0 || i + j > obj.length) {
            throw new IndexOutOfBoundsException("Array Size=" + obj.length + ", offset=" + i + ", length=" + j);
        }
        for (int k = 0; k < j; ++k) {
            this.A.append(obj[i + k]);
        }
    }
    
    @Override
    public void write(final int n) throws IOException {
        this.A.append((char)n);
    }
    
    @Override
    public void write(final String obj, final int n, final int n2) throws IOException {
        Objects.requireNonNull(obj, "String is missing");
        this.A.append(obj, n, n + n2);
    }
}
