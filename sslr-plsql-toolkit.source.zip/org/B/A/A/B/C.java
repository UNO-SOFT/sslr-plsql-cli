// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.B;

import java.util.Arrays;
import java.util.Iterator;
import org.B.A.A.S;
import java.util.concurrent.CopyOnWriteArrayList;
import java.io.File;
import java.util.Comparator;
import java.io.FileFilter;
import java.util.List;
import java.io.Serializable;

public class C implements Serializable
{
    private static final long E = 1185122225658782848L;
    private final List<D> C;
    private final E B;
    private final FileFilter D;
    private final Comparator<File> A;
    
    public C(final String pathname) {
        this(new File(pathname));
    }
    
    public C(final String pathname, final FileFilter fileFilter) {
        this(new File(pathname), fileFilter);
    }
    
    public C(final String pathname, final FileFilter fileFilter, final org.B.A.A.D d) {
        this(new File(pathname), fileFilter, d);
    }
    
    public C(final File file) {
        this(file, null);
    }
    
    public C(final File file, final FileFilter fileFilter) {
        this(file, fileFilter, null);
    }
    
    public C(final File file, final FileFilter fileFilter, final org.B.A.A.D d) {
        this(new E(file), fileFilter, d);
    }
    
    protected C(final E b, final FileFilter d, final org.B.A.A.D d2) {
        this.C = new CopyOnWriteArrayList<D>();
        if (b == null) {
            throw new IllegalArgumentException("Root entry is missing");
        }
        if (b.H() == null) {
            throw new IllegalArgumentException("Root directory is missing");
        }
        this.B = b;
        this.D = d;
        if (d2 == null || d2.equals(org.B.A.A.D.D)) {
            this.A = org.B.A.A.D.E.V;
        }
        else if (d2.equals(org.B.A.A.D.E)) {
            this.A = org.B.A.A.D.E.S;
        }
        else {
            this.A = org.B.A.A.D.E.W;
        }
    }
    
    public File F() {
        return this.B.H();
    }
    
    public FileFilter B() {
        return this.D;
    }
    
    public void B(final D d) {
        if (d != null) {
            this.C.add(d);
        }
    }
    
    public void A(final D d) {
        if (d != null) {
            while (this.C.remove(d)) {}
        }
    }
    
    public Iterable<D> D() {
        return this.C;
    }
    
    public void E() throws Exception {
        this.B.B(this.B.H());
        this.B.A(this.A(this.B.H(), this.B));
    }
    
    public void C() throws Exception {
    }
    
    public void A() {
        final Iterator<D> iterator = this.C.iterator();
        while (iterator.hasNext()) {
            iterator.next().A(this);
        }
        final File h = this.B.H();
        if (h.exists()) {
            this.A(this.B, this.B.E(), this.A(h));
        }
        else if (this.B.F()) {
            this.A(this.B, this.B.E(), S.G);
        }
        final Iterator<D> iterator2 = this.C.iterator();
        while (iterator2.hasNext()) {
            iterator2.next().B(this);
        }
    }
    
    private void A(final E e, final E[] array, final File[] array2) {
        int i = 0;
        final E[] array3 = (array2.length > 0) ? new E[array2.length] : org.B.A.A.B.E.J;
        for (final E e2 : array) {
            while (i < array2.length && this.A.compare(e2.H(), array2[i]) > 0) {
                this.A(array3[i] = this.A(e, array2[i]));
                ++i;
            }
            if (i < array2.length && this.A.compare(e2.H(), array2[i]) == 0) {
                this.B(e2, array2[i]);
                this.A(e2, e2.E(), this.A(array2[i]));
                array3[i] = e2;
                ++i;
            }
            else {
                this.A(e2, e2.E(), S.G);
                this.B(e2);
            }
        }
        while (i < array2.length) {
            this.A(array3[i] = this.A(e, array2[i]));
            ++i;
        }
        e.A(array3);
    }
    
    private E A(final E e, final File file) {
        final E a = e.A(file);
        a.B(file);
        a.A(this.A(file, a));
        return a;
    }
    
    private E[] A(final File file, final E e) {
        final File[] a = this.A(file);
        final E[] array = (a.length > 0) ? new E[a.length] : org.B.A.A.B.E.J;
        for (int i = 0; i < a.length; ++i) {
            array[i] = this.A(e, a[i]);
        }
        return array;
    }
    
    private void A(final E e) {
        for (final D d : this.C) {
            if (e.A()) {
                d.A(e.H());
            }
            else {
                d.D(e.H());
            }
        }
        final E[] e2 = e.E();
        for (int length = e2.length, i = 0; i < length; ++i) {
            this.A(e2[i]);
        }
    }
    
    private void B(final E e, final File file) {
        if (e.B(file)) {
            for (final D d : this.C) {
                if (e.A()) {
                    d.E(file);
                }
                else {
                    d.C(file);
                }
            }
        }
    }
    
    private void B(final E e) {
        for (final D d : this.C) {
            if (e.A()) {
                d.B(e.H());
            }
            else {
                d.F(e.H());
            }
        }
    }
    
    private File[] A(final File file) {
        File[] g = null;
        if (file.isDirectory()) {
            g = ((this.D == null) ? file.listFiles() : file.listFiles(this.D));
        }
        if (g == null) {
            g = S.G;
        }
        if (this.A != null && g.length > 1) {
            Arrays.sort(g, this.A);
        }
        return g;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(this.getClass().getSimpleName());
        sb.append("[file='");
        sb.append(this.F().getPath());
        sb.append('\'');
        if (this.D != null) {
            sb.append(", ");
            sb.append(this.D.toString());
        }
        sb.append(", listeners=");
        sb.append(this.C.size());
        sb.append("]");
        return sb.toString();
    }
}
