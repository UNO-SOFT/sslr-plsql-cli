// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.B;

import java.io.File;

public interface D
{
    void A(final C p0);
    
    void A(final File p0);
    
    void E(final File p0);
    
    void B(final File p0);
    
    void D(final File p0);
    
    void C(final File p0);
    
    void F(final File p0);
    
    void B(final C p0);
}
