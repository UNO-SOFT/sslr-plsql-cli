// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.B;

import java.io.File;

public class B implements D
{
    @Override
    public void A(final C c) {
    }
    
    @Override
    public void A(final File file) {
    }
    
    @Override
    public void E(final File file) {
    }
    
    @Override
    public void B(final File file) {
    }
    
    @Override
    public void D(final File file) {
    }
    
    @Override
    public void C(final File file) {
    }
    
    @Override
    public void F(final File file) {
    }
    
    @Override
    public void B(final C c) {
    }
}
