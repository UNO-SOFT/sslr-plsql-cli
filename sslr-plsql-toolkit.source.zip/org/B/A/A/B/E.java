// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.B;

import java.io.IOException;
import org.B.A.A.S;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.io.File;
import java.io.Serializable;

public class E implements Serializable
{
    private static final long C = -2505664948818681153L;
    static final E[] J;
    private final E I;
    private E[] D;
    private final File F;
    private String A;
    private boolean H;
    private boolean G;
    private long E;
    private long B;
    
    public E(final File file) {
        this(null, file);
    }
    
    public E(final E i, final File f) {
        if (f == null) {
            throw new IllegalArgumentException("File is missing");
        }
        this.F = f;
        this.I = i;
        this.A = f.getName();
    }
    
    public boolean B(final File file) {
        final boolean h = this.H;
        final long e = this.E;
        final boolean g = this.G;
        final long b = this.B;
        this.A = file.getName();
        this.H = Files.exists(file.toPath(), new LinkOption[0]);
        this.G = (this.H && file.isDirectory());
        try {
            this.E = (this.H ? S.K(file) : 0L);
        }
        catch (final IOException ex) {
            this.E = 0L;
        }
        this.B = ((this.H && !this.G) ? file.length() : 0L);
        return this.H != h || this.E != e || this.G != g || this.B != b;
    }
    
    public E A(final File file) {
        return new E(this, file);
    }
    
    public E B() {
        return this.I;
    }
    
    public int C() {
        return (this.I == null) ? 0 : (this.I.C() + 1);
    }
    
    public E[] E() {
        return (this.D != null) ? this.D : org.B.A.A.B.E.J;
    }
    
    public void A(final E... d) {
        this.D = d;
    }
    
    public File H() {
        return this.F;
    }
    
    public String G() {
        return this.A;
    }
    
    public void A(final String a) {
        this.A = a;
    }
    
    public long I() {
        return this.E;
    }
    
    public void A(final long e) {
        this.E = e;
    }
    
    public long D() {
        return this.B;
    }
    
    public void B(final long b) {
        this.B = b;
    }
    
    public boolean F() {
        return this.H;
    }
    
    public void A(final boolean h) {
        this.H = h;
    }
    
    public boolean A() {
        return this.G;
    }
    
    public void B(final boolean g) {
        this.G = g;
    }
    
    static {
        J = new E[0];
    }
}
