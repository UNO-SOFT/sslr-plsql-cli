// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.B;

import java.util.Iterator;
import java.util.Collections;
import java.util.Optional;
import java.util.Collection;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ThreadFactory;
import java.util.List;

public final class A implements Runnable
{
    private static final C[] B;
    private final long D;
    private final List<C> F;
    private Thread A;
    private ThreadFactory E;
    private volatile boolean C;
    
    public A() {
        this(10000L);
    }
    
    public A(final long d) {
        this.F = new CopyOnWriteArrayList<C>();
        this.D = d;
    }
    
    public A(final long n, final Collection<C> value) {
        this(n, (C[])Optional.ofNullable(value).orElse(Collections.emptyList()).toArray(org.B.A.A.B.A.B));
    }
    
    public A(final long n, final C... array) {
        this(n);
        if (array != null) {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.B(array[i]);
            }
        }
    }
    
    public long B() {
        return this.D;
    }
    
    public synchronized void A(final ThreadFactory e) {
        this.E = e;
    }
    
    public void B(final C c) {
        if (c != null) {
            this.F.add(c);
        }
    }
    
    public void A(final C c) {
        if (c != null) {
            while (this.F.remove(c)) {}
        }
    }
    
    public Iterable<C> A() {
        return this.F;
    }
    
    public synchronized void C() throws Exception {
        if (this.C) {
            throw new IllegalStateException("Monitor is already running");
        }
        final Iterator<C> iterator = this.F.iterator();
        while (iterator.hasNext()) {
            iterator.next().E();
        }
        this.C = true;
        if (this.E != null) {
            this.A = this.E.newThread(this);
        }
        else {
            this.A = new Thread(this);
        }
        this.A.start();
    }
    
    public synchronized void D() throws Exception {
        this.A(this.D);
    }
    
    public synchronized void A(final long millis) throws Exception {
        if (!this.C) {
            throw new IllegalStateException("Monitor is not running");
        }
        this.C = false;
        try {
            this.A.interrupt();
            this.A.join(millis);
        }
        catch (final InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
        final Iterator<C> iterator = this.F.iterator();
        while (iterator.hasNext()) {
            iterator.next().C();
        }
    }
    
    @Override
    public void run() {
        while (this.C) {
            final Iterator<C> iterator = this.F.iterator();
            while (iterator.hasNext()) {
                iterator.next().A();
            }
            if (!this.C) {
                break;
            }
            try {
                Thread.sleep(this.D);
            }
            catch (final InterruptedException ex) {}
        }
    }
    
    static {
        B = new C[0];
    }
}
