// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.A;

import java.util.regex.Pattern;

final class C implements A
{
    private final Pattern B;
    
    public C(final String regex) {
        this(Pattern.compile(regex));
    }
    
    public C(final Pattern b) {
        if (b == null) {
            throw new IllegalArgumentException("Null pattern");
        }
        this.B = b;
    }
    
    @Override
    public boolean A(final String input) {
        return this.B.matcher(input).matches();
    }
}
