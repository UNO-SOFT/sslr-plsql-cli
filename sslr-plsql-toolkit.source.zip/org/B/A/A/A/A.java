// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.A;

public interface A
{
    boolean A(final String p0);
}
