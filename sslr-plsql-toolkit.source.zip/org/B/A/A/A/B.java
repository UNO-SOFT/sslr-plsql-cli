// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.A;

import org.B.A.A.M;

final class B implements A
{
    private final String A;
    
    public B(final String a) {
        this.A = a;
    }
    
    @Override
    public boolean A(final String s) {
        return M.C(s, this.A);
    }
}
