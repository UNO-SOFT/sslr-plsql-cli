// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.A;

import java.util.regex.Pattern;
import java.io.ObjectStreamClass;
import java.io.InvalidClassException;
import java.util.Iterator;
import java.io.IOException;
import java.util.ArrayList;
import java.io.InputStream;
import java.util.List;
import java.io.ObjectInputStream;

public class D extends ObjectInputStream
{
    private final List<A> A;
    private final List<A> B;
    
    public D(final InputStream in) throws IOException {
        super(in);
        this.A = new ArrayList<A>();
        this.B = new ArrayList<A>();
    }
    
    private void B(final String s) throws InvalidClassException {
        final Iterator<A> iterator = this.B.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().A(s)) {
                this.A(s);
            }
        }
        boolean b = false;
        final Iterator<A> iterator2 = this.A.iterator();
        while (iterator2.hasNext()) {
            if (iterator2.next().A(s)) {
                b = true;
                break;
            }
        }
        if (!b) {
            this.A(s);
        }
    }
    
    protected void A(final String str) throws InvalidClassException {
        throw new InvalidClassException("Class name not accepted: " + str);
    }
    
    @Override
    protected Class<?> resolveClass(final ObjectStreamClass desc) throws IOException, ClassNotFoundException {
        this.B(desc.getName());
        return super.resolveClass(desc);
    }
    
    public D B(final Class<?>... array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            this.A.add(new E(new String[] { array[i].getName() }));
        }
        return this;
    }
    
    public D A(final Class<?>... array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            this.B.add(new E(new String[] { array[i].getName() }));
        }
        return this;
    }
    
    public D B(final String... array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            this.A.add(new B(array[i]));
        }
        return this;
    }
    
    public D A(final String... array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            this.B.add(new B(array[i]));
        }
        return this;
    }
    
    public D B(final Pattern pattern) {
        this.A.add(new C(pattern));
        return this;
    }
    
    public D A(final Pattern pattern) {
        this.B.add(new C(pattern));
        return this;
    }
    
    public D A(final A a) {
        this.A.add(a);
        return this;
    }
    
    public D B(final A a) {
        this.B.add(a);
        return this;
    }
}
