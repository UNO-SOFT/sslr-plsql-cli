// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.D;

import java.util.List;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class A extends F implements Serializable
{
    private static final int s = 2;
    private static final int r = 1;
    private static final long t = 296132640160964395L;
    public static final Comparator<File> p;
    public static final Comparator<File> q;
    
    public int I(final File file, final File file2) {
        return this.A(file) - this.A(file2);
    }
    
    private int A(final File file) {
        return file.isDirectory() ? 1 : 2;
    }
    
    static {
        p = new A();
        q = new C(A.p);
    }
}
