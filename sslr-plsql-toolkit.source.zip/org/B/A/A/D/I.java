// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.D;

import java.util.List;
import org.B.A.A.D;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class I extends F implements Serializable
{
    private static final long l = 6527501707585768673L;
    public static final Comparator<File> i;
    public static final Comparator<File> f;
    public static final Comparator<File> k;
    public static final Comparator<File> h;
    public static final Comparator<File> j;
    public static final Comparator<File> g;
    private final D e;
    
    public I() {
        this.e = D.F;
    }
    
    public I(final D d) {
        this.e = ((d == null) ? D.F : d);
    }
    
    public int G(final File file, final File file2) {
        return this.e.A(file.getPath(), file2.getPath());
    }
    
    @Override
    public String toString() {
        return super.toString() + "[caseSensitivity=" + this.e + "]";
    }
    
    static {
        i = new I();
        f = new C(I.i);
        k = new I(D.E);
        h = new C(I.k);
        j = new I(D.D);
        g = new C(I.j);
    }
}
