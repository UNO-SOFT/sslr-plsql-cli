// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.D;

import java.util.List;
import org.B.A.A.S;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class D extends F implements Serializable
{
    private static final long P = -1201561106411416190L;
    public static final Comparator<File> O;
    public static final Comparator<File> L;
    public static final Comparator<File> N;
    public static final Comparator<File> K;
    private final boolean M;
    
    public D() {
        this.M = false;
    }
    
    public D(final boolean m) {
        this.M = m;
    }
    
    public int C(final File file, final File file2) {
        long length;
        if (file.isDirectory()) {
            length = ((this.M && file.exists()) ? S.L(file) : 0L);
        }
        else {
            length = file.length();
        }
        long length2;
        if (file2.isDirectory()) {
            length2 = ((this.M && file2.exists()) ? S.L(file2) : 0L);
        }
        else {
            length2 = file2.length();
        }
        final long n = length - length2;
        if (n < 0L) {
            return -1;
        }
        if (n > 0L) {
            return 1;
        }
        return 0;
    }
    
    @Override
    public String toString() {
        return super.toString() + "[sumDirectoryContents=" + this.M + "]";
    }
    
    static {
        O = new D();
        L = new C(D.O);
        N = new D(true);
        K = new C(D.N);
    }
}
