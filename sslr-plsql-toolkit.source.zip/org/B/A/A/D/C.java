// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.D;

import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

class C extends F implements Serializable
{
    private static final long J = -4808255005272229056L;
    private final Comparator<File> I;
    
    public C(final Comparator<File> i) {
        if (i == null) {
            throw new IllegalArgumentException("Delegate comparator is missing");
        }
        this.I = i;
    }
    
    public int B(final File file, final File file2) {
        return this.I.compare(file2, file);
    }
    
    @Override
    public String toString() {
        return super.toString() + "[" + this.I.toString() + "]";
    }
}
