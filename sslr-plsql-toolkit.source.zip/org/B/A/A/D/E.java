// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.D;

import java.util.List;
import org.B.A.A.D;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class E extends F implements Serializable
{
    private static final long X = 8397947749814525798L;
    public static final Comparator<File> W;
    public static final Comparator<File> Q;
    public static final Comparator<File> S;
    public static final Comparator<File> T;
    public static final Comparator<File> V;
    public static final Comparator<File> U;
    private final D R;
    
    public E() {
        this.R = D.F;
    }
    
    public E(final D d) {
        this.R = ((d == null) ? D.F : d);
    }
    
    public int D(final File file, final File file2) {
        return this.R.A(file.getName(), file2.getName());
    }
    
    @Override
    public String toString() {
        return super.toString() + "[caseSensitivity=" + this.R + "]";
    }
    
    static {
        W = new E();
        Q = new C(E.W);
        S = new E(D.E);
        T = new C(E.S);
        V = new E(D.D);
        U = new C(E.V);
    }
}
