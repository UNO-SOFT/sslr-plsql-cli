// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.D;

import java.util.List;
import java.util.Arrays;
import java.io.File;
import java.util.Comparator;

abstract class F implements Comparator<File>
{
    public File[] A(final File... a) {
        if (a != null) {
            Arrays.sort(a, this);
        }
        return a;
    }
    
    public List<File> A(final List<File> list) {
        if (list != null) {
            list.sort(this);
        }
        return list;
    }
    
    @Override
    public String toString() {
        return this.getClass().getSimpleName();
    }
}
