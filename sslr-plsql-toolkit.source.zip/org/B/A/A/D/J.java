// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.D;

import java.util.List;
import org.B.A.A.S;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class J extends F implements Serializable
{
    private static final long o = 7372168004395734046L;
    public static final Comparator<File> m;
    public static final Comparator<File> n;
    
    public int H(final File file, final File file2) {
        final long n = S.B(file) - S.B(file2);
        if (n < 0L) {
            return -1;
        }
        if (n > 0L) {
            return 1;
        }
        return 0;
    }
    
    static {
        m = new J();
        n = new C(J.m);
    }
}
