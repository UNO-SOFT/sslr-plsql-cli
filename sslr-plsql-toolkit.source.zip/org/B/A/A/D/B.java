// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.D;

import java.util.List;
import org.B.A.A.M;
import org.B.A.A.D;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class B extends F implements Serializable
{
    private static final long H = 1928235200184222815L;
    public static final Comparator<File> E;
    public static final Comparator<File> D;
    public static final Comparator<File> C;
    public static final Comparator<File> F;
    public static final Comparator<File> B;
    public static final Comparator<File> G;
    private final D A;
    
    public B() {
        this.A = org.B.A.A.D.F;
    }
    
    public B(final D d) {
        this.A = ((d == null) ? org.B.A.A.D.F : d);
    }
    
    public int A(final File file, final File file2) {
        return this.A.A(M.C(file.getName()), M.C(file2.getName()));
    }
    
    @Override
    public String toString() {
        return super.toString() + "[caseSensitivity=" + this.A + "]";
    }
    
    static {
        E = new B();
        D = new C(org.B.A.A.D.B.E);
        C = new B(org.B.A.A.D.E);
        F = new C(org.B.A.A.D.B.C);
        B = new B(org.B.A.A.D.D);
        G = new C(org.B.A.A.D.B.B);
    }
}
