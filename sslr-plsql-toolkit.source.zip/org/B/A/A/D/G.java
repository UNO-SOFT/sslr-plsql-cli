// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.D;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class G extends F implements Serializable
{
    private static final Comparator<?>[] Z;
    private static final long a = -2224170307287243428L;
    private static final Comparator<?>[] _;
    private final Comparator<File>[] Y;
    
    public G(final Comparator<File>... array) {
        if (array == null) {
            this.Y = (Comparator[])G._;
        }
        else {
            System.arraycopy(array, 0, this.Y = new Comparator[array.length], 0, array.length);
        }
    }
    
    public G(final Iterable<Comparator<File>> iterable) {
        if (iterable == null) {
            this.Y = (Comparator[])G._;
        }
        else {
            final ArrayList list = new ArrayList();
            final Iterator<Comparator<File>> iterator = iterable.iterator();
            while (iterator.hasNext()) {
                list.add(iterator.next());
            }
            this.Y = (Comparator[])list.toArray(G.Z);
        }
    }
    
    public int E(final File file, final File file2) {
        int compare = 0;
        final Comparator<File>[] y = this.Y;
        for (int length = y.length, i = 0; i < length; ++i) {
            compare = y[i].compare(file, file2);
            if (compare != 0) {
                break;
            }
        }
        return compare;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append('{');
        for (int i = 0; i < this.Y.length; ++i) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(this.Y[i]);
        }
        sb.append('}');
        return sb.toString();
    }
    
    static {
        Z = new Comparator[0];
        _ = new Comparator[0];
    }
}
