// 
// Decompiled by Procyon v0.6.0
// 

package org.B.A.A.D;

import java.util.List;
import java.io.File;
import java.util.Comparator;
import java.io.Serializable;

public class H extends F implements Serializable
{
    private static final long d = 3260141861365313518L;
    public static final Comparator<File> b;
    public static final Comparator<File> c;
    
    public int F(final File file, final File pathname) {
        return file.compareTo(pathname);
    }
    
    static {
        b = new H();
        c = new C(H.b);
    }
}
