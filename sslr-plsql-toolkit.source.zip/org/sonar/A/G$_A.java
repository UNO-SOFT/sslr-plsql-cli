// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.A;

import java.util.ArrayList;
import java.util.List;

public static final class _A
{
    private List<D> A;
    private boolean B;
    
    private _A() {
        this.A = new ArrayList<D>();
        this.B = false;
    }
    
    public _A A(final D d) {
        this.A.add(d);
        return this;
    }
    
    public _A A(final D... array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            this.A(array[i]);
        }
        return this;
    }
    
    public _A B() {
        this.B = true;
        return this;
    }
    
    public <O> G<O> A() {
        return new G<O>(this, null);
    }
}
