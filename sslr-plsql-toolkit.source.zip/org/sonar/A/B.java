// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.A;

public interface B
{
    boolean A(final int p0);
}
