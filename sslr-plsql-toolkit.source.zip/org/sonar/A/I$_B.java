// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.A;

public final class _B implements Cloneable
{
    private int B;
    private int C;
    
    public _B() {
        this.B = 1;
        this.C = 0;
    }
    
    public int C() {
        return this.B;
    }
    
    public int B() {
        return this.C;
    }
    
    public _B A() {
        final _B b = new _B();
        b.C = this.C;
        b.B = this.B;
        return b;
    }
}
