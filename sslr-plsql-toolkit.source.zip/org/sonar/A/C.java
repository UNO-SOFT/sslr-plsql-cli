// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.A;

public class C extends RuntimeException
{
    public C(final String message, final Exception cause) {
        super(message, cause);
    }
    
    public C(final String message) {
        super(message);
    }
    
    public C(final String message, final Throwable cause) {
        super(message, cause);
    }
}
