// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.A;

public abstract class D<O>
{
    public abstract boolean A(final A p0, final O p1);
}
