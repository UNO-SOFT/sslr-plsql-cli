// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.A;

import java.io.IOException;
import java.io.Reader;

public final class J<O> extends E<O>
{
    private D<O>[] E;
    private A D;
    
    public J(final D<O>... e) {
        this.E = new D[0];
        this.E = e;
    }
    
    public J(final O o, final D<O>... e) {
        super(o);
        this.E = new D[0];
        this.E = e;
    }
    
    @Override
    public void A(final Reader reader) {
        super.A(reader);
        this.D = new A(reader, this.A());
    }
    
    @Override
    public int A(final char[] array, int n, final int n2) throws IOException {
        if (this.D.D() == -1) {
            return -1;
        }
        final int n3 = n;
        while (n < array.length && this.D.D() != -1) {
            boolean b = false;
            final D<O>[] e = this.E;
            for (int length = e.length, i = 0; i < length; ++i) {
                if (e[i].A(this.D, this.B())) {
                    b = true;
                    break;
                }
            }
            if (!b) {
                array[n++] = (char)this.D.F();
            }
        }
        return n - n3;
    }
}
