// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.A;

import java.io.IOException;
import java.io.Reader;

public abstract class E<O>
{
    private Reader A;
    private O B;
    private F C;
    
    public E() {
    }
    
    public E(final O b) {
        this.B = b;
    }
    
    public Reader C() {
        return this.A;
    }
    
    public void A(final Reader a) {
        this.A = a;
    }
    
    public O B() {
        return this.B;
    }
    
    public void A(final O b) {
        this.B = b;
    }
    
    public F A() {
        return this.C;
    }
    
    public void A(final F c) {
        this.C = c;
    }
    
    public abstract int A(final char[] p0, final int p1, final int p2) throws IOException;
}
