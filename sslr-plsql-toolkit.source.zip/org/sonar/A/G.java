// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.A;

import java.util.ArrayList;
import org.slf4j.LoggerFactory;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;

public class G<O> extends D<O>
{
    private static final Logger B;
    private final boolean C;
    private final D<O>[] A;
    
    @Deprecated
    public G(final List<D> list) {
        this(list, false);
    }
    
    @Deprecated
    public G(final D... a) {
        this((List)Arrays.asList((D[])a), false);
    }
    
    @Deprecated
    public G(final List<D> list, final boolean c) {
        this.A = list.toArray(new D[list.size()]);
        this.C = c;
    }
    
    private G(final _A a) {
        this.A = a.A.toArray(new D[a.A.size()]);
        this.C = a.B;
    }
    
    @Override
    public boolean A(final A a, final O o) {
        for (int i = a.D(); i != -1; i = a.D()) {
            boolean b = false;
            final D<O>[] a2 = this.A;
            for (int length = a2.length, j = 0; j < length; ++j) {
                if (a2[j].A(a, o)) {
                    b = true;
                    break;
                }
            }
            if (!b) {
                if (G.B.isDebugEnabled() || this.C) {
                    final String string = "None of the channel has been able to handle character '" + (char)a.D() + "' (decimal value " + a.D() + ") at line " + a.G() + ", column " + a.E();
                    if (this.C) {
                        throw new IllegalStateException(string);
                    }
                    G.B.debug(string);
                }
                a.F();
            }
        }
        return true;
    }
    
    D[] A() {
        return this.A;
    }
    
    public static _A B() {
        return new _A();
    }
    
    static {
        B = LoggerFactory.getLogger((Class)G.class);
    }
    
    public static final class _A
    {
        private List<D> A;
        private boolean B;
        
        private _A() {
            this.A = new ArrayList<D>();
            this.B = false;
        }
        
        public _A A(final D d) {
            this.A.add(d);
            return this;
        }
        
        public _A A(final D... array) {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.A(array[i]);
            }
            return this;
        }
        
        public _A B() {
            this.B = true;
            return this;
        }
        
        public <O> G<O> A() {
            return new G<O>(this, null);
        }
    }
}
