// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.A;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public abstract class H<O> extends D<O>
{
    private final StringBuilder E;
    private final Matcher D;
    
    public H(final String regex) {
        this.E = new StringBuilder();
        this.D = Pattern.compile(regex).matcher("");
    }
    
    @Override
    public final boolean A(final A a, final O o) {
        if (a.A(this.D, this.E) > 0) {
            this.A(this.E, o);
            this.E.delete(0, this.E.length());
            return true;
        }
        return false;
    }
    
    protected abstract void A(final CharSequence p0, final O p1);
}
