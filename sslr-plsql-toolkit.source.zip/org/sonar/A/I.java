// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.A;

import java.io.FilterReader;
import java.io.IOException;
import org.B.A.A.W;
import java.io.Reader;
import java.io.StringReader;

public class I implements CharSequence
{
    private int H;
    private _B G;
    private char[] B;
    private int I;
    private static final char C = '\n';
    private static final char A = '\r';
    private int E;
    private boolean D;
    private StringBuilder F;
    
    protected I(final String s, final F f) {
        this(new StringReader(s), f);
    }
    
    protected I(final Reader reader, final F f) {
        this.H = -1;
        this.I = 0;
        this.D = false;
        this.F = new StringBuilder();
        Reader reader2 = null;
        try {
            this.H = -1;
            this.G = new _B();
            this.E = f.B();
            reader2 = reader;
            final E[] d = f.D();
            for (int length = d.length, i = 0; i < length; ++i) {
                reader2 = new _A(reader2, d[i], f);
            }
            this.B = W.F(reader2);
        }
        catch (final IOException ex) {
            throw new C(ex.getMessage(), ex);
        }
        finally {
            W.E(reader2);
        }
    }
    
    public final int F() {
        if (this.I >= this.B.length) {
            return -1;
        }
        final char h = this.B[this.I++];
        this.D(h);
        if (this.D) {
            this.F.append(h);
        }
        return this.H = h;
    }
    
    private void D(final int n) {
        if (n == 10 || (n == 13 && this.D() != 10)) {
            this.G.B++;
            this.G.C = 0;
        }
        else if (n == 9) {
            this.G.C += this.E;
        }
        else {
            this.G.C++;
        }
    }
    
    public final int I() {
        return this.H;
    }
    
    public final int D() {
        return this.C(0);
    }
    
    @Deprecated
    public final void C() {
    }
    
    public final int G() {
        return this.G.B;
    }
    
    public final _B B() {
        return this.G;
    }
    
    public final int E() {
        return this.G.C;
    }
    
    public final I A(final int n) {
        this.G.C = n;
        return this;
    }
    
    public final void B(final int n) {
        this.G.B = n;
    }
    
    public final void A() {
        this.D = true;
    }
    
    public final CharSequence H() {
        this.D = false;
        final StringBuilder f = this.F;
        this.F = new StringBuilder();
        return f;
    }
    
    @Override
    public final char charAt(final int n) {
        return (char)this.C(n);
    }
    
    protected final int C(final int n) {
        if (this.I + n >= this.B.length) {
            return -1;
        }
        return this.B[this.I + n];
    }
    
    @Override
    public final int length() {
        return this.B.length - this.I;
    }
    
    @Override
    public final CharSequence subSequence(final int n, final int n2) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("CodeReader(");
        sb.append("line:").append(this.G.B);
        sb.append("|column:").append(this.G.C);
        sb.append("|cursor value:'").append((char)this.D()).append("'");
        sb.append(")");
        return sb.toString();
    }
    
    static final class _A extends FilterReader
    {
        private E<?> A;
        
        public _A(final Reader in, final E<?> a, final F f) {
            super(in);
            (this.A = a).A(f.A());
            this.A.A(in);
        }
        
        @Override
        public int read() throws IOException {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public int read(final char[] array, final int n, final int n2) throws IOException {
            final int a = this.A.A(array, n, n2);
            return (a == 0) ? -1 : a;
        }
        
        @Override
        public long skip(final long n) throws IOException {
            throw new UnsupportedOperationException();
        }
    }
    
    public final class _B implements Cloneable
    {
        private int B;
        private int C;
        
        public _B() {
            this.B = 1;
            this.C = 0;
        }
        
        public int C() {
            return this.B;
        }
        
        public int B() {
            return this.C;
        }
        
        public _B A() {
            final _B b = new _B();
            b.C = this.C;
            b.B = this.B;
            return b;
        }
    }
}
