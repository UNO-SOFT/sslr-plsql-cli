// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.A;

import java.util.Collection;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

public class F
{
    @Deprecated
    public static final int D = 8000;
    public static final int C = 1;
    private int A;
    private List<E<?>> B;
    
    public F() {
        this.A = 1;
        this.B = new ArrayList<E<?>>();
    }
    
    @Deprecated
    public int C() {
        return Integer.MAX_VALUE;
    }
    
    @Deprecated
    public void B(final int n) {
    }
    
    public int B() {
        return this.A;
    }
    
    public void A(final int a) {
        this.A = a;
    }
    
    public E[] D() {
        return this.B.toArray(new E[this.B.size()]);
    }
    
    public void A(final E<?>... a) {
        this.B = new ArrayList<E<?>>(Arrays.asList(a));
    }
    
    public void A(final E<?> e) {
        this.B.add(e);
    }
    
    public F A() {
        final F f = new F();
        f.A(this.A);
        return f;
    }
}
