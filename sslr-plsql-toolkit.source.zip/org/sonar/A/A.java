// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.A;

import java.util.regex.Matcher;
import java.io.IOException;
import java.io.Reader;

public class A extends I
{
    private _B J;
    
    public A(final Reader reader) {
        super(reader, new F());
    }
    
    public A(final String s) {
        super(s, new F());
    }
    
    public A(final Reader reader, final F f) {
        super(reader, f);
    }
    
    public A(final String s, final F f) {
        super(s, f);
    }
    
    public final void A(final Appendable appendable) {
        try {
            appendable.append((char)this.F());
        }
        catch (final IOException ex) {
            throw new C(ex.getMessage(), ex);
        }
    }
    
    public final char[] E(final int n) {
        final char[] array = new char[n];
        for (int n2 = 0, n3 = this.C(n2); n3 != -1 && n2 < n; n3 = this.C(++n2)) {
            array[n2] = (char)n3;
        }
        return array;
    }
    
    public final void A(final B b, final Appendable appendable) {
        int n = 0;
        char c = this.charAt(n);
        try {
            while (!b.A(c) && c != -1) {
                appendable.append(c);
                c = this.charAt(++n);
            }
        }
        catch (final IOException ex) {
            throw new C(ex.getMessage(), ex);
        }
    }
    
    @Deprecated
    public final String A(final B b) {
        final StringBuilder sb = new StringBuilder();
        this.A(b, sb);
        return sb.toString();
    }
    
    @Deprecated
    public final void B(final B b, final Appendable appendable) {
        this.J = this.B().A();
        try {
            do {
                appendable.append((char)this.F());
            } while (!b.A(this.D()) && this.D() != -1);
        }
        catch (final IOException ex) {
            throw new C(ex.getMessage(), ex);
        }
    }
    
    public final int A(final Matcher matcher, final Appendable appendable) {
        return this.A(matcher, null, appendable);
    }
    
    public final int A(final Matcher matcher, final Matcher matcher2, final Appendable appendable) {
        try {
            matcher.reset(this);
            if (matcher.lookingAt()) {
                if (matcher2 != null) {
                    matcher2.reset(this);
                    matcher2.region(matcher.end(), this.length());
                    if (!matcher2.lookingAt()) {
                        return -1;
                    }
                }
                this.J = this.B().A();
                for (int i = 0; i < matcher.end(); ++i) {
                    appendable.append((char)this.F());
                }
                return matcher.end();
            }
        }
        catch (final StackOverflowError stackOverflowError) {
            throw new C("Unable to apply regular expression '" + matcher.pattern().pattern() + "' at line " + this.B().C() + " and column " + this.B().B() + ", because it led to a stack overflow error." + " This error may be due to an inefficient use of alternations - see http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=5050507", stackOverflowError);
        }
        catch (final IndexOutOfBoundsException ex) {
            return -1;
        }
        catch (final IOException ex2) {
            throw new C(ex2.getMessage(), ex2);
        }
        return -1;
    }
    
    public final _B J() {
        return this.J;
    }
}
