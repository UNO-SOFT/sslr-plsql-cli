// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.A;

import java.io.IOException;
import java.io.Reader;
import java.io.FilterReader;

static final class _A extends FilterReader
{
    private E<?> A;
    
    public _A(final Reader in, final E<?> a, final F f) {
        super(in);
        (this.A = a).A(f.A());
        this.A.A(in);
    }
    
    @Override
    public int read() throws IOException {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public int read(final char[] array, final int n, final int n2) throws IOException {
        final int a = this.A.A(array, n, n2);
        return (a == 0) ? -1 : a;
    }
    
    @Override
    public long skip(final long n) throws IOException {
        throw new UnsupportedOperationException();
    }
}
