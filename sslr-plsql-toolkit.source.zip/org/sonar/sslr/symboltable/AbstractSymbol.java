// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.symboltable;

public abstract class AbstractSymbol implements Symbol
{
    private final Scope D;
    private final String E;
    
    protected AbstractSymbol(final Scope d, final String e) {
        this.D = d;
        this.E = e;
    }
    
    @Override
    public Scope getEnclosingScope() {
        return this.D;
    }
    
    @Override
    public String getKey() {
        return this.E;
    }
}
