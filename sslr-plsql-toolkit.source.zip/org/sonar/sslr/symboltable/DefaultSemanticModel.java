// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.symboltable;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.Collection;
import com.A.B.J.a;
import java.util.IdentityHashMap;
import com.A.B.J.FC;
import com.sonar.sslr.api.AstNode;
import java.util.Map;

public class DefaultSemanticModel implements SemanticModel
{
    private final Map<AstNode, Scope> D;
    private final Map<AstNode, Symbol> A;
    private final Map<AstNode, Symbol> C;
    private final FC<Symbol, AstNode> B;
    
    public DefaultSemanticModel() {
        this.D = new IdentityHashMap<AstNode, Scope>();
        this.A = new IdentityHashMap<AstNode, Symbol>();
        this.C = new IdentityHashMap<AstNode, Symbol>();
        this.B = (FC<Symbol, AstNode>)a.\u00ec();
    }
    
    @Override
    public Symbol getDeclaredSymbol(AstNode parent) {
        Symbol symbol;
        for (symbol = null; symbol == null && parent != null; symbol = this.C.get(parent), parent = parent.getParent()) {}
        return symbol;
    }
    
    @Override
    public void declareSymbol(final AstNode astNode, final Symbol symbol) {
        this.getEnclosingScope(astNode).addSymbol(symbol);
        this.A.put(astNode, symbol);
        this.C.put(astNode, symbol);
    }
    
    @Override
    public void declareScope(final AstNode astNode, final Scope scope) {
        final Scope enclosingScope = scope.getEnclosingScope();
        if (enclosingScope != null) {
            enclosingScope.addNestedScope(scope);
        }
        this.D.put(astNode, scope);
    }
    
    @Override
    public void declareReference(final AstNode astNode, final Symbol symbol) {
        this.B.D(symbol, astNode);
        this.C.put(astNode, symbol);
    }
    
    @Override
    public Scope getEnclosingScope(AstNode parent) {
        Scope scope;
        for (scope = null; scope == null && parent != null; scope = this.D.get(parent), parent = parent.getParent()) {}
        return scope;
    }
    
    @Override
    public Collection<AstNode> getReferences(final Symbol symbol) {
        return this.B.X(symbol);
    }
    
    @Override
    public <T extends Symbol> Collection<T> getSymbols(final Class<T> clazz) {
        final ArrayList list = new ArrayList();
        for (final Symbol symbol : this.A.values()) {
            if (clazz.isInstance(symbol)) {
                list.add(symbol);
            }
        }
        return list;
    }
    
    @Override
    public <T extends Scope> Collection<T> getScopes(final Class<T> clazz) {
        final ArrayList list = new ArrayList();
        for (final Scope scope : this.D.values()) {
            if (clazz.isInstance(scope)) {
                list.add(scope);
            }
        }
        return list;
    }
}
