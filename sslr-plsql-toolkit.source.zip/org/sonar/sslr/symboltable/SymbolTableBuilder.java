// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.symboltable;

import com.sonar.sslr.api.AstNodeType;
import java.util.Iterator;
import com.A.B.J.J;
import com.sonar.sslr.api.AstVisitor;
import com.sonar.sslr.impl.ast.AstWalker;
import com.sonar.sslr.api.AstNode;
import java.util.ArrayList;
import java.util.List;

public class SymbolTableBuilder
{
    private final List<SymbolTableBuilderVisitor> B;
    private final List<SymbolTableBuilderVisitor> A;
    
    public SymbolTableBuilder() {
        this.B = new ArrayList<SymbolTableBuilderVisitor>();
        this.A = new ArrayList<SymbolTableBuilderVisitor>();
    }
    
    public SymbolTableBuilder addToFirstPhase(final SymbolTableBuilderVisitor symbolTableBuilderVisitor) {
        this.B.add(symbolTableBuilderVisitor);
        return this;
    }
    
    public SymbolTableBuilder addToSecondPhase(final SymbolTableBuilderVisitor symbolTableBuilderVisitor) {
        this.A.add(symbolTableBuilderVisitor);
        return this;
    }
    
    public SemanticModel buildSymbolTable(final AstNode astNode) {
        final DefaultSemanticModel defaultSemanticModel = new DefaultSemanticModel();
        new AstWalker(A(defaultSemanticModel, this.B)).walkAndVisit(astNode);
        new AstWalker(A(defaultSemanticModel, this.A)).walkAndVisit(astNode);
        return defaultSemanticModel;
    }
    
    private static List<AstVisitor> A(final SemanticModel semanticModel, final List<SymbolTableBuilderVisitor> list) {
        final J._D<Object> \u0137 = J.\u0136();
        final Iterator<SymbolTableBuilderVisitor> iterator = list.iterator();
        while (iterator.hasNext()) {
            \u0137.F(new _A(semanticModel, iterator.next()));
        }
        return (List<AstVisitor>)\u0137.K();
    }
    
    private static class _A implements AstVisitor
    {
        private final SymbolTableBuilderVisitor B;
        private final SemanticModel A;
        
        public _A(final SemanticModel a, final SymbolTableBuilderVisitor b) {
            this.A = a;
            this.B = b;
        }
        
        @Override
        public List<AstNodeType> getAstNodeTypesToVisit() {
            return this.B.getNodeTypes();
        }
        
        @Override
        public void visitFile(final AstNode astNode) {
        }
        
        @Override
        public void leaveFile(final AstNode astNode) {
        }
        
        @Override
        public void visitNode(final AstNode astNode) {
            this.B.visitNode(this.A, astNode);
        }
        
        @Override
        public void leaveNode(final AstNode astNode) {
        }
    }
}
