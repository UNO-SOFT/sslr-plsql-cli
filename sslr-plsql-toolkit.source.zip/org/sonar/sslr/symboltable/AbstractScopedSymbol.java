// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.symboltable;

public abstract class AbstractScopedSymbol extends AbstractScope implements Symbol
{
    private final String J;
    
    protected AbstractScopedSymbol(final Scope scope, final String j) {
        super(scope);
        this.J = j;
    }
    
    @Override
    public String getKey() {
        return this.J;
    }
}
