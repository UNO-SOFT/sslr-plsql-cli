// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.symboltable;

import javax.annotation.CheckForNull;
import java.util.List;

public interface Scope
{
    Scope getEnclosingScope();
    
    void addNestedScope(final Scope p0);
    
    List<Scope> getNestedScopes();
    
    void addSymbol(final Symbol p0);
    
    List<Symbol> getSymbols();
    
     <T extends Symbol> List<T> getSymbols(final Class<T> p0);
    
     <T extends Symbol> T getSymbol(final Class<T> p0, final String p1);
    
    @CheckForNull
     <T extends Symbol> T resolveSymbol(final Class<T> p0, final String p1);
}
