// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.symboltable;

import java.util.Collection;
import com.sonar.sslr.api.AstNode;

public interface SemanticModel
{
    Symbol getDeclaredSymbol(final AstNode p0);
    
    void declareSymbol(final AstNode p0, final Symbol p1);
    
    Scope getEnclosingScope(final AstNode p0);
    
    void declareScope(final AstNode p0, final Scope p1);
    
    Collection<AstNode> getReferences(final Symbol p0);
    
    void declareReference(final AstNode p0, final Symbol p1);
    
     <T extends Symbol> Collection<T> getSymbols(final Class<T> p0);
    
     <T extends Scope> Collection<T> getScopes(final Class<T> p0);
}
