// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.symboltable;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractScope implements Scope
{
    private final Scope B;
    private final List<Symbol> A;
    private final List<Scope> C;
    
    protected AbstractScope(final Scope b) {
        this.A = new ArrayList<Symbol>();
        this.C = new ArrayList<Scope>();
        this.B = b;
    }
    
    @Override
    public Scope getEnclosingScope() {
        return this.B;
    }
    
    @Override
    public List<Scope> getNestedScopes() {
        return this.C;
    }
    
    @Override
    public void addNestedScope(final Scope scope) {
        this.C.add(scope);
    }
    
    @Override
    public void addSymbol(final Symbol symbol) {
        this.A.add(symbol);
    }
    
    @Override
    public List<Symbol> getSymbols() {
        return this.A;
    }
    
    @Override
    public <T extends Symbol> List<T> getSymbols(final Class<T> clazz) {
        final ArrayList list = new ArrayList();
        for (final Symbol symbol : this.getSymbols()) {
            if (clazz.isInstance(symbol)) {
                list.add(symbol);
            }
        }
        return list;
    }
    
    @Override
    public <T extends Symbol> T getSymbol(final Class<T> clazz, final String s) {
        for (final Symbol symbol : this.getSymbols()) {
            if (clazz.isInstance(symbol) && s.equals(symbol.getKey())) {
                return (T)symbol;
            }
        }
        return null;
    }
    
    @Override
    public <T extends Symbol> T resolveSymbol(final Class<T> clazz, final String s) {
        Symbol symbol = null;
        for (Scope enclosingScope = this; enclosingScope != null; enclosingScope = enclosingScope.getEnclosingScope()) {
            symbol = enclosingScope.getSymbol(clazz, s);
            if (symbol != null) {
                break;
            }
        }
        return (T)symbol;
    }
}
