// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.symboltable;

public interface Symbol
{
    Scope getEnclosingScope();
    
    String getKey();
}
