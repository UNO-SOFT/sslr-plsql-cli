// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.symboltable;

import com.sonar.sslr.api.AstNode;
import java.util.Collections;
import java.util.Arrays;
import com.sonar.sslr.api.AstNodeType;
import java.util.List;

public abstract class SymbolTableBuilderVisitor
{
    private final List<AstNodeType> A;
    
    protected SymbolTableBuilderVisitor(final AstNodeType... a) {
        this.A = Collections.unmodifiableList((List<? extends AstNodeType>)Arrays.asList((T[])a));
    }
    
    public List<AstNodeType> getNodeTypes() {
        return this.A;
    }
    
    public abstract void visitNode(final SemanticModel p0, final AstNode p1);
}
