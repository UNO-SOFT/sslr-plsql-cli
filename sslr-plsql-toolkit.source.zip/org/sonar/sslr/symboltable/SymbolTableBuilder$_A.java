// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.symboltable;

import com.sonar.sslr.api.AstNode;
import com.sonar.sslr.api.AstNodeType;
import java.util.List;
import com.sonar.sslr.api.AstVisitor;

private static class _A implements AstVisitor
{
    private final SymbolTableBuilderVisitor B;
    private final SemanticModel A;
    
    public _A(final SemanticModel a, final SymbolTableBuilderVisitor b) {
        this.A = a;
        this.B = b;
    }
    
    @Override
    public List<AstNodeType> getAstNodeTypesToVisit() {
        return this.B.getNodeTypes();
    }
    
    @Override
    public void visitFile(final AstNode astNode) {
    }
    
    @Override
    public void leaveFile(final AstNode astNode) {
    }
    
    @Override
    public void visitNode(final AstNode astNode) {
        this.B.visitNode(this.A, astNode);
    }
    
    @Override
    public void leaveNode(final AstNode astNode) {
    }
}
