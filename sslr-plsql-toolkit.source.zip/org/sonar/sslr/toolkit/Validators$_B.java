// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.toolkit;

private static class _B implements ValidationCallback
{
    @Override
    public String validate(final String str) {
        return ("false".equals(str) || "true".equals(str)) ? "" : ("Must be either \"true\" or \"false\": " + str);
    }
}
