// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.toolkit;

import java.nio.charset.UnsupportedCharsetException;
import java.nio.charset.IllegalCharsetNameException;
import java.nio.charset.Charset;

public class Validators
{
    private static final _A B;
    private static final _B A;
    
    private Validators() {
    }
    
    public static ValidationCallback charsetValidator() {
        return Validators.B;
    }
    
    public static ValidationCallback integerRangeValidator(final int n, final int n2) {
        return new _C(n, n2);
    }
    
    public static ValidationCallback booleanValidator() {
        return Validators.A;
    }
    
    static {
        B = new _A();
        A = new _B();
    }
    
    private static class _B implements ValidationCallback
    {
        @Override
        public String validate(final String str) {
            return ("false".equals(str) || "true".equals(str)) ? "" : ("Must be either \"true\" or \"false\": " + str);
        }
    }
    
    private static class _C implements ValidationCallback
    {
        private final int B;
        private final int A;
        
        public _C(final int n, final int n2) {
            if (n > n2) {
                throw new IllegalArgumentException("lowerBound(" + n + ") <= upperBound(" + n2 + ")");
            }
            this.B = n;
            this.A = n2;
        }
        
        @Override
        public String validate(final String s) {
            try {
                final int int1 = Integer.parseInt(s);
                if (int1 < this.B || int1 > this.A) {
                    return this.A(int1);
                }
                return "";
            }
            catch (final NumberFormatException ex) {
                return "Not an integer: " + s;
            }
        }
        
        private String A(final int n) {
            String s;
            if (this.B == this.A) {
                s = "Must be equal to " + this.B + ": " + n;
            }
            else if (this.A == Integer.MAX_VALUE) {
                if (this.B == 0) {
                    s = "Must be positive or 0: " + n;
                }
                else if (this.B == 1) {
                    s = "Must be strictly positive: " + n;
                }
                else {
                    s = "Must be greater or equal to " + this.B + ": " + n;
                }
            }
            else if (this.B == Integer.MIN_VALUE) {
                if (this.A == 0) {
                    s = "Must be negative or 0: " + n;
                }
                else if (this.A == -1) {
                    s = "Must be strictly negative: " + n;
                }
                else {
                    s = "Must be lower or equal to " + this.A + ": " + n;
                }
            }
            else {
                s = "Must be between " + this.B + " and " + this.A + ": " + n;
            }
            return s;
        }
    }
    
    private static class _A implements ValidationCallback
    {
        @Override
        public String validate(final String charsetName) {
            try {
                Charset.forName(charsetName);
                return "";
            }
            catch (final IllegalCharsetNameException ex) {
                return "Illegal charset: " + ex.getMessage();
            }
            catch (final UnsupportedCharsetException ex2) {
                return "Unsupported charset: " + ex2.getMessage();
            }
        }
    }
}
