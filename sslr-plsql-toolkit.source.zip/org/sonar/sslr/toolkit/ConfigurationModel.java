// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.toolkit;

import org.sonar.B.E;
import com.sonar.sslr.impl.Parser;
import java.nio.charset.Charset;
import java.util.List;

public interface ConfigurationModel
{
    List<ConfigurationProperty> getProperties();
    
    void setUpdatedFlag();
    
    Charset getCharset();
    
    Parser getParser();
    
    List<E> getTokenizers();
}
