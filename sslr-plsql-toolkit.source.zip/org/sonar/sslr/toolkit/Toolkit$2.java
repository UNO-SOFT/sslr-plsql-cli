// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.toolkit;

import org.sonar.sslr.internal.toolkit.ToolkitView;
import org.sonar.sslr.internal.toolkit.ToolkitViewImpl;
import org.sonar.sslr.internal.toolkit.ToolkitPresenter;
import org.sonar.sslr.internal.toolkit.SourceCodeModel;
import javax.swing.UIManager;

class Toolkit$2 implements Runnable {
    @Override
    public void run() {
        try {
            for (final UIManager.LookAndFeelInfo lookAndFeelInfo : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(lookAndFeelInfo.getName())) {
                    UIManager.setLookAndFeel(lookAndFeelInfo.getClassName());
                    break;
                }
            }
        }
        catch (final Exception cause) {
            throw new RuntimeException(cause);
        }
        final ToolkitPresenter toolkitPresenter = new ToolkitPresenter(Toolkit.B(Toolkit.this), new SourceCodeModel(Toolkit.B(Toolkit.this)));
        toolkitPresenter.setView(new ToolkitViewImpl(toolkitPresenter));
        toolkitPresenter.run(Toolkit.A(Toolkit.this));
    }
}