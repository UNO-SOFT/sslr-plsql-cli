// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.toolkit;

import java.nio.charset.Charset;
import org.sonar.B.E;
import java.util.List;
import com.sonar.sslr.impl.Parser;

public abstract class AbstractConfigurationModel implements ConfigurationModel
{
    private boolean A;
    private Parser C;
    private List<E> B;
    
    public AbstractConfigurationModel() {
        this.A = true;
    }
    
    @Override
    public void setUpdatedFlag() {
        this.A = true;
    }
    
    private void A() {
        if (this.A) {
            this.C = this.doGetParser();
            this.B = this.doGetTokenizers();
        }
        this.A = false;
    }
    
    @Override
    public Charset getCharset() {
        return Charset.defaultCharset();
    }
    
    @Override
    public Parser getParser() {
        this.A();
        return this.C;
    }
    
    @Override
    public List<E> getTokenizers() {
        this.A();
        return this.B;
    }
    
    public abstract Parser doGetParser();
    
    public abstract List<E> doGetTokenizers();
}
