// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.toolkit;

import java.nio.charset.UnsupportedCharsetException;
import java.nio.charset.IllegalCharsetNameException;
import java.nio.charset.Charset;

private static class _A implements ValidationCallback
{
    @Override
    public String validate(final String charsetName) {
        try {
            Charset.forName(charsetName);
            return "";
        }
        catch (final IllegalCharsetNameException ex) {
            return "Illegal charset: " + ex.getMessage();
        }
        catch (final UnsupportedCharsetException ex2) {
            return "Unsupported charset: " + ex2.getMessage();
        }
    }
}
