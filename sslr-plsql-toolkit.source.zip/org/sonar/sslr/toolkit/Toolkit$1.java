// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.toolkit;

import org.sonar.B.E;
import java.util.Collections;
import com.sonar.sslr.impl.Parser;
import java.util.List;

class Toolkit$1 extends AbstractConfigurationModel {
    final /* synthetic */ List E;
    final /* synthetic */ Parser D;
    
    @Override
    public List<ConfigurationProperty> getProperties() {
        return Collections.emptyList();
    }
    
    @Override
    public List<E> doGetTokenizers() {
        return this.E;
    }
    
    @Override
    public Parser doGetParser() {
        return this.D;
    }
}