// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.toolkit;

import java.util.Objects;

public class ConfigurationProperty
{
    private static final ValidationCallback D;
    private final String B;
    private final String C;
    private String E;
    private final ValidationCallback A;
    
    public ConfigurationProperty(final String s, final String s2, final String s3) {
        this(s, s2, s3, ConfigurationProperty.D);
    }
    
    public ConfigurationProperty(final String s, final String s2, final String e, final ValidationCallback validationCallback) {
        Objects.requireNonNull(s);
        Objects.requireNonNull(s2);
        Objects.requireNonNull(e);
        Objects.requireNonNull(validationCallback);
        final String validate = validationCallback.validate(e);
        if (!"".equals(validate)) {
            throw new IllegalArgumentException("The default value \"" + e + "\" did not pass validation: " + validate);
        }
        this.B = s;
        this.C = s2;
        this.A = validationCallback;
        this.E = e;
    }
    
    public String getName() {
        return this.B;
    }
    
    public String getDescription() {
        return this.C;
    }
    
    public String validate(final String s) {
        return this.A.validate(s);
    }
    
    public void setValue(final String s) {
        final String validate = this.validate(s);
        if (!"".equals(validate)) {
            throw new IllegalArgumentException("The value \"" + s + "\" did not pass validation: " + validate);
        }
        this.E = s;
    }
    
    public String getValue() {
        return this.E;
    }
    
    static {
        D = new ValidationCallback() {
            @Override
            public String validate(final String s) {
                return "";
            }
        };
    }
}
