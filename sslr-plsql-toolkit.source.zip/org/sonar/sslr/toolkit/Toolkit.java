// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.toolkit;

import javax.swing.SwingUtilities;
import org.sonar.sslr.internal.toolkit.ToolkitView;
import org.sonar.sslr.internal.toolkit.ToolkitViewImpl;
import org.sonar.sslr.internal.toolkit.ToolkitPresenter;
import org.sonar.sslr.internal.toolkit.SourceCodeModel;
import javax.swing.UIManager;
import java.util.Objects;
import java.util.Collections;
import org.sonar.B.E;
import java.util.List;
import com.sonar.sslr.impl.Parser;

public class Toolkit
{
    private final String B;
    private final ConfigurationModel A;
    
    @Deprecated
    public Toolkit(final Parser parser, final List<E> list, final String s) {
        this(s, new AbstractConfigurationModel() {
            @Override
            public List<ConfigurationProperty> getProperties() {
                return Collections.emptyList();
            }
            
            @Override
            public List<E> doGetTokenizers() {
                return list;
            }
            
            @Override
            public Parser doGetParser() {
                return parser;
            }
        });
    }
    
    public Toolkit(final String s, final ConfigurationModel a) {
        Objects.requireNonNull(s);
        this.B = s;
        this.A = a;
    }
    
    public void run() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    for (final UIManager.LookAndFeelInfo lookAndFeelInfo : UIManager.getInstalledLookAndFeels()) {
                        if ("Nimbus".equals(lookAndFeelInfo.getName())) {
                            UIManager.setLookAndFeel(lookAndFeelInfo.getClassName());
                            break;
                        }
                    }
                }
                catch (final Exception cause) {
                    throw new RuntimeException(cause);
                }
                final ToolkitPresenter toolkitPresenter = new ToolkitPresenter(Toolkit.this.A, new SourceCodeModel(Toolkit.this.A));
                toolkitPresenter.setView(new ToolkitViewImpl(toolkitPresenter));
                toolkitPresenter.run(Toolkit.this.B);
            }
        });
    }
}
