// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.toolkit;

class ConfigurationProperty$1 implements ValidationCallback {
    @Override
    public String validate(final String s) {
        return "";
    }
}