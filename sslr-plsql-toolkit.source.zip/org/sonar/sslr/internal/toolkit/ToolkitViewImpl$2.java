// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

class ToolkitViewImpl$2 implements DocumentListener {
    @Override
    public void removeUpdate(final DocumentEvent documentEvent) {
        ToolkitViewImpl.this.presenter.onSourceCodeKeyTyped();
    }
    
    @Override
    public void insertUpdate(final DocumentEvent documentEvent) {
        ToolkitViewImpl.this.presenter.onSourceCodeKeyTyped();
    }
    
    @Override
    public void changedUpdate(final DocumentEvent documentEvent) {
        ToolkitViewImpl.this.presenter.onSourceCodeKeyTyped();
    }
}