// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import java.awt.GridBagConstraints;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusAdapter;
import java.util.ArrayList;
import java.util.List;
import java.util.Enumeration;
import com.sonar.sslr.api.Token;
import javax.swing.text.Highlighter;
import javax.swing.tree.TreePath;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.BadLocationException;
import javax.swing.SwingUtilities;
import java.awt.Point;
import java.util.Iterator;
import com.sonar.sslr.api.Trivia;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.annotation.Nullable;
import com.sonar.sslr.api.AstNode;
import java.io.File;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.DefaultCaret;
import javax.swing.Box;
import java.awt.Font;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import java.util.Objects;
import java.awt.Color;
import java.util.HashMap;
import java.awt.BorderLayout;
import java.awt.LayoutManager;
import java.awt.GridBagLayout;
import java.awt.Component;
import javax.swing.text.DefaultHighlighter;
import javax.swing.JFileChooser;
import javax.swing.JSplitPane;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import java.util.Map;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.JTabbedPane;
import javax.swing.tree.TreeModel;
import javax.swing.JFrame;

public class ToolkitViewImpl extends JFrame implements ToolkitView
{
    private static final long K = 1L;
    private static final TreeModel O;
    public final transient ToolkitPresenter presenter;
    private final JTabbedPane D;
    private final JTree G;
    private final JScrollPane T;
    private final JTextArea a;
    private final JScrollPane N;
    private final JTextArea V;
    private final JScrollPane d;
    private final JPanel B;
    private final JPanel R;
    private final JScrollPane H;
    private final Map<String, ConfigurationPropertyPanel> Z;
    private final JLabel b;
    private final JEditorPane M;
    private final JScrollPane X;
    private final JButton _;
    private final JButton W;
    private final JPanel J;
    private final JPanel e;
    private final JSplitPane U;
    private final JPanel L;
    private final JLabel I;
    private final JTextArea A;
    private final JScrollPane F;
    private final JPanel P;
    private final JFileChooser S;
    private final JButton C;
    private final JPanel E;
    private transient LineOffsets c;
    private final transient DefaultHighlighter.DefaultHighlightPainter f;
    private boolean Q;
    private boolean Y;
    
    public ToolkitViewImpl(final ToolkitPresenter toolkitPresenter) {
        this.D = new JTabbedPane();
        this.G = new JTree();
        this.T = new JScrollPane(this.G);
        this.a = new JTextArea();
        this.N = new JScrollPane(this.a);
        this.V = new JTextArea();
        this.d = new JScrollPane(this.V);
        this.B = new JPanel(new GridBagLayout());
        this.R = new JPanel(new BorderLayout());
        this.H = new JScrollPane(this.R);
        this.Z = new HashMap<String, ConfigurationPropertyPanel>();
        this.b = new JLabel(" Source Code");
        this.M = new JEditorPane();
        this.X = new JScrollPane(this.M);
        this._ = new JButton();
        this.W = new JButton();
        this.J = new JPanel();
        this.e = new JPanel(new BorderLayout(0, 2));
        this.U = new JSplitPane(1, this.e, this.D);
        this.L = new JPanel(new BorderLayout(0, 2));
        this.I = new JLabel("  XPath query");
        this.A = new JTextArea();
        this.F = new JScrollPane(this.A);
        this.P = new JPanel(new BorderLayout(10, 2));
        this.S = new JFileChooser();
        this.C = new JButton();
        this.E = new JPanel();
        this.c = null;
        this.f = new DefaultHighlighter.DefaultHighlightPainter(Color.LIGHT_GRAY);
        this.Q = false;
        this.Y = false;
        Objects.requireNonNull(toolkitPresenter);
        this.presenter = toolkitPresenter;
        this.B();
    }
    
    private void B() {
        this.setSize(1000, 700);
        this.setDefaultCloseOperation(3);
        this.setLayout(new BorderLayout(0, 5));
        this.G.getSelectionModel().setSelectionMode(4);
        this.G.addTreeSelectionListener(new TreeSelectionListener() {
            @Override
            public void valueChanged(final TreeSelectionEvent treeSelectionEvent) {
                if (!ToolkitViewImpl.this.Y) {
                    ToolkitViewImpl.this.presenter.onAstSelectionChanged();
                }
            }
        });
        this.V.setEditable(false);
        this.V.setFont(Font.decode("Monospaced"));
        this.D.setTabPlacement(1);
        this.D.add("Abstract Syntax Tree", this.T);
        this.D.add("XML", this.N);
        this.D.add("Console", this.d);
        this.D.add("Configuration", this.H);
        this.R.add(this.B, "North");
        this.R.add(Box.createGlue(), "Center");
        this.M.setContentType("text/html");
        this.M.setEditable(true);
        ((DefaultCaret)this.M.getCaret()).setUpdatePolicy(0);
        this.M.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void removeUpdate(final DocumentEvent documentEvent) {
                ToolkitViewImpl.this.presenter.onSourceCodeKeyTyped();
            }
            
            @Override
            public void insertUpdate(final DocumentEvent documentEvent) {
                ToolkitViewImpl.this.presenter.onSourceCodeKeyTyped();
            }
            
            @Override
            public void changedUpdate(final DocumentEvent documentEvent) {
                ToolkitViewImpl.this.presenter.onSourceCodeKeyTyped();
            }
        });
        this.M.addCaretListener(new CaretListener() {
            @Override
            public void caretUpdate(final CaretEvent caretEvent) {
                if (!ToolkitViewImpl.this.Q) {
                    ToolkitViewImpl.this.presenter.onSourceCodeTextCursorMoved();
                }
            }
        });
        this._.setText("Open Source File");
        this._.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent actionEvent) {
                ToolkitViewImpl.this.presenter.onSourceCodeOpenButtonClick();
            }
        });
        this.W.setText("Parse Source Code");
        this.W.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent actionEvent) {
                ToolkitViewImpl.this.presenter.onSourceCodeParseButtonClick();
            }
        });
        this.J.add(this._);
        this.J.add(this.W);
        this.e.add(this.b, "North");
        this.e.add(this.X, "Center");
        this.e.add(this.J, "South");
        this.U.setDividerLocation(this.getWidth() / 2);
        this.add(this.U, "Center");
        this.P.add(this.I, "North");
        this.P.add(Box.createHorizontalGlue(), "West");
        this.A.setText("//IDENTIFIER");
        this.A.setRows(8);
        this.P.add(this.F, "Center");
        this.P.add(Box.createHorizontalGlue(), "East");
        this.L.add(this.P, "North");
        this.C.setText("Evaluate XPath");
        this.C.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent actionEvent) {
                ToolkitViewImpl.this.presenter.onXPathEvaluateButtonClick();
            }
        });
        this.E.add(this.C);
        this.L.add(this.E, "South");
        this.add(this.L, "South");
    }
    
    @Override
    public void run() {
        this.setVisible(true);
    }
    
    @Override
    public File pickFileToParse() {
        if (this.S.showOpenDialog(this) == 0) {
            return this.S.getSelectedFile();
        }
        return null;
    }
    
    @Override
    public void displayHighlightedSourceCode(final String s) {
        try {
            this.Q = true;
            Objects.requireNonNull(s);
            final StringBuilder sb = new StringBuilder();
            sb.append("<html><head><style type=\"text/css\">");
            sb.append(CssLoader.getCss());
            sb.append("</style></head><body><pre class=\"code\" id=\"code\">");
            sb.append(s);
            sb.append("</pre></body></html>");
            this.M.setText(sb.toString());
            this.c = new LineOffsets(this.getSourceCode());
        }
        finally {
            this.Q = false;
        }
    }
    
    @Override
    public void displayAst(@Nullable final AstNode astNode) {
        if (astNode == null) {
            this.G.setModel(ToolkitViewImpl.O);
        }
        else {
            this.G.setModel(new DefaultTreeModel(A(astNode)));
        }
    }
    
    private static DefaultMutableTreeNode A(final AstNode userObject) {
        final DefaultMutableTreeNode defaultMutableTreeNode = new DefaultMutableTreeNode(userObject);
        if (userObject.hasChildren()) {
            final Iterator<AstNode> iterator = userObject.getChildren().iterator();
            while (iterator.hasNext()) {
                defaultMutableTreeNode.add(A(iterator.next()));
            }
        }
        else if (userObject.hasToken() && userObject.getToken().hasTrivia()) {
            for (final Trivia userObject2 : userObject.getToken().getTrivia()) {
                final DefaultMutableTreeNode newChild = new DefaultMutableTreeNode(userObject2);
                if (userObject2.hasPreprocessingDirective()) {
                    newChild.add(A(userObject2.getPreprocessingDirective().getAst()));
                }
                defaultMutableTreeNode.add(newChild);
            }
        }
        return defaultMutableTreeNode;
    }
    
    @Override
    public void displayXml(final String s) {
        Objects.requireNonNull(s);
        this.a.setText(s);
    }
    
    @Override
    public Point getSourceCodeScrollbarPosition() {
        return new Point(this.X.getHorizontalScrollBar().getValue(), this.X.getVerticalScrollBar().getValue());
    }
    
    @Override
    public void scrollSourceCodeTo(final Point obj) {
        Objects.requireNonNull(obj);
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                ToolkitViewImpl.this.X.getHorizontalScrollBar().setValue(obj.x);
                ToolkitViewImpl.this.X.getVerticalScrollBar().setValue(obj.y);
            }
        });
    }
    
    @Override
    public String getSourceCode() {
        final int a = this.A();
        final int c = this.C();
        try {
            return this.M.getText(a, c - a - 1);
        }
        catch (final BadLocationException cause) {
            throw new RuntimeException(cause);
        }
    }
    
    private int A() {
        return ((HTMLDocument)this.M.getDocument()).getElement("code").getStartOffset();
    }
    
    private int C() {
        return ((HTMLDocument)this.M.getDocument()).getElement("code").getEndOffset();
    }
    
    @Override
    public String getXPath() {
        return this.A.getText();
    }
    
    @Override
    public void selectAstNode(final AstNode astNode) {
        if (astNode != null) {
            try {
                this.Y = true;
                this.G.getSelectionModel().addSelectionPath(new TreePath(this.A((DefaultMutableTreeNode)this.G.getModel().getRoot(), astNode).getPath()));
            }
            finally {
                this.Y = false;
            }
        }
    }
    
    private DefaultMutableTreeNode A(final DefaultMutableTreeNode defaultMutableTreeNode, final Object obj) {
        if (defaultMutableTreeNode.getUserObject().equals(obj)) {
            return defaultMutableTreeNode;
        }
        for (int i = 0; i < defaultMutableTreeNode.getChildCount(); ++i) {
            final DefaultMutableTreeNode a = this.A((DefaultMutableTreeNode)defaultMutableTreeNode.getChildAt(i), obj);
            if (a != null) {
                return a;
            }
        }
        return null;
    }
    
    @Override
    public void highlightSourceCode(final AstNode obj) {
        Objects.requireNonNull(obj);
        if (!obj.hasToken()) {
            return;
        }
        final Token token = obj.getToken();
        final Token lastToken = obj.getLastToken();
        final int a = this.A(this.c.getStartOffset(token));
        final int a2 = this.A(this.c.getEndOffset(lastToken));
        try {
            this.M.getHighlighter().addHighlight(a, a2, this.f);
        }
        catch (final BadLocationException cause) {
            throw new RuntimeException(cause);
        }
    }
    
    private int A(final int a) {
        return Math.min(Math.max(a, 0) + this.A(), this.C());
    }
    
    @Override
    public void clearAstSelections() {
        try {
            this.Y = true;
            this.G.getSelectionModel().clearSelection();
        }
        finally {
            this.Y = false;
        }
    }
    
    @Override
    public void scrollAstTo(@Nullable final AstNode astNode) {
        if (astNode != null) {
            this.G.scrollPathToVisible(new TreePath(this.A((DefaultMutableTreeNode)this.G.getModel().getRoot(), astNode).getPath()));
        }
    }
    
    @Override
    public void clearSourceCodeHighlights() {
        this.M.getHighlighter().removeAllHighlights();
    }
    
    @Override
    public void scrollSourceCodeTo(@Nullable final AstNode astNode) {
        if (astNode != null && astNode.hasToken()) {
            final int n = astNode.getToken().getLine() + this.M.getVisibleRect().height / this.M.getFontMetrics(this.M.getFont()).getHeight() / 2;
            try {
                this.M.scrollRectToVisible(this.M.modelToView(0));
                this.M.scrollRectToVisible(this.M.modelToView(this.c.getOffset(n, 0)));
            }
            catch (final BadLocationException cause) {
                throw new RuntimeException(cause);
            }
        }
    }
    
    @Override
    public void disableXPathEvaluateButton() {
        this.C.setEnabled(false);
    }
    
    @Override
    public void enableXPathEvaluateButton() {
        this.C.setEnabled(true);
    }
    
    @Nullable
    @Override
    public AstNode getAstNodeFollowingCurrentSourceCodeTextCursorPosition() {
        return this.A((DefaultMutableTreeNode)this.G.getModel().getRoot(), this.M.getCaretPosition() - this.A());
    }
    
    private AstNode A(final DefaultMutableTreeNode defaultMutableTreeNode, final int n) {
        AstNode astNode = null;
        if (defaultMutableTreeNode != null) {
            final Enumeration<TreeNode> breadthFirstEnumeration = ((DefaultMutableTreeNode)this.G.getModel().getRoot()).breadthFirstEnumeration();
            int n2 = Integer.MAX_VALUE;
            while (breadthFirstEnumeration.hasMoreElements()) {
                final DefaultMutableTreeNode defaultMutableTreeNode2 = breadthFirstEnumeration.nextElement();
                if (defaultMutableTreeNode2.getUserObject() instanceof AstNode) {
                    final AstNode astNode2 = (AstNode)defaultMutableTreeNode2.getUserObject();
                    if (!astNode2.hasToken()) {
                        continue;
                    }
                    final int startOffset = this.c.getStartOffset(astNode2.getToken());
                    if (startOffset < n || startOffset >= n2) {
                        continue;
                    }
                    n2 = startOffset;
                    astNode = astNode2;
                }
            }
        }
        return astNode;
    }
    
    @Override
    public List<AstNode> getSelectedAstNodes() {
        final ArrayList list = new ArrayList();
        final TreePath[] selectionPaths = this.G.getSelectionPaths();
        if (selectionPaths != null) {
            final TreePath[] array = selectionPaths;
            for (int length = array.length, i = 0; i < length; ++i) {
                final Object userObject = ((DefaultMutableTreeNode)array[i].getLastPathComponent()).getUserObject();
                if (userObject instanceof AstNode) {
                    list.add(userObject);
                }
            }
        }
        return list;
    }
    
    @Override
    public void appendToConsole(final String str) {
        this.V.append(str);
    }
    
    @Override
    public void setFocusOnConsoleView() {
        this.D.setSelectedComponent(this.d);
    }
    
    @Override
    public void setFocusOnAbstractSyntaxTreeView() {
        this.D.setSelectedComponent(this.T);
    }
    
    @Override
    public void clearConsole() {
        this.V.setText("");
    }
    
    @Override
    public void addConfigurationProperty(final String s, final String s2) {
        final ConfigurationPropertyPanel configurationPropertyPanel = new ConfigurationPropertyPanel(s, s2);
        configurationPropertyPanel.getValueTextField().addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(final FocusEvent focusEvent) {
                ToolkitViewImpl.this.presenter.onConfigurationPropertyFocusLost(s);
            }
        });
        this.Z.put(s, configurationPropertyPanel);
        final GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = 2;
        constraints.weightx = 1.0;
        constraints.gridx = 0;
        constraints.anchor = 11;
        this.B.add(configurationPropertyPanel.getPanel(), constraints);
    }
    
    @Override
    public String getConfigurationPropertyValue(final String s) {
        return this.Z.get(s).getValueTextField().getText();
    }
    
    @Override
    public void setConfigurationPropertyValue(final String s, final String text) {
        this.Z.get(s).getValueTextField().setText(text);
    }
    
    @Override
    public void setConfigurationPropertyErrorMessage(final String s, final String text) {
        this.Z.get(s).getErrorMessageLabel().setText(text);
    }
    
    @Override
    public void setFocusOnConfigurationPropertyField(final String s) {
        this.Z.get(s).getValueTextField().requestFocus();
    }
    
    @Override
    public void setFocusOnConfigurationView() {
        this.D.setSelectedComponent(this.H);
    }
    
    static {
        O = new DefaultTreeModel(null);
    }
}
