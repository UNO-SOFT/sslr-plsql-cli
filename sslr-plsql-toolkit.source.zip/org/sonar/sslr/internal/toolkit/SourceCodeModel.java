// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import com.sonar.sslr.impl.ast.AstXmlPrinter;
import org.sonar.B.F;
import org.sonar.A.D;
import java.util.List;
import java.io.Reader;
import java.io.StringReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.charset.Charset;
import java.io.File;
import java.util.Objects;
import org.sonar.B.Q;
import com.sonar.sslr.api.AstNode;
import org.sonar.B._;
import org.sonar.sslr.toolkit.ConfigurationModel;

public class SourceCodeModel
{
    private final ConfigurationModel D;
    private final _ B;
    private String C;
    private AstNode A;
    
    public SourceCodeModel(final ConfigurationModel configurationModel) {
        this.B = new _(new Q(false, null, false));
        Objects.requireNonNull(configurationModel);
        this.D = configurationModel;
    }
    
    public void setSourceCode(final File file, final Charset charset) {
        this.A = this.D.getParser().parse(file);
        try {
            this.C = new String(Files.readAllBytes(Paths.get(file.getPath(), new String[0])), charset);
        }
        catch (final IOException cause) {
            throw new RuntimeException(cause);
        }
    }
    
    public void setSourceCode(final String c) {
        this.A = this.D.getParser().parse(c);
        this.C = c;
    }
    
    public String getHighlightedSourceCode() {
        return this.B.A(new StringReader(this.C), this.D.getTokenizers());
    }
    
    public String getXml() {
        return AstXmlPrinter.print(this.A);
    }
    
    public AstNode getAstNode() {
        return this.A;
    }
}
