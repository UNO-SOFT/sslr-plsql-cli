// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

class ToolkitViewImpl$1 implements TreeSelectionListener {
    @Override
    public void valueChanged(final TreeSelectionEvent treeSelectionEvent) {
        if (!ToolkitViewImpl.B(ToolkitViewImpl.this)) {
            ToolkitViewImpl.this.presenter.onAstSelectionChanged();
        }
    }
}