// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ToolkitViewImpl$4 implements ActionListener {
    @Override
    public void actionPerformed(final ActionEvent actionEvent) {
        ToolkitViewImpl.this.presenter.onSourceCodeOpenButtonClick();
    }
}