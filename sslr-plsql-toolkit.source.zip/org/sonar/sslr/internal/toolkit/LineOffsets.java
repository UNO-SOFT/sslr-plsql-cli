// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import com.sonar.sslr.api.Token;
import java.util.HashMap;
import java.util.Map;

public class LineOffsets
{
    private static final String A = "(\r)?\n|\r";
    private final Map<Integer, Integer> C;
    private final int B;
    
    public LineOffsets(final String s) {
        this.C = new HashMap<Integer, Integer>();
        int i = 0;
        final String[] split = s.split("(\r)?\n|\r", -1);
        for (int j = 1; j <= split.length; ++j) {
            this.C.put(j, i);
            i += split[j - 1].length() + 1;
        }
        this.B = i - 1;
    }
    
    public int getStartOffset(final Token token) {
        return this.getOffset(token.getLine(), token.getColumn());
    }
    
    public int getEndOffset(final Token token) {
        final String[] split = token.getOriginalValue().split("(\r)?\n|\r", -1);
        return this.getOffset(token.getLine() + split.length - 1, ((split.length > 1) ? 0 : token.getColumn()) + split[split.length - 1].length());
    }
    
    public int getOffset(final int n, final int n2) {
        if (n < 1) {
            throw new IllegalArgumentException();
        }
        if (n2 < 0) {
            throw new IllegalArgumentException();
        }
        if (this.C.containsKey(n)) {
            return Math.min(this.C.get(n) + n2, this.B);
        }
        return this.B;
    }
}
