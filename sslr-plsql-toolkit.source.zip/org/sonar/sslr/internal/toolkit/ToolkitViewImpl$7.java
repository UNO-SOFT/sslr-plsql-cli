// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import java.awt.Point;

class ToolkitViewImpl$7 implements Runnable {
    final /* synthetic */ Point B;
    
    @Override
    public void run() {
        ToolkitViewImpl.A(ToolkitViewImpl.this).getHorizontalScrollBar().setValue(this.B.x);
        ToolkitViewImpl.A(ToolkitViewImpl.this).getVerticalScrollBar().setValue(this.B.y);
    }
}