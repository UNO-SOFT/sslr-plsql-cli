// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import javax.swing.Box;
import java.awt.Color;
import java.awt.Component;
import javax.swing.border.Border;
import javax.swing.BorderFactory;
import java.awt.Insets;
import java.awt.GridBagConstraints;
import java.awt.LayoutManager;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPanel;
import java.io.Serializable;

public class ConfigurationPropertyPanel implements Serializable
{
    private static final long D = 1L;
    private final JPanel A;
    private final JTextField C;
    private final JLabel B;
    
    public ConfigurationPropertyPanel(final String title, final String text) {
        this.A = new JPanel(new GridBagLayout());
        final GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = 2;
        constraints.weightx = 1.0;
        constraints.gridx = 0;
        constraints.anchor = 11;
        constraints.insets = new Insets(3, 10, 3, 10);
        this.A.setBorder(BorderFactory.createTitledBorder(title));
        this.A.add(new JLabel(text), constraints);
        this.C = new JTextField();
        this.A.add(this.C, constraints);
        (this.B = new JLabel()).setForeground(Color.RED);
        this.A.add(this.B, constraints);
        final GridBagConstraints constraints2 = new GridBagConstraints();
        constraints2.gridx = 0;
        constraints2.weighty = 1.0;
        this.A.add(Box.createGlue(), constraints2);
    }
    
    public JPanel getPanel() {
        return this.A;
    }
    
    public JLabel getErrorMessageLabel() {
        return this.B;
    }
    
    public JTextField getValueTextField() {
        return this.C;
    }
}
