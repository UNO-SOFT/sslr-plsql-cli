// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import com.sonar.sslr.xpath.api.AstNodeXPathQuery;
import java.io.File;
import java.awt.Point;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import com.sonar.sslr.api.AstNode;
import java.util.Iterator;
import org.sonar.sslr.toolkit.ConfigurationProperty;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Objects;
import org.sonar.sslr.toolkit.ConfigurationModel;

public class ToolkitPresenter
{
    private final ConfigurationModel C;
    private final SourceCodeModel B;
    private ToolkitView A;
    
    public ToolkitPresenter(final ConfigurationModel c, final SourceCodeModel b) {
        this.A = null;
        this.C = c;
        this.B = b;
    }
    
    public void setView(final ToolkitView toolkitView) {
        Objects.requireNonNull(toolkitView);
        this.A = toolkitView;
    }
    
    void C() {
        if (this.A == null) {
            throw new IllegalStateException("the view must be set before the presenter can be ran");
        }
    }
    
    void B() {
        Thread.currentThread().setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(final Thread thread, final Throwable t) {
                final StringWriter out = new StringWriter();
                t.printStackTrace(new PrintWriter(out));
                ToolkitPresenter.this.A.appendToConsole(out.toString());
                ToolkitPresenter.this.A.setFocusOnConsoleView();
            }
        });
    }
    
    void A() {
        for (final ConfigurationProperty configurationProperty : this.C.getProperties()) {
            this.A.addConfigurationProperty(configurationProperty.getName(), configurationProperty.getDescription());
            this.A.setConfigurationPropertyValue(configurationProperty.getName(), configurationProperty.getValue());
        }
    }
    
    public void run(final String title) {
        this.C();
        this.B();
        this.A.setTitle(title);
        this.A.displayHighlightedSourceCode("");
        this.A.displayAst(null);
        this.A.displayXml("");
        this.A.disableXPathEvaluateButton();
        this.A();
        this.A.run();
    }
    
    public void onSourceCodeOpenButtonClick() {
        final File pickFileToParse = this.A.pickFileToParse();
        if (pickFileToParse != null) {
            this.A.clearConsole();
            try {
                this.A.displayHighlightedSourceCode(new String(Files.readAllBytes(Paths.get(pickFileToParse.getPath(), new String[0])), this.C.getCharset()));
            }
            catch (final IOException cause) {
                throw new RuntimeException(cause);
            }
            this.B.setSourceCode(pickFileToParse, this.C.getCharset());
            this.A.displayHighlightedSourceCode(this.B.getHighlightedSourceCode());
            this.A.displayAst(this.B.getAstNode());
            this.A.displayXml(this.B.getXml());
            this.A.scrollSourceCodeTo(new Point(0, 0));
            this.A.setFocusOnAbstractSyntaxTreeView();
            this.A.enableXPathEvaluateButton();
        }
    }
    
    public void onSourceCodeParseButtonClick() {
        this.A.clearConsole();
        this.B.setSourceCode(this.A.getSourceCode());
        final Point sourceCodeScrollbarPosition = this.A.getSourceCodeScrollbarPosition();
        this.A.displayHighlightedSourceCode(this.B.getHighlightedSourceCode());
        this.A.displayAst(this.B.getAstNode());
        this.A.displayXml(this.B.getXml());
        this.A.scrollSourceCodeTo(sourceCodeScrollbarPosition);
        this.A.setFocusOnAbstractSyntaxTreeView();
        this.A.enableXPathEvaluateButton();
    }
    
    public void onXPathEvaluateButtonClick() {
        final AstNodeXPathQuery<Object> create = (AstNodeXPathQuery<Object>)AstNodeXPathQuery.create(this.A.getXPath());
        this.A.clearConsole();
        this.A.clearAstSelections();
        this.A.clearSourceCodeHighlights();
        AstNode astNode = null;
        for (final AstNode next : create.selectNodes(this.B.getAstNode())) {
            if (next instanceof AstNode) {
                final AstNode astNode2 = next;
                if (astNode == null) {
                    astNode = astNode2;
                }
                this.A.selectAstNode(astNode2);
                this.A.highlightSourceCode(astNode2);
            }
        }
        this.A.scrollAstTo(astNode);
        this.A.scrollSourceCodeTo(astNode);
        this.A.setFocusOnAbstractSyntaxTreeView();
    }
    
    public void onSourceCodeKeyTyped() {
        this.A.displayAst(null);
        this.A.displayXml("");
        this.A.clearSourceCodeHighlights();
        this.A.disableXPathEvaluateButton();
    }
    
    public void onSourceCodeTextCursorMoved() {
        this.A.clearAstSelections();
        final AstNode astNodeFollowingCurrentSourceCodeTextCursorPosition = this.A.getAstNodeFollowingCurrentSourceCodeTextCursorPosition();
        this.A.selectAstNode(astNodeFollowingCurrentSourceCodeTextCursorPosition);
        this.A.scrollAstTo(astNodeFollowingCurrentSourceCodeTextCursorPosition);
    }
    
    public void onAstSelectionChanged() {
        this.A.clearSourceCodeHighlights();
        AstNode astNode = null;
        for (final AstNode astNode2 : this.A.getSelectedAstNodes()) {
            if (astNode == null) {
                astNode = astNode2;
            }
            this.A.highlightSourceCode(astNode2);
        }
        this.A.scrollSourceCodeTo(astNode);
    }
    
    public void onConfigurationPropertyFocusLost(final String s) {
        final ConfigurationProperty a = this.A(s);
        if (a == null) {
            throw new IllegalArgumentException("No such configuration property: " + s);
        }
        final String configurationPropertyValue = this.A.getConfigurationPropertyValue(s);
        final String validate = a.validate(configurationPropertyValue);
        this.A.setConfigurationPropertyErrorMessage(a.getName(), validate);
        if ("".equals(validate)) {
            a.setValue(configurationPropertyValue);
            this.C.setUpdatedFlag();
        }
        else {
            this.A.setFocusOnConfigurationPropertyField(s);
            this.A.setFocusOnConfigurationView();
        }
    }
    
    private ConfigurationProperty A(final String s) {
        for (final ConfigurationProperty configurationProperty : this.C.getProperties()) {
            if (s.equals(configurationProperty.getName())) {
                return configurationProperty;
            }
        }
        return null;
    }
}
