// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;

class ToolkitPresenter$1 implements Thread.UncaughtExceptionHandler {
    @Override
    public void uncaughtException(final Thread thread, final Throwable t) {
        final StringWriter out = new StringWriter();
        t.printStackTrace(new PrintWriter(out));
        ToolkitPresenter.A(ToolkitPresenter.this).appendToConsole(out.toString());
        ToolkitPresenter.A(ToolkitPresenter.this).setFocusOnConsoleView();
    }
}