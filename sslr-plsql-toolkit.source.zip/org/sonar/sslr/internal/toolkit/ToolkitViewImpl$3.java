// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

class ToolkitViewImpl$3 implements CaretListener {
    @Override
    public void caretUpdate(final CaretEvent caretEvent) {
        if (!ToolkitViewImpl.C(ToolkitViewImpl.this)) {
            ToolkitViewImpl.this.presenter.onSourceCodeTextCursorMoved();
        }
    }
}