// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import java.awt.event.FocusEvent;
import java.awt.event.FocusAdapter;

class ToolkitViewImpl$8 extends FocusAdapter {
    final /* synthetic */ String B;
    
    @Override
    public void focusLost(final FocusEvent focusEvent) {
        ToolkitViewImpl.this.presenter.onConfigurationPropertyFocusLost(this.B);
    }
}