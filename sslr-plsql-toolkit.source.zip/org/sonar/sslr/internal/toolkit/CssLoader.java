// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import java.io.IOException;
import org.B.A.A.W;

public final class CssLoader
{
    private static final String A = "/org/sonar/sslr/toolkit/sourceCodeEditor.css";
    
    private CssLoader() {
    }
    
    public static String getCss() {
        try {
            return W.B(CssLoader.class.getResourceAsStream("/org/sonar/sslr/toolkit/sourceCodeEditor.css"));
        }
        catch (final IOException cause) {
            throw new RuntimeException(cause);
        }
    }
}
