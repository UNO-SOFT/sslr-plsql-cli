// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.toolkit;

import java.util.List;
import java.awt.Point;
import com.sonar.sslr.api.AstNode;
import javax.annotation.Nullable;
import java.io.File;

public interface ToolkitView
{
    void run();
    
    void setTitle(final String p0);
    
    @Nullable
    File pickFileToParse();
    
    void displayHighlightedSourceCode(final String p0);
    
    void displayAst(@Nullable final AstNode p0);
    
    void displayXml(final String p0);
    
    Point getSourceCodeScrollbarPosition();
    
    void scrollSourceCodeTo(final Point p0);
    
    String getSourceCode();
    
    String getXPath();
    
    void selectAstNode(@Nullable final AstNode p0);
    
    void clearAstSelections();
    
    void scrollAstTo(@Nullable final AstNode p0);
    
    void highlightSourceCode(final AstNode p0);
    
    void clearSourceCodeHighlights();
    
    void scrollSourceCodeTo(@Nullable final AstNode p0);
    
    void disableXPathEvaluateButton();
    
    void enableXPathEvaluateButton();
    
    @Nullable
    AstNode getAstNodeFollowingCurrentSourceCodeTextCursorPosition();
    
    List<AstNode> getSelectedAstNodes();
    
    void appendToConsole(final String p0);
    
    void setFocusOnConsoleView();
    
    void setFocusOnAbstractSyntaxTreeView();
    
    void clearConsole();
    
    void addConfigurationProperty(final String p0, final String p1);
    
    String getConfigurationPropertyValue(final String p0);
    
    void setConfigurationPropertyValue(final String p0, final String p1);
    
    void setConfigurationPropertyErrorMessage(final String p0, final String p1);
    
    void setFocusOnConfigurationPropertyField(final String p0);
    
    void setFocusOnConfigurationView();
}
