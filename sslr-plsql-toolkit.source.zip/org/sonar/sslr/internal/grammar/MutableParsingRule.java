// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.grammar;

import org.sonar.sslr.internal.vm.RuleRefExpression;
import org.sonar.sslr.internal.vm.Instruction;
import org.sonar.sslr.internal.vm.CompilationHandler;
import com.sonar.sslr.api.AstNode;
import com.sonar.sslr.impl.ast.SkipFromAstIfOnlyOneChild;
import com.sonar.sslr.impl.ast.AlwaysSkipFromAst;
import org.sonar.sslr.internal.vm.SequenceExpression;
import org.sonar.sslr.internal.vm.FirstOfExpression;
import org.sonar.sslr.internal.vm.EndOfInputExpression;
import org.sonar.sslr.internal.vm.PatternExpression;
import org.sonar.sslr.internal.vm.StringExpression;
import org.sonar.sslr.parser.GrammarOperators;
import org.sonar.sslr.grammar.GrammarException;
import com.sonar.sslr.api.AstNodeType;
import com.sonar.sslr.impl.ast.NeverSkipFromAst;
import org.sonar.sslr.internal.vm.ParsingExpression;
import org.sonar.sslr.grammar.GrammarRuleKey;
import org.sonar.sslr.internal.vm.MemoParsingExpression;
import com.sonar.sslr.api.AstNodeSkippingPolicy;
import com.sonar.sslr.api.Rule;
import org.sonar.sslr.internal.matchers.Matcher;
import org.sonar.sslr.internal.vm.CompilableGrammarRule;

public class MutableParsingRule implements CompilableGrammarRule, Matcher, Rule, AstNodeSkippingPolicy, MemoParsingExpression, GrammarRuleKey
{
    private final GrammarRuleKey \u02e1;
    private final String \u02e2;
    private ParsingExpression \u02e4;
    private AstNodeSkippingPolicy \u02e3;
    
    public MutableParsingRule(final String \u02e2) {
        this.\u02e3 = NeverSkipFromAst.INSTANCE;
        this.\u02e1 = this;
        this.\u02e2 = \u02e2;
    }
    
    public MutableParsingRule(final GrammarRuleKey \u02e1) {
        this.\u02e3 = NeverSkipFromAst.INSTANCE;
        this.\u02e1 = \u02e1;
        this.\u02e2 = \u02e1.toString();
    }
    
    public String getName() {
        return this.\u02e2;
    }
    
    public AstNodeType getRealAstNodeType() {
        return this.\u02e1;
    }
    
    @Override
    public GrammarRuleKey getRuleKey() {
        return this.\u02e1;
    }
    
    @Override
    public ParsingExpression getExpression() {
        return this.\u02e4;
    }
    
    @Override
    public Rule is(final Object... array) {
        if (this.\u02e4 != null) {
            throw new GrammarException("The rule '" + this.\u02e1 + "' has already been defined somewhere in the grammar.");
        }
        this.setExpression((ParsingExpression)GrammarOperators.sequence(array));
        return this;
    }
    
    @Override
    public Rule override(final Object... array) {
        this.setExpression((ParsingExpression)GrammarOperators.sequence(array));
        return this;
    }
    
    @Override
    public void mock() {
        this.setExpression(new SequenceExpression(new ParsingExpression[] { new StringExpression(this.getName()), new FirstOfExpression(new ParsingExpression[] { new PatternExpression("\\s++"), EndOfInputExpression.INSTANCE }) }));
    }
    
    @Override
    public void setExpression(final ParsingExpression \u02e4) {
        this.\u02e4 = \u02e4;
    }
    
    @Override
    public void skip() {
        this.\u02e3 = AlwaysSkipFromAst.INSTANCE;
    }
    
    @Override
    public void skipIfOneChild() {
        this.\u02e3 = SkipFromAstIfOnlyOneChild.INSTANCE;
    }
    
    @Override
    public boolean hasToBeSkippedFromAst(final AstNode astNode) {
        return this.\u02e3.hasToBeSkippedFromAst(astNode);
    }
    
    @Override
    public Instruction[] compile(final CompilationHandler compilationHandler) {
        return compilationHandler.compile(new RuleRefExpression(this.\u02e1));
    }
    
    @Override
    public String toString() {
        return this.getName();
    }
    
    @Override
    public boolean shouldMemoize() {
        return true;
    }
}
