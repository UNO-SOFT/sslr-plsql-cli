// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.grammar;

import com.sonar.sslr.api.Rule;
import org.sonar.sslr.internal.vm.CompilableGrammarRule;
import org.sonar.sslr.grammar.GrammarRuleKey;
import java.util.Map;
import org.sonar.sslr.parser.LexerlessGrammar;

public class MutableGrammar extends LexerlessGrammar
{
    private final Map<GrammarRuleKey, ? extends CompilableGrammarRule> B;
    private final GrammarRuleKey A;
    
    public MutableGrammar(final Map<GrammarRuleKey, ? extends CompilableGrammarRule> b, final GrammarRuleKey a) {
        this.B = b;
        this.A = a;
    }
    
    @Override
    public Rule rule(final GrammarRuleKey grammarRuleKey) {
        return (Rule)this.B.get(grammarRuleKey);
    }
    
    @Override
    public Rule getRootRule() {
        return this.rule(this.A);
    }
}
