// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.ast.select;

import java.util.Collections;
import java.util.Iterator;
import com.sonar.sslr.api.AstNode;
import java.util.function.Predicate;
import com.sonar.sslr.api.AstNodeType;
import org.sonar.sslr.ast.AstSelect;

public class EmptyAstSelect implements AstSelect
{
    @Override
    public AstSelect children() {
        return this;
    }
    
    @Override
    public AstSelect children(final AstNodeType astNodeType) {
        return this;
    }
    
    @Override
    public AstSelect children(final AstNodeType... array) {
        return this;
    }
    
    @Override
    public AstSelect nextSibling() {
        return this;
    }
    
    @Override
    public AstSelect previousSibling() {
        return this;
    }
    
    @Override
    public AstSelect parent() {
        return this;
    }
    
    @Override
    public AstSelect firstAncestor(final AstNodeType astNodeType) {
        return this;
    }
    
    @Override
    public AstSelect firstAncestor(final AstNodeType... array) {
        return this;
    }
    
    @Override
    public AstSelect descendants(final AstNodeType astNodeType) {
        return this;
    }
    
    @Override
    public AstSelect descendants(final AstNodeType... array) {
        return this;
    }
    
    @Override
    public boolean isEmpty() {
        return true;
    }
    
    @Override
    public boolean isNotEmpty() {
        return false;
    }
    
    @Override
    public AstSelect filter(final AstNodeType astNodeType) {
        return this;
    }
    
    @Override
    public AstSelect filter(final AstNodeType... array) {
        return this;
    }
    
    @Override
    public AstSelect filter(final Predicate<AstNode> predicate) {
        return this;
    }
    
    @Override
    public int size() {
        return 0;
    }
    
    @Override
    public AstNode get(final int n) {
        throw new IndexOutOfBoundsException();
    }
    
    @Override
    public Iterator<AstNode> iterator() {
        return Collections.emptyIterator();
    }
}
