// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.ast.select;

import java.util.Collections;
import java.util.function.Predicate;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import com.sonar.sslr.api.AstNodeType;
import com.sonar.sslr.api.AstNode;
import org.sonar.sslr.ast.AstSelect;

public class SingleAstSelect implements AstSelect
{
    private final AstNode A;
    
    public SingleAstSelect(final AstNode a) {
        this.A = a;
    }
    
    @Override
    public AstSelect children() {
        if (this.A.getNumberOfChildren() == 1) {
            return new SingleAstSelect(this.A.getFirstChild());
        }
        if (this.A.getNumberOfChildren() > 1) {
            return new ListAstSelect(this.A.getChildren());
        }
        return AstSelectFactory.empty();
    }
    
    @Override
    public AstSelect children(final AstNodeType astNodeType) {
        if (this.A.getNumberOfChildren() == 1) {
            final AstNode astNode = this.A.getChildren().get(0);
            if (astNode.getType() == astNodeType) {
                return new SingleAstSelect(astNode);
            }
            return AstSelectFactory.empty();
        }
        else {
            if (this.A.getNumberOfChildren() > 1) {
                final ArrayList list = new ArrayList();
                for (final AstNode astNode2 : this.A.getChildren()) {
                    if (astNode2.getType() == astNodeType) {
                        list.add(astNode2);
                    }
                }
                return AstSelectFactory.create(list);
            }
            return AstSelectFactory.empty();
        }
    }
    
    @Override
    public AstSelect children(final AstNodeType... array) {
        if (this.A.getNumberOfChildren() == 1) {
            final AstNode astNode = this.A.getChildren().get(0);
            if (astNode.is(array)) {
                return new SingleAstSelect(astNode);
            }
            return AstSelectFactory.empty();
        }
        else {
            if (this.A.getNumberOfChildren() > 1) {
                final ArrayList list = new ArrayList();
                for (final AstNode astNode2 : this.A.getChildren()) {
                    if (astNode2.is(array)) {
                        list.add(astNode2);
                    }
                }
                return AstSelectFactory.create(list);
            }
            return AstSelectFactory.empty();
        }
    }
    
    @Override
    public AstSelect nextSibling() {
        return AstSelectFactory.select(this.A.getNextSibling());
    }
    
    @Override
    public AstSelect previousSibling() {
        return AstSelectFactory.select(this.A.getPreviousSibling());
    }
    
    @Override
    public AstSelect parent() {
        return AstSelectFactory.select(this.A.getParent());
    }
    
    @Override
    public AstSelect firstAncestor(final AstNodeType astNodeType) {
        AstNode astNode;
        for (astNode = this.A.getParent(); astNode != null && astNode.getType() != astNodeType; astNode = astNode.getParent()) {}
        return AstSelectFactory.select(astNode);
    }
    
    @Override
    public AstSelect firstAncestor(final AstNodeType... array) {
        AstNode astNode;
        for (astNode = this.A.getParent(); astNode != null && !astNode.is(array); astNode = astNode.getParent()) {}
        return AstSelectFactory.select(astNode);
    }
    
    @Override
    public AstSelect descendants(final AstNodeType astNodeType) {
        return AstSelectFactory.create(this.A.getDescendants(astNodeType));
    }
    
    @Override
    public AstSelect descendants(final AstNodeType... array) {
        return AstSelectFactory.create(this.A.getDescendants(array));
    }
    
    @Override
    public boolean isEmpty() {
        return false;
    }
    
    @Override
    public boolean isNotEmpty() {
        return true;
    }
    
    @Override
    public AstSelect filter(final AstNodeType astNodeType) {
        return (this.A.getType() == astNodeType) ? this : AstSelectFactory.empty();
    }
    
    @Override
    public AstSelect filter(final AstNodeType... array) {
        return this.A.is(array) ? this : AstSelectFactory.empty();
    }
    
    @Override
    public AstSelect filter(final Predicate<AstNode> predicate) {
        return predicate.test(this.A) ? this : AstSelectFactory.empty();
    }
    
    @Override
    public int size() {
        return 1;
    }
    
    @Override
    public AstNode get(final int n) {
        if (n == 0) {
            return this.A;
        }
        throw new IndexOutOfBoundsException();
    }
    
    @Override
    public Iterator<AstNode> iterator() {
        return Collections.singleton(this.A).iterator();
    }
}
