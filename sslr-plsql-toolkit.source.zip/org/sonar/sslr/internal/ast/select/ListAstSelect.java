// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.ast.select;

import java.util.function.Predicate;
import com.sonar.sslr.api.AstNodeType;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import com.sonar.sslr.api.AstNode;
import java.util.List;
import org.sonar.sslr.ast.AstSelect;

public class ListAstSelect implements AstSelect
{
    private final List<AstNode> B;
    
    public ListAstSelect(final List<AstNode> b) {
        this.B = b;
    }
    
    @Override
    public AstSelect children() {
        final ArrayList list = new ArrayList();
        final Iterator<AstNode> iterator = this.B.iterator();
        while (iterator.hasNext()) {
            list.addAll(iterator.next().getChildren());
        }
        return AstSelectFactory.create(list);
    }
    
    @Override
    public AstSelect children(final AstNodeType astNodeType) {
        final ArrayList list = new ArrayList();
        final Iterator<AstNode> iterator = this.B.iterator();
        while (iterator.hasNext()) {
            for (final AstNode astNode : iterator.next().getChildren()) {
                if (astNode.getType() == astNodeType) {
                    list.add(astNode);
                }
            }
        }
        return AstSelectFactory.create(list);
    }
    
    @Override
    public AstSelect children(final AstNodeType... array) {
        final ArrayList list = new ArrayList();
        final Iterator<AstNode> iterator = this.B.iterator();
        while (iterator.hasNext()) {
            for (final AstNode astNode : iterator.next().getChildren()) {
                if (astNode.is(array)) {
                    list.add(astNode);
                }
            }
        }
        return AstSelectFactory.create(list);
    }
    
    @Override
    public AstSelect nextSibling() {
        final ArrayList list = new ArrayList();
        final Iterator<AstNode> iterator = this.B.iterator();
        while (iterator.hasNext()) {
            final AstNode nextSibling = iterator.next().getNextSibling();
            if (nextSibling != null) {
                list.add(nextSibling);
            }
        }
        return AstSelectFactory.create(list);
    }
    
    @Override
    public AstSelect previousSibling() {
        final ArrayList list = new ArrayList();
        final Iterator<AstNode> iterator = this.B.iterator();
        while (iterator.hasNext()) {
            final AstNode previousSibling = iterator.next().getPreviousSibling();
            if (previousSibling != null) {
                list.add(previousSibling);
            }
        }
        return AstSelectFactory.create(list);
    }
    
    @Override
    public AstSelect parent() {
        final ArrayList list = new ArrayList();
        final Iterator<AstNode> iterator = this.B.iterator();
        while (iterator.hasNext()) {
            final AstNode parent = iterator.next().getParent();
            if (parent != null) {
                list.add(parent);
            }
        }
        return AstSelectFactory.create(list);
    }
    
    @Override
    public AstSelect firstAncestor(final AstNodeType astNodeType) {
        final ArrayList list = new ArrayList();
        final Iterator<AstNode> iterator = this.B.iterator();
        while (iterator.hasNext()) {
            AstNode astNode;
            for (astNode = iterator.next().getParent(); astNode != null && astNode.getType() != astNodeType; astNode = astNode.getParent()) {}
            if (astNode != null) {
                list.add(astNode);
            }
        }
        return AstSelectFactory.create(list);
    }
    
    @Override
    public AstSelect firstAncestor(final AstNodeType... array) {
        final ArrayList list = new ArrayList();
        final Iterator<AstNode> iterator = this.B.iterator();
        while (iterator.hasNext()) {
            AstNode astNode;
            for (astNode = iterator.next().getParent(); astNode != null && !astNode.is(array); astNode = astNode.getParent()) {}
            if (astNode != null) {
                list.add(astNode);
            }
        }
        return AstSelectFactory.create(list);
    }
    
    @Override
    public AstSelect descendants(final AstNodeType astNodeType) {
        final ArrayList list = new ArrayList();
        final Iterator<AstNode> iterator = this.B.iterator();
        while (iterator.hasNext()) {
            list.addAll(iterator.next().getDescendants(astNodeType));
        }
        return AstSelectFactory.create(list);
    }
    
    @Override
    public AstSelect descendants(final AstNodeType... array) {
        final ArrayList list = new ArrayList();
        final Iterator<AstNode> iterator = this.B.iterator();
        while (iterator.hasNext()) {
            list.addAll(iterator.next().getDescendants(array));
        }
        return AstSelectFactory.create(list);
    }
    
    @Override
    public boolean isEmpty() {
        return false;
    }
    
    @Override
    public boolean isNotEmpty() {
        return true;
    }
    
    @Override
    public AstSelect filter(final AstNodeType astNodeType) {
        final ArrayList list = new ArrayList();
        for (final AstNode astNode : this.B) {
            if (astNode.getType() == astNodeType) {
                list.add(astNode);
            }
        }
        return AstSelectFactory.create(list);
    }
    
    @Override
    public AstSelect filter(final AstNodeType... array) {
        final ArrayList list = new ArrayList();
        for (final AstNode astNode : this.B) {
            if (astNode.is(array)) {
                list.add(astNode);
            }
        }
        return AstSelectFactory.create(list);
    }
    
    @Override
    public AstSelect filter(final Predicate<AstNode> predicate) {
        final ArrayList list = new ArrayList();
        for (final AstNode astNode : this.B) {
            if (predicate.test(astNode)) {
                list.add(astNode);
            }
        }
        return AstSelectFactory.create(list);
    }
    
    @Override
    public int size() {
        return this.B.size();
    }
    
    @Override
    public AstNode get(final int n) {
        return this.B.get(n);
    }
    
    @Override
    public Iterator<AstNode> iterator() {
        return this.B.iterator();
    }
}
