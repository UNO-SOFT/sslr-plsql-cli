// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.ast.select;

import java.util.List;
import javax.annotation.Nullable;
import com.sonar.sslr.api.AstNode;
import org.sonar.sslr.ast.AstSelect;

public final class AstSelectFactory
{
    private static final AstSelect A;
    
    private AstSelectFactory() {
    }
    
    public static AstSelect select(@Nullable final AstNode astNode) {
        return (astNode == null) ? AstSelectFactory.A : new SingleAstSelect(astNode);
    }
    
    public static AstSelect create(final List<AstNode> list) {
        if (list.size() == 1) {
            return new SingleAstSelect(list.get(0));
        }
        if (!list.isEmpty()) {
            return new ListAstSelect(list);
        }
        return AstSelectFactory.A;
    }
    
    public static AstSelect empty() {
        return AstSelectFactory.A;
    }
    
    static {
        A = new EmptyAstSelect();
    }
}
