// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.matchers;

import java.util.ArrayList;
import java.util.Arrays;
import javax.annotation.Nullable;
import java.net.URI;
import java.io.File;

public class LocatedText implements CharSequence
{
    private static final int[] C;
    private final File B;
    private final URI E;
    private final char[] D;
    private final int[] A;
    
    public LocatedText(@Nullable final File b, final char[] d) {
        this.B = b;
        this.E = ((b == null) ? null : b.toURI());
        this.D = d;
        this.A = A(d);
    }
    
    @Override
    public int length() {
        return this.D.length;
    }
    
    public char[] toChars() {
        final char[] array = new char[this.length()];
        System.arraycopy(this.D, 0, array, 0, array.length);
        return array;
    }
    
    @Override
    public char charAt(final int n) {
        return this.D[n];
    }
    
    @Override
    public CharSequence subSequence(final int n, final int n2) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public String toString() {
        return new String(this.toChars());
    }
    
    A B(final int n) {
        if (n < 0 || n > this.length()) {
            throw new IndexOutOfBoundsException();
        }
        final int a = this.A(n);
        return new A(this.B, this.E, a, n - this.C(a) + 1);
    }
    
    private int A(final int key) {
        final int binarySearch = Arrays.binarySearch(this.A, key);
        return (binarySearch >= 0) ? (binarySearch + 2) : (-binarySearch);
    }
    
    private int C(final int n) {
        return (n == 1) ? 0 : this.A[n - 2];
    }
    
    private static int[] A(final char[] array) {
        final ArrayList list = new ArrayList();
        for (int i = 0; i < array.length; ++i) {
            if (A(array, i)) {
                list.add(i + 1);
            }
        }
        if (list.isEmpty()) {
            return LocatedText.C;
        }
        final int[] array2 = new int[list.size()];
        for (int j = 0; j < list.size(); ++j) {
            array2[j] = (int)list.get(j);
        }
        return array2;
    }
    
    private static boolean A(final char[] array, final int n) {
        return array[n] == '\n' || (array[n] == '\r' && ((n + 1 < array.length && array[n + 1] != '\n') || n + 1 == array.length));
    }
    
    static {
        C = new int[0];
    }
}
