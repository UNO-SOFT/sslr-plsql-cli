// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.matchers;

import java.util.Arrays;
import java.util.ArrayList;

public class ImmutableInputBuffer implements InputBuffer
{
    private final char[] B;
    private final int[] A;
    
    public ImmutableInputBuffer(final char[] b) {
        this.B = b;
        final ArrayList list = new ArrayList();
        int i = 0;
        list.add(0);
        while (i < b.length) {
            if (A(b, i)) {
                list.add(i + 1);
            }
            ++i;
        }
        list.add(i);
        this.A = new int[list.size()];
        for (int j = 0; j < list.size(); ++j) {
            this.A[j] = (int)list.get(j);
        }
    }
    
    @Override
    public int length() {
        return this.B.length;
    }
    
    @Override
    public char charAt(final int n) {
        return this.B[n];
    }
    
    private static boolean A(final char[] array, final int n) {
        return array[n] == '\n' || (array[n] == '\r' && ((n + 1 < array.length && array[n + 1] != '\n') || n + 1 == array.length));
    }
    
    @Override
    public String extractLine(final int n) {
        final int offset = this.A[n - 1];
        return new String(this.B, offset, this.A[n] - offset);
    }
    
    @Override
    public int getLineCount() {
        return this.A.length - 1;
    }
    
    private int A(final int key) {
        final int binarySearch = Arrays.binarySearch(this.A, key);
        return Math.min((binarySearch >= 0) ? (binarySearch + 1) : (-(binarySearch + 1)), this.getLineCount());
    }
    
    @Override
    public Position getPosition(final int n) {
        final int a = this.A(n);
        return new Position(a, n - this.A[a - 1] + 1);
    }
}
