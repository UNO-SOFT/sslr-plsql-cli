// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.matchers;

public final class TextUtils
{
    public static final char CR = '\r';
    public static final char LF = '\n';
    private static final char[] B;
    private static final String[] A;
    
    private TextUtils() {
    }
    
    public static String escape(final char c) {
        for (int i = 0; i < TextUtils.B.length; ++i) {
            if (TextUtils.B[i] == c) {
                return TextUtils.A[i];
            }
        }
        return String.valueOf(c);
    }
    
    public static String trimTrailingLineSeparatorFrom(final String s) {
        int n;
        for (n = s.length() - 1; n >= 0 && (s.charAt(n) == '\n' || s.charAt(n) == '\r'); --n) {}
        return s.substring(0, n + 1);
    }
    
    static {
        B = new char[] { '\r', '\n', '\f', '\t', '\"' };
        A = new String[] { "\\r", "\\n", "\\f", "\\t", "\\\"" };
    }
}
