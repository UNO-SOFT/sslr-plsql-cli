// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.matchers;

import java.util.Objects;

public class MatcherPathElement
{
    private final Matcher B;
    private final int C;
    private final int A;
    
    public MatcherPathElement(final Matcher b, final int c, final int a) {
        this.B = b;
        this.C = c;
        this.A = a;
    }
    
    public Matcher getMatcher() {
        return this.B;
    }
    
    public int getStartIndex() {
        return this.C;
    }
    
    public int getEndIndex() {
        return this.A;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.B, this.C, this.A);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof MatcherPathElement) {
            final MatcherPathElement matcherPathElement = (MatcherPathElement)o;
            return this.B.equals(matcherPathElement.B) && this.C == matcherPathElement.C && this.A == matcherPathElement.A;
        }
        return false;
    }
}
