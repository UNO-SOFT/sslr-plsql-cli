// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.matchers;

import org.sonar.sslr.internal.vm.lexerful.TokenTypeExpression;
import java.util.Iterator;
import com.sonar.sslr.api.AstNodeType;
import java.util.Collection;
import java.util.ArrayList;
import com.sonar.sslr.impl.matcher.RuleDefinition;
import com.sonar.sslr.api.AstNode;
import com.sonar.sslr.api.Token;
import java.util.List;

public class LexerfulAstCreator
{
    private final List<Token> A;
    
    public static AstNode create(final ParseNode parseNode, final List<Token> list) {
        final AstNode b = new LexerfulAstCreator(list).B(parseNode);
        b.hasToBeSkippedFromAst();
        return b;
    }
    
    private LexerfulAstCreator(final List<Token> a) {
        this.A = a;
    }
    
    private AstNode B(final ParseNode parseNode) {
        if (parseNode.getMatcher() instanceof RuleDefinition) {
            return this.A(parseNode);
        }
        return this.C(parseNode);
    }
    
    private AstNode A(final ParseNode parseNode) {
        final ArrayList list = new ArrayList();
        final Iterator<ParseNode> iterator = parseNode.getChildren().iterator();
        while (iterator.hasNext()) {
            final AstNode b = this.B(iterator.next());
            if (b == null) {
                continue;
            }
            if (b.hasToBeSkippedFromAst()) {
                list.addAll(b.getChildren());
            }
            else {
                list.add(b);
            }
        }
        final RuleDefinition ruleDefinition = (RuleDefinition)parseNode.getMatcher();
        final AstNode astNode = new AstNode(ruleDefinition, ruleDefinition.getName(), (parseNode.getStartIndex() < this.A.size()) ? this.A.get(parseNode.getStartIndex()) : null);
        final Iterator iterator2 = list.iterator();
        while (iterator2.hasNext()) {
            astNode.addChild((AstNode)iterator2.next());
        }
        astNode.setFromIndex(parseNode.getStartIndex());
        astNode.setToIndex(parseNode.getEndIndex());
        return astNode;
    }
    
    private AstNode C(final ParseNode parseNode) {
        final Token token = this.A.get(parseNode.getStartIndex());
        if (parseNode.getMatcher() instanceof TokenTypeExpression && token.getType().hasToBeSkippedFromAst(null)) {
            return null;
        }
        final AstNode astNode = new AstNode(token);
        astNode.setFromIndex(parseNode.getStartIndex());
        astNode.setToIndex(parseNode.getEndIndex());
        return astNode;
    }
}
