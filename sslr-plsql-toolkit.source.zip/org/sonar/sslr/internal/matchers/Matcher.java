// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.matchers;

public interface Matcher
{
}
