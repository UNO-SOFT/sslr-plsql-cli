// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.matchers;

import java.util.Objects;
import javax.annotation.Nullable;
import java.net.URI;
import java.io.File;

class A
{
    private final File B;
    private final URI D;
    private final int A;
    private final int C;
    
    public A(@Nullable final File b, @Nullable final URI d, final int a, final int c) {
        this.B = b;
        this.D = d;
        this.A = a;
        this.C = c;
    }
    
    public File B() {
        return this.B;
    }
    
    public URI C() {
        return this.D;
    }
    
    public int A() {
        return this.A;
    }
    
    public int D() {
        return this.C;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.B, this.A, this.C);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof A) {
            final A a = (A)o;
            return Objects.equals(this.B, a.B) && this.A == a.A && this.C == a.C;
        }
        return false;
    }
    
    @Override
    public String toString() {
        return "TextLocation{file=" + this.B + ", line=" + this.A + ", column=" + this.C + '}';
    }
}
