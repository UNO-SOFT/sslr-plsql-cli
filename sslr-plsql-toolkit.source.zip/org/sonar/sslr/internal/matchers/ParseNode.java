// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.matchers;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;

public class ParseNode
{
    private final int D;
    private final int B;
    private final List<ParseNode> A;
    private final Matcher C;
    
    public ParseNode(final int d, final int b, final List<ParseNode> c, final Matcher c2) {
        this.D = d;
        this.B = b;
        this.A = new ArrayList<ParseNode>(c);
        this.C = c2;
    }
    
    public ParseNode(final int d, final int b, final Matcher c) {
        this.D = d;
        this.B = b;
        this.C = c;
        this.A = Collections.emptyList();
    }
    
    public int getStartIndex() {
        return this.D;
    }
    
    public int getEndIndex() {
        return this.B;
    }
    
    public List<ParseNode> getChildren() {
        return this.A;
    }
    
    public Matcher getMatcher() {
        return this.C;
    }
}
