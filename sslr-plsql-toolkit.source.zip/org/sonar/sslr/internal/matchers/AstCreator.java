// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.matchers;

import java.net.URISyntaxException;
import java.util.Iterator;
import com.sonar.sslr.api.AstNodeType;
import java.util.Collection;
import java.util.Collections;
import com.sonar.sslr.api.GenericTokenType;
import org.sonar.sslr.internal.vm.TokenExpression;
import org.sonar.sslr.internal.vm.TriviaExpression;
import org.sonar.sslr.internal.grammar.MutableParsingRule;
import java.util.ArrayList;
import com.sonar.sslr.api.AstNode;
import org.sonar.sslr.parser.ParsingResult;
import com.sonar.sslr.api.TokenType;
import com.sonar.sslr.api.Trivia;
import java.util.List;
import com.sonar.sslr.api.Token;
import java.net.URI;

public final class AstCreator
{
    private static final URI C;
    private final LocatedText A;
    private final Token.Builder E;
    private final List<Trivia> D;
    static final TokenType B;
    
    public static AstNode create(final ParsingResult parsingResult, final LocatedText locatedText) {
        final AstNode d = new AstCreator(locatedText).D(parsingResult.getParseTreeRoot());
        d.hasToBeSkippedFromAst();
        return d;
    }
    
    private AstCreator(final LocatedText a) {
        this.E = Token.builder();
        this.D = new ArrayList<Trivia>();
        this.A = a;
    }
    
    private AstNode D(final ParseNode parseNode) {
        if (parseNode.getMatcher() instanceof MutableParsingRule) {
            return this.C(parseNode);
        }
        return this.E(parseNode);
    }
    
    private AstNode E(final ParseNode parseNode) {
        if (!(parseNode.getMatcher() instanceof TriviaExpression)) {
            if (parseNode.getMatcher() instanceof TokenExpression) {
                this.B(parseNode);
                final TokenExpression tokenExpression = (TokenExpression)parseNode.getMatcher();
                this.E.setType(tokenExpression.getTokenType());
                if (tokenExpression.getTokenType() == GenericTokenType.COMMENT) {
                    this.E.setTrivia(Collections.emptyList());
                    this.D.add(Trivia.createComment(this.E.build()));
                    return null;
                }
            }
            else {
                this.B(parseNode);
                this.E.setType(AstCreator.B);
            }
            final Token build = this.E.setTrivia(this.D).build();
            this.D.clear();
            final AstNode astNode = new AstNode(build);
            astNode.setFromIndex(parseNode.getStartIndex());
            astNode.setToIndex(parseNode.getEndIndex());
            return astNode;
        }
        final TriviaExpression triviaExpression = (TriviaExpression)parseNode.getMatcher();
        if (triviaExpression.getTriviaKind() == Trivia.TriviaKind.SKIPPED_TEXT) {
            return null;
        }
        if (triviaExpression.getTriviaKind() == Trivia.TriviaKind.COMMENT) {
            this.B(parseNode);
            this.E.setTrivia(Collections.emptyList());
            this.E.setType(GenericTokenType.COMMENT);
            this.D.add(Trivia.createComment(this.E.build()));
            return null;
        }
        throw new IllegalStateException("Unexpected trivia kind: " + triviaExpression.getTriviaKind());
    }
    
    private void B(final ParseNode parseNode) {
        final A b = this.A.B(parseNode.getStartIndex());
        if (b == null) {
            this.E.setGeneratedCode(true);
            this.E.setLine(1);
            this.E.setColumn(0);
            this.E.setURI(AstCreator.C);
        }
        else {
            this.E.setGeneratedCode(false);
            this.E.setLine(b.A());
            this.E.setColumn(b.D() - 1);
            this.E.setURI((b.C() == null) ? AstCreator.C : b.C());
            this.E.notCopyBook();
        }
        this.E.setValueAndOriginalValue(this.A(parseNode));
    }
    
    private AstNode C(final ParseNode parseNode) {
        final MutableParsingRule mutableParsingRule = (MutableParsingRule)parseNode.getMatcher();
        final ArrayList list = new ArrayList();
        final Iterator<ParseNode> iterator = parseNode.getChildren().iterator();
        while (iterator.hasNext()) {
            final AstNode d = this.D(iterator.next());
            if (d != null) {
                if (d.hasToBeSkippedFromAst()) {
                    list.addAll(d.getChildren());
                }
                else {
                    list.add(d);
                }
            }
        }
        Token token = null;
        for (final AstNode astNode : list) {
            if (astNode.getToken() != null) {
                token = astNode.getToken();
                break;
            }
        }
        final AstNode astNode2 = new AstNode(mutableParsingRule, mutableParsingRule.getName(), token);
        final Iterator iterator3 = list.iterator();
        while (iterator3.hasNext()) {
            astNode2.addChild((AstNode)iterator3.next());
        }
        astNode2.setFromIndex(parseNode.getStartIndex());
        astNode2.setToIndex(parseNode.getEndIndex());
        return astNode2;
    }
    
    private String A(final ParseNode parseNode) {
        final StringBuilder sb = new StringBuilder();
        for (int i = parseNode.getStartIndex(); i < Math.min(parseNode.getEndIndex(), this.A.length()); ++i) {
            sb.append(this.A.charAt(i));
        }
        return sb.toString();
    }
    
    static {
        try {
            C = new URI("tests://unittest");
        }
        catch (final URISyntaxException cause) {
            throw new IllegalStateException(cause);
        }
        B = new TokenType() {
            @Override
            public String getName() {
                return "TOKEN";
            }
            
            @Override
            public String getValue() {
                return this.getName();
            }
            
            @Override
            public boolean hasToBeSkippedFromAst(final AstNode astNode) {
                return false;
            }
        };
    }
}
