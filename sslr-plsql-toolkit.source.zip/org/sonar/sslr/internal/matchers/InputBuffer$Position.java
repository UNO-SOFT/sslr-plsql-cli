// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.matchers;

public static class Position
{
    private final int A;
    private final int B;
    
    public Position(final int a, final int b) {
        this.A = a;
        this.B = b;
    }
    
    public int getLine() {
        return this.A;
    }
    
    public int getColumn() {
        return this.B;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Position)) {
            return false;
        }
        final Position position = (Position)o;
        return this.A == position.A && this.B == position.B;
    }
    
    @Override
    public int hashCode() {
        return 31 * this.A + this.B;
    }
    
    @Override
    public String toString() {
        return "(" + this.A + ", " + this.B + ")";
    }
}
