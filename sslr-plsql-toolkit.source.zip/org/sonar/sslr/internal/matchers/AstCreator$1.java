// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.matchers;

import com.sonar.sslr.api.AstNode;
import com.sonar.sslr.api.TokenType;

class AstCreator$1 implements TokenType {
    @Override
    public String getName() {
        return "TOKEN";
    }
    
    @Override
    public String getValue() {
        return this.getName();
    }
    
    @Override
    public boolean hasToBeSkippedFromAst(final AstNode astNode) {
        return false;
    }
}