// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.matchers;

import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
interface package-info
{
}
