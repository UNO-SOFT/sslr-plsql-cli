// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public class NextExpression implements ParsingExpression
{
    private final ParsingExpression K;
    
    public NextExpression(final ParsingExpression k) {
        this.K = k;
    }
    
    @Override
    public Instruction[] compile(final CompilationHandler compilationHandler) {
        final Instruction[] compile = compilationHandler.compile(this.K);
        final Instruction[] array = new Instruction[compile.length + 3];
        array[0] = Instruction.choice(array.length - 1);
        System.arraycopy(compile, 0, array, 1, compile.length);
        array[compile.length + 1] = Instruction.backCommit(2);
        array[compile.length + 2] = Instruction.backtrack();
        return array;
    }
    
    @Override
    public String toString() {
        return "Next[" + this.K + "]";
    }
}
