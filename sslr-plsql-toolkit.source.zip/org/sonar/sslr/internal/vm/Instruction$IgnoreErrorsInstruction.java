// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public static final class IgnoreErrorsInstruction extends Instruction
{
    @Override
    public void execute(final Machine machine) {
        machine.setIgnoreErrors(true);
        machine.jump(1);
    }
    
    @Override
    public String toString() {
        return "IgnoreErrors";
    }
}
