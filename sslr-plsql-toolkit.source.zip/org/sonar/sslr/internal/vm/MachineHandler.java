// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public interface MachineHandler
{
    void onBacktrack(final Machine p0);
}
