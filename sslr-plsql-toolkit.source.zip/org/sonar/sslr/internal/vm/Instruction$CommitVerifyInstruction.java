// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import org.sonar.sslr.internal.matchers.ParseNode;
import java.util.Collection;
import org.sonar.sslr.grammar.GrammarException;

public static final class CommitVerifyInstruction extends Instruction
{
    private final int \u0390;
    
    public CommitVerifyInstruction(final int \u0390) {
        this.\u0390 = \u0390;
    }
    
    @Override
    public void execute(final Machine machine) {
        if (machine.getIndex() == machine.peek().index()) {
            throw new GrammarException("The inner part of ZeroOrMore and OneOrMore must not allow empty matches");
        }
        machine.peek().parent().subNodes().addAll(machine.peek().subNodes());
        machine.pop();
        machine.jump(this.\u0390);
    }
    
    @Override
    public String toString() {
        return "CommitVerify " + this.\u0390;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof CommitVerifyInstruction && this.\u0390 == ((CommitVerifyInstruction)o).\u0390;
    }
    
    @Override
    public int hashCode() {
        return this.\u0390;
    }
}
