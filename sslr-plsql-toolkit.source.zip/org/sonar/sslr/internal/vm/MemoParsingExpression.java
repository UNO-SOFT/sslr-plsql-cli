// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import org.sonar.sslr.internal.matchers.Matcher;

public interface MemoParsingExpression extends ParsingExpression, Matcher
{
    boolean shouldMemoize();
}
