// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import java.util.Objects;
import org.sonar.sslr.internal.matchers.Matcher;

public static final class CallInstruction extends Instruction
{
    private final int \u0393;
    private final Matcher \u0392;
    
    public CallInstruction(final int \u03b3, final Matcher \u03b2) {
        this.\u0393 = \u03b3;
        this.\u0392 = \u03b2;
    }
    
    @Override
    public void execute(final Machine machine) {
        machine.pushReturn(1, this.\u0392, this.\u0393);
    }
    
    @Override
    public String toString() {
        return "Call " + this.\u0393;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o instanceof CallInstruction) {
            final CallInstruction callInstruction = (CallInstruction)o;
            return this.\u0393 == callInstruction.\u0393 && Objects.equals(this.\u0392, callInstruction.\u0392);
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return this.\u0393;
    }
}
