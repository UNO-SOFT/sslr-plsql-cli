// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public class NothingExpression extends NativeExpression
{
    public static final NothingExpression INSTANCE;
    
    private NothingExpression() {
    }
    
    @Override
    public void execute(final Machine machine) {
        machine.backtrack();
    }
    
    @Override
    public String toString() {
        return "Nothing";
    }
    
    static {
        INSTANCE = new NothingExpression();
    }
}
