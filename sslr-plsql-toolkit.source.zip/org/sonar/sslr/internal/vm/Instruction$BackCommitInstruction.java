// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public static final class BackCommitInstruction extends Instruction
{
    private final int \u0394;
    
    public BackCommitInstruction(final int \u03b4) {
        this.\u0394 = \u03b4;
    }
    
    @Override
    public void execute(final Machine machine) {
        final MachineStack peek = machine.peek();
        machine.setIndex(peek.index());
        machine.setIgnoreErrors(peek.isIgnoreErrors());
        machine.pop();
        machine.jump(this.\u0394);
    }
    
    @Override
    public String toString() {
        return "BackCommit " + this.\u0394;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof BackCommitInstruction && this.\u0394 == ((BackCommitInstruction)o).\u0394;
    }
    
    @Override
    public int hashCode() {
        return this.\u0394;
    }
}
