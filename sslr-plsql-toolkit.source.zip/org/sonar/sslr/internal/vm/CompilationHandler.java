// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public class CompilationHandler
{
    public Instruction[] compile(final ParsingExpression parsingExpression) {
        return parsingExpression.compile(this);
    }
}
