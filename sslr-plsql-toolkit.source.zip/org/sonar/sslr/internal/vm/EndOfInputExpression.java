// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public class EndOfInputExpression extends NativeExpression
{
    public static final EndOfInputExpression INSTANCE;
    
    private EndOfInputExpression() {
    }
    
    @Override
    public void execute(final Machine machine) {
        if (machine.length() == 0) {
            machine.jump(1);
        }
        else {
            machine.backtrack();
        }
    }
    
    @Override
    public String toString() {
        return "EndOfInput";
    }
    
    static {
        INSTANCE = new EndOfInputExpression();
    }
}
