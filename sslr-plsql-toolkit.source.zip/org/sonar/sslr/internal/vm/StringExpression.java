// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import org.sonar.sslr.internal.matchers.Matcher;

public class StringExpression extends NativeExpression implements Matcher
{
    private final String \u03a0;
    
    public StringExpression(final String \u03c0) {
        this.\u03a0 = \u03c0;
    }
    
    @Override
    public void execute(final Machine machine) {
        if (machine.length() < this.\u03a0.length()) {
            machine.backtrack();
            return;
        }
        for (int i = 0; i < this.\u03a0.length(); ++i) {
            if (machine.charAt(i) != this.\u03a0.charAt(i)) {
                machine.backtrack();
                return;
            }
        }
        machine.createLeafNode(this, this.\u03a0.length());
        machine.jump(1);
    }
    
    @Override
    public String toString() {
        return "String " + this.\u03a0;
    }
}
