// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import org.sonar.sslr.internal.matchers.ParseNode;
import java.util.Collection;

public static final class CommitInstruction extends Instruction
{
    private final int \u0397;
    
    public CommitInstruction(final int \u03b7) {
        this.\u0397 = \u03b7;
    }
    
    @Override
    public void execute(final Machine machine) {
        machine.peek().parent().subNodes().addAll(machine.peek().subNodes());
        machine.pop();
        machine.jump(this.\u0397);
    }
    
    @Override
    public String toString() {
        return "Commit " + this.\u0397;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof CommitInstruction && this.\u0397 == ((CommitInstruction)o).\u0397;
    }
    
    @Override
    public int hashCode() {
        return this.\u0397;
    }
}
