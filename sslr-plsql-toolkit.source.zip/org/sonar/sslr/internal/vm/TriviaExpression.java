// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import com.sonar.sslr.api.Trivia;
import org.sonar.sslr.internal.matchers.Matcher;

public class TriviaExpression implements Matcher, ParsingExpression
{
    private final Trivia.TriviaKind J;
    private final ParsingExpression I;
    
    public TriviaExpression(final Trivia.TriviaKind j, final ParsingExpression i) {
        this.J = j;
        this.I = i;
    }
    
    public Trivia.TriviaKind getTriviaKind() {
        return this.J;
    }
    
    @Override
    public Instruction[] compile(final CompilationHandler compilationHandler) {
        return TokenExpression.A(compilationHandler, this, this.I);
    }
    
    @Override
    public String toString() {
        return "Trivia " + this.J + "[" + this.I + "]";
    }
}
