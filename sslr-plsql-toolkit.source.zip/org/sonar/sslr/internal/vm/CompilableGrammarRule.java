// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import org.sonar.sslr.grammar.GrammarRuleKey;
import com.sonar.sslr.api.Rule;
import org.sonar.sslr.internal.matchers.Matcher;

public interface CompilableGrammarRule extends Matcher, Rule, ParsingExpression
{
    GrammarRuleKey getRuleKey();
    
    void setExpression(final ParsingExpression p0);
    
    ParsingExpression getExpression();
}
