// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public static final class JumpInstruction extends Instruction
{
    private final int \u0395;
    
    public JumpInstruction(final int \u03b5) {
        this.\u0395 = \u03b5;
    }
    
    @Override
    public void execute(final Machine machine) {
        machine.jump(this.\u0395);
    }
    
    @Override
    public String toString() {
        return "Jump " + this.\u0395;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof JumpInstruction && this.\u0395 == ((JumpInstruction)o).\u0395;
    }
    
    @Override
    public int hashCode() {
        return this.\u0395;
    }
}
