// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public class ZeroOrMoreExpression implements ParsingExpression
{
    private final ParsingExpression \u0388;
    
    public ZeroOrMoreExpression(final ParsingExpression \u03ad) {
        this.\u0388 = \u03ad;
    }
    
    @Override
    public Instruction[] compile(final CompilationHandler compilationHandler) {
        final Instruction[] compile = compilationHandler.compile(this.\u0388);
        final Instruction[] array = new Instruction[compile.length + 2];
        array[0] = Instruction.choice(compile.length + 2);
        System.arraycopy(compile, 0, array, 1, compile.length);
        array[compile.length + 1] = Instruction.commitVerify(-1 - compile.length);
        return array;
    }
    
    @Override
    public String toString() {
        return "ZeroOrMore[" + this.\u0388 + "]";
    }
}
