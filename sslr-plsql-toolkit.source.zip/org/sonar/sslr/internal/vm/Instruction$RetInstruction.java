// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public static final class RetInstruction extends Instruction
{
    @Override
    public void execute(final Machine machine) {
        machine.createNode();
        final MachineStack peek = machine.peek();
        machine.setIgnoreErrors(peek.isIgnoreErrors());
        machine.setAddress(peek.address());
        machine.popReturn();
    }
    
    @Override
    public String toString() {
        return "Ret";
    }
}
