// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public class OptionalExpression implements ParsingExpression
{
    private final ParsingExpression H;
    
    public OptionalExpression(final ParsingExpression h) {
        this.H = h;
    }
    
    @Override
    public Instruction[] compile(final CompilationHandler compilationHandler) {
        final Instruction[] compile = compilationHandler.compile(this.H);
        final Instruction[] array = new Instruction[compile.length + 2];
        array[0] = Instruction.choice(array.length);
        System.arraycopy(compile, 0, array, 1, compile.length);
        array[compile.length + 1] = Instruction.commit(1);
        return array;
    }
    
    @Override
    public String toString() {
        return "Optional[" + this.H + "]";
    }
}
