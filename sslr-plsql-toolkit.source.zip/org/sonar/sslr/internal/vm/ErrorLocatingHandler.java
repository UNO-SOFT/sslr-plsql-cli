// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public class ErrorLocatingHandler implements MachineHandler
{
    private int A;
    
    public ErrorLocatingHandler() {
        this.A = -1;
    }
    
    @Override
    public void onBacktrack(final Machine machine) {
        if (this.A < machine.getIndex()) {
            this.A = machine.getIndex();
        }
    }
    
    public int getErrorIndex() {
        return this.A;
    }
}
