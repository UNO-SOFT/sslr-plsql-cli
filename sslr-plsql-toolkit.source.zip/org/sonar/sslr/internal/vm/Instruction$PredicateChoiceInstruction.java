// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public static final class PredicateChoiceInstruction extends Instruction
{
    private final int \u0396;
    
    public PredicateChoiceInstruction(final int \u03b6) {
        this.\u0396 = \u03b6;
    }
    
    @Override
    public void execute(final Machine machine) {
        machine.pushBacktrack(this.\u0396);
        machine.setIgnoreErrors(true);
        machine.jump(1);
    }
    
    @Override
    public String toString() {
        return "PredicateChoice " + this.\u0396;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof PredicateChoiceInstruction && this.\u0396 == ((PredicateChoiceInstruction)o).\u0396;
    }
    
    @Override
    public int hashCode() {
        return this.\u0396;
    }
}
