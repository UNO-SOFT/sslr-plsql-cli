// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import org.sonar.sslr.internal.matchers.MatcherPathElement;

public class ErrorTreeNode
{
    public MatcherPathElement pathElement;
    public List<ErrorTreeNode> children;
    
    public ErrorTreeNode() {
        this.children = new ArrayList<ErrorTreeNode>();
    }
    
    public static ErrorTreeNode buildTree(final List<List<MatcherPathElement>> list) {
        final ErrorTreeNode errorTreeNode = new ErrorTreeNode();
        errorTreeNode.pathElement = list.get(0).get(0);
        final Iterator<List<MatcherPathElement>> iterator = list.iterator();
        while (iterator.hasNext()) {
            A(errorTreeNode, iterator.next());
        }
        return errorTreeNode;
    }
    
    private static void A(final ErrorTreeNode errorTreeNode, final List<MatcherPathElement> list) {
        ErrorTreeNode errorTreeNode2 = errorTreeNode;
        int i = 1;
        for (int n = 1; n != 0 && i < list.size(); ++i, n = 1) {
            n = 0;
            for (final ErrorTreeNode errorTreeNode3 : errorTreeNode2.children) {
                if (errorTreeNode3.pathElement.equals(list.get(i))) {
                    errorTreeNode2 = errorTreeNode3;
                    break;
                }
            }
        }
        while (i < list.size()) {
            final ErrorTreeNode errorTreeNode4 = new ErrorTreeNode();
            errorTreeNode4.pathElement = list.get(i);
            errorTreeNode2.children.add(errorTreeNode4);
            errorTreeNode2 = errorTreeNode4;
            ++i;
        }
    }
}
