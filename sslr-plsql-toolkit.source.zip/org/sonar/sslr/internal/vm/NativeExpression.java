// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public abstract class NativeExpression extends Instruction implements ParsingExpression
{
    @Override
    public final Instruction[] compile(final CompilationHandler compilationHandler) {
        return new Instruction[] { this };
    }
}
