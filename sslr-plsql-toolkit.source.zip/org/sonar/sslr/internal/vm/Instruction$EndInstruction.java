// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public static final class EndInstruction extends Instruction
{
    @Override
    public void execute(final Machine machine) {
        machine.setAddress(-1);
    }
    
    @Override
    public String toString() {
        return "End";
    }
}
