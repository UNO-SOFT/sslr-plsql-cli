// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import org.sonar.sslr.internal.matchers.Matcher;
import org.sonar.sslr.internal.matchers.ParseNode;
import java.util.List;

public class MachineStack
{
    private final MachineStack F;
    private MachineStack A;
    private final List<ParseNode> H;
    private int G;
    private int E;
    private boolean B;
    private Matcher C;
    private int D;
    private int I;
    
    public MachineStack() {
        this.F = null;
        this.H = Collections.emptyList();
        this.E = -1;
    }
    
    private MachineStack(final MachineStack f) {
        this.F = f;
        this.H = new ArrayList<ParseNode>();
    }
    
    public MachineStack parent() {
        return this.F;
    }
    
    public MachineStack getOrCreateChild() {
        if (this.A == null) {
            this.A = new MachineStack(this);
        }
        return this.A;
    }
    
    public boolean isReturn() {
        return this.C != null;
    }
    
    public boolean isEmpty() {
        return this.E == -1;
    }
    
    public int address() {
        return this.G;
    }
    
    public void setAddress(final int g) {
        this.G = g;
    }
    
    public int index() {
        return this.E;
    }
    
    public void setIndex(final int e) {
        this.E = e;
    }
    
    public boolean isIgnoreErrors() {
        return this.B;
    }
    
    public void setIgnoreErrors(final boolean b) {
        this.B = b;
    }
    
    public Matcher matcher() {
        return this.C;
    }
    
    public void setMatcher(@Nullable final Matcher c) {
        this.C = c;
    }
    
    public int leftRecursion() {
        return this.D;
    }
    
    public void setLeftRecursion(final int d) {
        this.D = d;
    }
    
    public int calledAddress() {
        return this.I;
    }
    
    public void setCalledAddress(final int i) {
        this.I = i;
    }
    
    public List<ParseNode> subNodes() {
        return this.H;
    }
}
