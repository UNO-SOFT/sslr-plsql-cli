// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import org.sonar.sslr.grammar.GrammarRuleKey;

public class RuleRefExpression extends NativeExpression
{
    private final GrammarRuleKey \u039e;
    
    public RuleRefExpression(final GrammarRuleKey \u03be) {
        this.\u039e = \u03be;
    }
    
    public GrammarRuleKey getRuleKey() {
        return this.\u039e;
    }
    
    @Override
    public void execute(final Machine machine) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public String toString() {
        return "Ref " + this.\u039e;
    }
}
