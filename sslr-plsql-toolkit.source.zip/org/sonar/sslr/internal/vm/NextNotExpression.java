// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public class NextNotExpression implements ParsingExpression
{
    private final ParsingExpression L;
    
    public NextNotExpression(final ParsingExpression l) {
        this.L = l;
    }
    
    @Override
    public Instruction[] compile(final CompilationHandler compilationHandler) {
        final Instruction[] compile = compilationHandler.compile(this.L);
        final Instruction[] array = new Instruction[compile.length + 2];
        array[0] = Instruction.predicateChoice(compile.length + 2);
        System.arraycopy(compile, 0, array, 1, compile.length);
        array[compile.length + 1] = Instruction.failTwice();
        return array;
    }
    
    @Override
    public String toString() {
        return "NextNot[" + this.L + "]";
    }
}
