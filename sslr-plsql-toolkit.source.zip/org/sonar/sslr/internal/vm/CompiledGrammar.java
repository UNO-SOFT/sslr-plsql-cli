// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import org.sonar.sslr.internal.matchers.Matcher;
import org.sonar.sslr.grammar.GrammarRuleKey;
import java.util.Map;

public class CompiledGrammar
{
    private final Map<GrammarRuleKey, CompilableGrammarRule> D;
    private final Instruction[] A;
    private final GrammarRuleKey C;
    private final int B;
    
    public CompiledGrammar(final Instruction[] a, final Map<GrammarRuleKey, CompilableGrammarRule> d, final GrammarRuleKey c, final int b) {
        this.A = a;
        this.D = d;
        this.C = c;
        this.B = b;
    }
    
    public Instruction[] getInstructions() {
        return this.A;
    }
    
    public Matcher getMatcher(final GrammarRuleKey grammarRuleKey) {
        return this.D.get(grammarRuleKey);
    }
    
    public GrammarRuleKey getRootRuleKey() {
        return this.C;
    }
    
    public int getRootRuleOffset() {
        return this.B;
    }
}
