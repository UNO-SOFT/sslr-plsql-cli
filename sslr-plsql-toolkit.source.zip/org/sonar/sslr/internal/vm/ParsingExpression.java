// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import com.sonar.sslr.impl.matcher.Matcher;

public interface ParsingExpression extends Matcher
{
    Instruction[] compile(final CompilationHandler p0);
}
