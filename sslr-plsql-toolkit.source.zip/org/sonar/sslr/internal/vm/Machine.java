// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import org.sonar.sslr.grammar.GrammarException;
import java.util.Arrays;
import org.sonar.sslr.internal.matchers.Matcher;
import org.sonar.sslr.parser.ParseError;
import org.sonar.sslr.internal.matchers.InputBuffer;
import org.sonar.sslr.internal.matchers.ImmutableInputBuffer;
import org.sonar.sslr.parser.ParsingResult;
import org.sonar.sslr.internal.vm.lexerful.LexerfulParseErrorFormatter;
import com.sonar.sslr.api.RecognitionException;
import java.util.List;
import org.sonar.sslr.internal.matchers.ParseNode;
import com.sonar.sslr.api.Token;

public class Machine implements CharSequence
{
    private final char[] H;
    private final Token[] F;
    private final int C;
    private MachineStack G;
    private int E;
    private int I;
    private boolean A;
    private final ParseNode[] B;
    private final int[] L;
    private final MachineHandler K;
    private boolean D;
    private static final MachineHandler J;
    
    public static ParseNode parse(final List<Token> list, final CompiledGrammar compiledGrammar) {
        final Token[] array = list.toArray(new Token[list.size()]);
        final ErrorLocatingHandler errorLocatingHandler = new ErrorLocatingHandler();
        final Machine machine = new Machine(null, array, compiledGrammar.getInstructions(), errorLocatingHandler);
        machine.A(compiledGrammar.getMatcher(compiledGrammar.getRootRuleKey()), compiledGrammar.getRootRuleOffset(), compiledGrammar.getInstructions());
        if (machine.A) {
            return machine.G.subNodes().get(0);
        }
        if (list.isEmpty()) {
            throw new RecognitionException(1, "No tokens");
        }
        final int errorIndex = errorLocatingHandler.getErrorIndex();
        throw new RecognitionException((errorIndex < list.size()) ? ((Token)list.get(errorIndex)).getLine() : list.get(list.size() - 1).getLine(), new LexerfulParseErrorFormatter().format(list, errorIndex));
    }
    
    public static ParsingResult parse(final char[] array, final CompiledGrammar compiledGrammar) {
        final Instruction[] instructions = compiledGrammar.getInstructions();
        final ErrorLocatingHandler errorLocatingHandler = new ErrorLocatingHandler();
        final Machine machine = new Machine(array, null, instructions, errorLocatingHandler);
        machine.A(compiledGrammar.getMatcher(compiledGrammar.getRootRuleKey()), compiledGrammar.getRootRuleOffset(), instructions);
        if (machine.A) {
            return new ParsingResult(new ImmutableInputBuffer(machine.H), machine.A, machine.G.subNodes().get(0), null);
        }
        final ImmutableInputBuffer immutableInputBuffer = new ImmutableInputBuffer(machine.H);
        return new ParsingResult(immutableInputBuffer, machine.A, null, new ParseError(immutableInputBuffer, errorLocatingHandler.getErrorIndex()));
    }
    
    private void A(final Matcher matcher, final int n, final Instruction[] array) {
        this.A(-1);
        this.G.setMatcher(matcher);
        this.jump(n);
        this.A(array);
    }
    
    public static boolean execute(final String s, final Instruction[] array) {
        final Machine machine = new Machine(s, array);
        while (machine.I != -1 && machine.I < array.length) {
            array[machine.I].execute(machine);
        }
        return machine.A;
    }
    
    public static boolean execute(final Instruction[] array, final Token... array2) {
        final Machine machine = new Machine(null, array2, array, Machine.J);
        while (machine.I != -1 && machine.I < array.length) {
            array[machine.I].execute(machine);
        }
        return machine.A;
    }
    
    public Machine(final String s, final Instruction[] array, final MachineHandler machineHandler) {
        this(s.toCharArray(), null, array, machineHandler);
    }
    
    private Machine(final char[] h, final Token[] f, final Instruction[] array, final MachineHandler k) {
        this.A = true;
        this.D = false;
        this.H = h;
        this.F = f;
        if (h != null) {
            this.C = h.length;
        }
        else {
            this.C = f.length;
        }
        this.K = k;
        this.B = new ParseNode[this.C + 1];
        this.G = new MachineStack();
        (this.G = this.G.getOrCreateChild()).setIndex(-1);
        Arrays.fill(this.L = new int[array.length], -1);
    }
    
    public Machine(final String s, final Instruction[] array) {
        this(s, array, Machine.J);
    }
    
    private void A(final Instruction[] array) {
        while (this.I != -1) {
            array[this.I].execute(this);
        }
    }
    
    public int getAddress() {
        return this.I;
    }
    
    public void setAddress(final int i) {
        this.I = i;
    }
    
    public void jump(final int n) {
        this.I += n;
    }
    
    private void A(final int address) {
        this.G = this.G.getOrCreateChild();
        this.G.subNodes().clear();
        this.G.setAddress(address);
        this.G.setIndex(this.E);
        this.G.setIgnoreErrors(this.D);
    }
    
    public void popReturn() {
        this.L[this.G.calledAddress()] = this.G.leftRecursion();
        this.G = this.G.parent();
    }
    
    public void pushReturn(final int n, final Matcher matcher, final int n2) {
        final ParseNode parseNode = this.B[this.E];
        if (parseNode != null && parseNode.getMatcher() == matcher) {
            this.G.subNodes().add(parseNode);
            this.E = parseNode.getEndIndex();
            this.I += n;
        }
        else {
            this.A(this.I + n);
            this.G.setMatcher(matcher);
            this.I += n2;
            if (this.L[this.I] == this.E) {
                throw new GrammarException("Left recursion has been detected, involved rule: " + matcher.toString());
            }
            this.G.setCalledAddress(this.I);
            this.G.setLeftRecursion(this.L[this.I]);
            this.L[this.I] = this.E;
        }
    }
    
    public void pushBacktrack(final int n) {
        this.A(this.I + n);
        this.G.setMatcher(null);
    }
    
    public void pop() {
        this.G = this.G.parent();
    }
    
    public MachineStack peek() {
        return this.G;
    }
    
    public void setIgnoreErrors(final boolean d) {
        this.D = d;
    }
    
    public void backtrack() {
        while (this.G.isReturn()) {
            if (!(this.D = this.G.isIgnoreErrors())) {
                this.K.onBacktrack(this);
            }
            this.popReturn();
        }
        if (this.G.isEmpty()) {
            this.I = -1;
            this.A = false;
        }
        else {
            this.E = this.G.index();
            this.I = this.G.address();
            this.D = this.G.isIgnoreErrors();
            this.G = this.G.parent();
        }
    }
    
    public void createNode() {
        final ParseNode parseNode = new ParseNode(this.G.index(), this.E, this.G.subNodes(), this.G.matcher());
        this.G.parent().subNodes().add(parseNode);
        if (this.G.matcher() instanceof MemoParsingExpression && ((MemoParsingExpression)this.G.matcher()).shouldMemoize()) {
            this.B[this.G.index()] = parseNode;
        }
    }
    
    public void createLeafNode(final Matcher matcher, final int n) {
        this.G.subNodes().add(new ParseNode(this.E, this.E + n, matcher));
        this.E += n;
    }
    
    public int getIndex() {
        return this.E;
    }
    
    public void setIndex(final int e) {
        this.E = e;
    }
    
    public void advanceIndex(final int n) {
        this.E += n;
    }
    
    @Override
    public int length() {
        return this.C - this.E;
    }
    
    @Override
    public char charAt(final int n) {
        return this.H[this.E + n];
    }
    
    @Override
    public CharSequence subSequence(final int n, final int n2) {
        throw new UnsupportedOperationException();
    }
    
    public Token tokenAt(final int n) {
        return this.F[this.E + n];
    }
    
    static {
        J = new MachineHandler() {
            @Override
            public void onBacktrack(final Machine machine) {
            }
        };
    }
}
