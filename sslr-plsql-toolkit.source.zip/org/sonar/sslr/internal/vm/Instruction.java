// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import java.util.Objects;
import org.sonar.sslr.internal.matchers.ParseNode;
import java.util.Collection;
import org.sonar.sslr.grammar.GrammarException;
import org.sonar.sslr.internal.matchers.Matcher;
import java.util.List;

public abstract class Instruction
{
    private static final Instruction \u038a;
    private static final Instruction \u038c;
    private static final Instruction \u038f;
    private static final Instruction \u0389;
    private static final Instruction \u038e;
    
    public static void addAll(final List<Instruction> list, final Instruction[] array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            list.add(array[i]);
        }
    }
    
    public static Instruction jump(final int n) {
        return new JumpInstruction(n);
    }
    
    public static Instruction call(final int n, final Matcher matcher) {
        return new CallInstruction(n, matcher);
    }
    
    public static Instruction ret() {
        return Instruction.\u038a;
    }
    
    public static Instruction backtrack() {
        return Instruction.\u038c;
    }
    
    public static Instruction end() {
        return Instruction.\u038f;
    }
    
    public static Instruction choice(final int n) {
        return new ChoiceInstruction(n);
    }
    
    public static Instruction predicateChoice(final int n) {
        return new PredicateChoiceInstruction(n);
    }
    
    public static Instruction commit(final int n) {
        return new CommitInstruction(n);
    }
    
    public static Instruction commitVerify(final int n) {
        return new CommitVerifyInstruction(n);
    }
    
    public static Instruction failTwice() {
        return Instruction.\u0389;
    }
    
    public static Instruction backCommit(final int n) {
        return new BackCommitInstruction(n);
    }
    
    public static Instruction ignoreErrors() {
        return Instruction.\u038e;
    }
    
    public abstract void execute(final Machine p0);
    
    static {
        \u038a = new RetInstruction();
        \u038c = new BacktrackInstruction();
        \u038f = new EndInstruction();
        \u0389 = new FailTwiceInstruction();
        \u038e = new IgnoreErrorsInstruction();
    }
    
    public static final class BackCommitInstruction extends Instruction
    {
        private final int \u0394;
        
        public BackCommitInstruction(final int \u03b4) {
            this.\u0394 = \u03b4;
        }
        
        @Override
        public void execute(final Machine machine) {
            final MachineStack peek = machine.peek();
            machine.setIndex(peek.index());
            machine.setIgnoreErrors(peek.isIgnoreErrors());
            machine.pop();
            machine.jump(this.\u0394);
        }
        
        @Override
        public String toString() {
            return "BackCommit " + this.\u0394;
        }
        
        @Override
        public boolean equals(final Object o) {
            return o instanceof BackCommitInstruction && this.\u0394 == ((BackCommitInstruction)o).\u0394;
        }
        
        @Override
        public int hashCode() {
            return this.\u0394;
        }
    }
    
    public static final class FailTwiceInstruction extends Instruction
    {
        @Override
        public void execute(final Machine machine) {
            machine.setIndex(machine.peek().index());
            machine.pop();
            machine.backtrack();
        }
        
        @Override
        public String toString() {
            return "FailTwice";
        }
    }
    
    public static final class EndInstruction extends Instruction
    {
        @Override
        public void execute(final Machine machine) {
            machine.setAddress(-1);
        }
        
        @Override
        public String toString() {
            return "End";
        }
    }
    
    public static final class BacktrackInstruction extends Instruction
    {
        @Override
        public void execute(final Machine machine) {
            machine.backtrack();
        }
        
        @Override
        public String toString() {
            return "Backtrack";
        }
    }
    
    public static final class RetInstruction extends Instruction
    {
        @Override
        public void execute(final Machine machine) {
            machine.createNode();
            final MachineStack peek = machine.peek();
            machine.setIgnoreErrors(peek.isIgnoreErrors());
            machine.setAddress(peek.address());
            machine.popReturn();
        }
        
        @Override
        public String toString() {
            return "Ret";
        }
    }
    
    public static final class CommitVerifyInstruction extends Instruction
    {
        private final int \u0390;
        
        public CommitVerifyInstruction(final int \u0390) {
            this.\u0390 = \u0390;
        }
        
        @Override
        public void execute(final Machine machine) {
            if (machine.getIndex() == machine.peek().index()) {
                throw new GrammarException("The inner part of ZeroOrMore and OneOrMore must not allow empty matches");
            }
            machine.peek().parent().subNodes().addAll(machine.peek().subNodes());
            machine.pop();
            machine.jump(this.\u0390);
        }
        
        @Override
        public String toString() {
            return "CommitVerify " + this.\u0390;
        }
        
        @Override
        public boolean equals(final Object o) {
            return o instanceof CommitVerifyInstruction && this.\u0390 == ((CommitVerifyInstruction)o).\u0390;
        }
        
        @Override
        public int hashCode() {
            return this.\u0390;
        }
    }
    
    public static final class CommitInstruction extends Instruction
    {
        private final int \u0397;
        
        public CommitInstruction(final int \u03b7) {
            this.\u0397 = \u03b7;
        }
        
        @Override
        public void execute(final Machine machine) {
            machine.peek().parent().subNodes().addAll(machine.peek().subNodes());
            machine.pop();
            machine.jump(this.\u0397);
        }
        
        @Override
        public String toString() {
            return "Commit " + this.\u0397;
        }
        
        @Override
        public boolean equals(final Object o) {
            return o instanceof CommitInstruction && this.\u0397 == ((CommitInstruction)o).\u0397;
        }
        
        @Override
        public int hashCode() {
            return this.\u0397;
        }
    }
    
    public static final class PredicateChoiceInstruction extends Instruction
    {
        private final int \u0396;
        
        public PredicateChoiceInstruction(final int \u03b6) {
            this.\u0396 = \u03b6;
        }
        
        @Override
        public void execute(final Machine machine) {
            machine.pushBacktrack(this.\u0396);
            machine.setIgnoreErrors(true);
            machine.jump(1);
        }
        
        @Override
        public String toString() {
            return "PredicateChoice " + this.\u0396;
        }
        
        @Override
        public boolean equals(final Object o) {
            return o instanceof PredicateChoiceInstruction && this.\u0396 == ((PredicateChoiceInstruction)o).\u0396;
        }
        
        @Override
        public int hashCode() {
            return this.\u0396;
        }
    }
    
    public static final class IgnoreErrorsInstruction extends Instruction
    {
        @Override
        public void execute(final Machine machine) {
            machine.setIgnoreErrors(true);
            machine.jump(1);
        }
        
        @Override
        public String toString() {
            return "IgnoreErrors";
        }
    }
    
    public static final class ChoiceInstruction extends Instruction
    {
        private final int \u0391;
        
        public ChoiceInstruction(final int \u03b1) {
            this.\u0391 = \u03b1;
        }
        
        @Override
        public void execute(final Machine machine) {
            machine.pushBacktrack(this.\u0391);
            machine.jump(1);
        }
        
        @Override
        public String toString() {
            return "Choice " + this.\u0391;
        }
        
        @Override
        public boolean equals(final Object o) {
            return o instanceof ChoiceInstruction && this.\u0391 == ((ChoiceInstruction)o).\u0391;
        }
        
        @Override
        public int hashCode() {
            return this.\u0391;
        }
    }
    
    public static final class CallInstruction extends Instruction
    {
        private final int \u0393;
        private final Matcher \u0392;
        
        public CallInstruction(final int \u03b3, final Matcher \u03b2) {
            this.\u0393 = \u03b3;
            this.\u0392 = \u03b2;
        }
        
        @Override
        public void execute(final Machine machine) {
            machine.pushReturn(1, this.\u0392, this.\u0393);
        }
        
        @Override
        public String toString() {
            return "Call " + this.\u0393;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (o instanceof CallInstruction) {
                final CallInstruction callInstruction = (CallInstruction)o;
                return this.\u0393 == callInstruction.\u0393 && Objects.equals(this.\u0392, callInstruction.\u0392);
            }
            return false;
        }
        
        @Override
        public int hashCode() {
            return this.\u0393;
        }
    }
    
    public static final class JumpInstruction extends Instruction
    {
        private final int \u0395;
        
        public JumpInstruction(final int \u03b5) {
            this.\u0395 = \u03b5;
        }
        
        @Override
        public void execute(final Machine machine) {
            machine.jump(this.\u0395);
        }
        
        @Override
        public String toString() {
            return "Jump " + this.\u0395;
        }
        
        @Override
        public boolean equals(final Object o) {
            return o instanceof JumpInstruction && this.\u0395 == ((JumpInstruction)o).\u0395;
        }
        
        @Override
        public int hashCode() {
            return this.\u0395;
        }
    }
}
