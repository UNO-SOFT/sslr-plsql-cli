// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import org.sonar.sslr.internal.matchers.Matcher;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ArrayDeque;
import org.sonar.sslr.grammar.GrammarRuleKey;
import java.util.Map;
import java.util.Queue;

public class MutableGrammarCompiler extends CompilationHandler
{
    private final Queue<CompilableGrammarRule> C;
    private final Map<GrammarRuleKey, CompilableGrammarRule> A;
    private final Map<GrammarRuleKey, Integer> B;
    
    public MutableGrammarCompiler() {
        this.C = new ArrayDeque<CompilableGrammarRule>();
        this.A = new HashMap<GrammarRuleKey, CompilableGrammarRule>();
        this.B = new HashMap<GrammarRuleKey, Integer>();
    }
    
    public static CompiledGrammar compile(final CompilableGrammarRule compilableGrammarRule) {
        return new MutableGrammarCompiler().A(compilableGrammarRule);
    }
    
    private CompiledGrammar A(final CompilableGrammarRule compilableGrammarRule) {
        final ArrayList list = new ArrayList();
        this.C.add(compilableGrammarRule);
        this.A.put(compilableGrammarRule.getRuleKey(), compilableGrammarRule);
        while (!this.C.isEmpty()) {
            final CompilableGrammarRule compilableGrammarRule2 = this.C.poll();
            this.B.put(compilableGrammarRule2.getRuleKey(), list.size());
            Instruction.addAll(list, this.compile(compilableGrammarRule2.getExpression()));
            list.add(Instruction.ret());
        }
        final Instruction[] array = (Instruction[])list.toArray(new Instruction[list.size()]);
        for (int i = 0; i < array.length; ++i) {
            final Instruction instruction = array[i];
            if (instruction instanceof RuleRefExpression) {
                final GrammarRuleKey ruleKey = ((RuleRefExpression)instruction).getRuleKey();
                array[i] = Instruction.call(this.B.get(ruleKey) - i, this.A.get(ruleKey));
            }
        }
        return new CompiledGrammar(array, this.A, compilableGrammarRule.getRuleKey(), this.B.get(compilableGrammarRule.getRuleKey()));
    }
    
    @Override
    public Instruction[] compile(final ParsingExpression parsingExpression) {
        if (parsingExpression instanceof CompilableGrammarRule) {
            final CompilableGrammarRule compilableGrammarRule = (CompilableGrammarRule)parsingExpression;
            if (!this.A.containsKey(compilableGrammarRule.getRuleKey())) {
                this.C.add(compilableGrammarRule);
                this.A.put(compilableGrammarRule.getRuleKey(), compilableGrammarRule);
            }
            return compilableGrammarRule.compile(this);
        }
        return parsingExpression.compile(this);
    }
}
