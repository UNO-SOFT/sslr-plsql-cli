// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import org.sonar.sslr.grammar.GrammarException;
import java.util.regex.Pattern;
import org.sonar.sslr.internal.matchers.Matcher;

public class PatternExpression extends NativeExpression implements Matcher
{
    private final java.util.regex.Matcher \u039f;
    
    public PatternExpression(final String regex) {
        this.\u039f = Pattern.compile(regex).matcher("");
    }
    
    @Override
    public void execute(final Machine input) {
        this.\u039f.reset(input);
        boolean looking;
        try {
            looking = this.\u039f.lookingAt();
        }
        catch (final StackOverflowError stackOverflowError) {
            throw new GrammarException(stackOverflowError, "The regular expression '" + this.\u039f.pattern().pattern() + "' has led to a stack overflow error. This error is certainly due to an inefficient use of alternations. See http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=5050507");
        }
        if (looking) {
            input.createLeafNode(this, this.\u039f.end());
            input.jump(1);
        }
        else {
            input.backtrack();
        }
        this.\u039f.reset("");
    }
    
    @Override
    public String toString() {
        return "Pattern " + this.\u039f.pattern().pattern();
    }
    
    java.util.regex.Matcher C() {
        return this.\u039f;
    }
}
