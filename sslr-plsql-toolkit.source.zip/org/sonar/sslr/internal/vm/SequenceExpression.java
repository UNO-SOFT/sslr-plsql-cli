// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class SequenceExpression implements ParsingExpression
{
    private final ParsingExpression[] \u037a;
    
    public SequenceExpression(final ParsingExpression... \u037a) {
        this.\u037a = \u037a;
    }
    
    @Override
    public Instruction[] compile(final CompilationHandler compilationHandler) {
        final ArrayList list = new ArrayList();
        final ParsingExpression[] \u037a = this.\u037a;
        for (int length = \u037a.length, i = 0; i < length; ++i) {
            Instruction.addAll(list, compilationHandler.compile(\u037a[i]));
        }
        return (Instruction[])list.toArray(new Instruction[list.size()]);
    }
    
    @Override
    public String toString() {
        return "Sequence" + Arrays.toString(this.\u037a);
    }
}
