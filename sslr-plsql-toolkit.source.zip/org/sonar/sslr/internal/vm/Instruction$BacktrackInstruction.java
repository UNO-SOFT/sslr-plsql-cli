// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public static final class BacktrackInstruction extends Instruction
{
    @Override
    public void execute(final Machine machine) {
        machine.backtrack();
    }
    
    @Override
    public String toString() {
        return "Backtrack";
    }
}
