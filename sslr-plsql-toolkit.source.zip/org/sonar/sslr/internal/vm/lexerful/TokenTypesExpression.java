// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm.lexerful;

import org.sonar.sslr.internal.vm.Machine;
import java.util.Collection;
import java.util.Arrays;
import java.util.HashSet;
import com.sonar.sslr.api.TokenType;
import java.util.Set;
import org.sonar.sslr.internal.matchers.Matcher;
import org.sonar.sslr.internal.vm.NativeExpression;

public class TokenTypesExpression extends NativeExpression implements Matcher
{
    private final Set<TokenType> \u0398;
    
    public TokenTypesExpression(final TokenType... a) {
        (this.\u0398 = new HashSet<TokenType>()).addAll(Arrays.asList(a));
    }
    
    @Override
    public void execute(final Machine machine) {
        if (machine.length() == 0 || !this.\u0398.contains(machine.tokenAt(0).getType())) {
            machine.backtrack();
            return;
        }
        machine.createLeafNode(this, 1);
        machine.jump(1);
    }
    
    @Override
    public String toString() {
        return "TokenTypes " + this.\u0398;
    }
}
