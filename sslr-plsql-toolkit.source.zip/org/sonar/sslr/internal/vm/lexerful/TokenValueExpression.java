// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm.lexerful;

import com.sonar.sslr.api.Token;
import org.sonar.sslr.internal.vm.Machine;
import org.sonar.sslr.internal.matchers.Matcher;
import org.sonar.sslr.internal.vm.NativeExpression;

public class TokenValueExpression extends NativeExpression implements Matcher
{
    private final String \u039b;
    
    public TokenValueExpression(final String \u03bb) {
        this.\u039b = \u03bb;
    }
    
    @Override
    public void execute(final Machine machine) {
        if (machine.length() == 0) {
            machine.backtrack();
            return;
        }
        final Token token = machine.tokenAt(0);
        if (this.\u039b.hashCode() == token.getValue().hashCode() && this.\u039b.equals(token.getValue())) {
            machine.createLeafNode(this, 1);
            machine.jump(1);
        }
        else {
            machine.backtrack();
        }
    }
    
    @Override
    public String toString() {
        return "TokenValue " + this.\u039b;
    }
}
