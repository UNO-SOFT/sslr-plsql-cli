// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm.lexerful;

static synthetic class LexerfulParseErrorFormatter$1 {}