// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm.lexerful;

import org.sonar.sslr.internal.vm.Machine;
import org.sonar.sslr.internal.matchers.Matcher;
import org.sonar.sslr.internal.vm.NativeExpression;

public class TokenTypeClassExpression extends NativeExpression implements Matcher
{
    private final Class \u0399;
    
    public TokenTypeClassExpression(final Class \u03b9) {
        this.\u0399 = \u03b9;
    }
    
    @Override
    public void execute(final Machine machine) {
        if (machine.length() == 0 || this.\u0399 != machine.tokenAt(0).getType().getClass()) {
            machine.backtrack();
            return;
        }
        machine.createLeafNode(this, 1);
        machine.jump(1);
    }
    
    @Override
    public String toString() {
        return "TokenTypeClass " + this.\u0399;
    }
}
