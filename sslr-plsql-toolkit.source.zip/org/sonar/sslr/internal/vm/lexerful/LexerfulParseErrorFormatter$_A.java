// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm.lexerful;

private static class _A
{
    int A;
    int B;
    
    @Override
    public String toString() {
        return "(" + this.A + ", " + this.B + ")";
    }
}
