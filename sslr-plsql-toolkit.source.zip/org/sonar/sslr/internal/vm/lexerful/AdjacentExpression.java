// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm.lexerful;

import com.sonar.sslr.api.Token;
import org.sonar.sslr.internal.vm.Machine;
import org.sonar.sslr.internal.vm.NativeExpression;

public class AdjacentExpression extends NativeExpression
{
    public static final AdjacentExpression INSTANCE;
    
    private AdjacentExpression() {
    }
    
    @Override
    public void execute(final Machine machine) {
        if (machine.getIndex() == 0) {
            machine.backtrack();
            return;
        }
        final Token token = machine.tokenAt(-1);
        final Token token2 = machine.tokenAt(0);
        if (token2.getColumn() <= token.getColumn() + token.getValue().length() && token2.getLine() == token.getLine()) {
            machine.jump(1);
        }
        else {
            machine.backtrack();
        }
    }
    
    @Override
    public String toString() {
        return "Adjacent";
    }
    
    static {
        INSTANCE = new AdjacentExpression();
    }
}
