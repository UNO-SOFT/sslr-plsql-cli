// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm.lexerful;

import com.sonar.sslr.api.Token;
import org.sonar.sslr.internal.vm.Machine;
import com.sonar.sslr.api.TokenType;
import org.sonar.sslr.internal.matchers.Matcher;
import org.sonar.sslr.internal.vm.NativeExpression;

public class TokensBridgeExpression extends NativeExpression implements Matcher
{
    private final TokenType \u039d;
    private final TokenType \u039c;
    
    public TokensBridgeExpression(final TokenType \u03bd, final TokenType \u03bc) {
        this.\u039d = \u03bd;
        this.\u039c = \u03bc;
    }
    
    @Override
    public void execute(final Machine machine) {
        final int length = machine.length();
        if (length < 2 || machine.tokenAt(0).getType() != this.\u039d) {
            machine.backtrack();
            return;
        }
        int n = 0;
        int n2 = 1;
        while (++n < length) {
            final Token token = machine.tokenAt(n);
            if (token.getType() == this.\u039d) {
                ++n2;
            }
            else if (token.getType() == this.\u039c) {
                --n2;
            }
            if (n2 == 0) {
                for (int i = 0; i <= n; ++i) {
                    machine.createLeafNode(this, 1);
                }
                machine.jump(1);
                return;
            }
        }
        machine.backtrack();
    }
    
    @Override
    public String toString() {
        return "Bridge[" + this.\u039d + "," + this.\u039c + "]";
    }
}
