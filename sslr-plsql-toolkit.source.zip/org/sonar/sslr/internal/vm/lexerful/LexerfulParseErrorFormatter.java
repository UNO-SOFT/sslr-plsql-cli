// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm.lexerful;

import java.util.Iterator;
import com.sonar.sslr.api.Token;
import java.util.List;

public class LexerfulParseErrorFormatter
{
    private static final int A = 30;
    
    public String format(final List<Token> list, final int n) {
        final StringBuilder sb = new StringBuilder();
        final _A a = (n < list.size()) ? B(list.get(n)) : A(list.get(list.size() - 1));
        sb.append("Parse error at line ").append(a.A).append(" column ").append(a.B).append(":\n\n");
        A(sb, list, n, a.A);
        return sb.toString();
    }
    
    private static _A B(final Token token) {
        final _A a = new _A();
        a.A = token.getLine();
        a.B = token.getColumn();
        return a;
    }
    
    private static _A A(final Token token) {
        final _A a = new _A();
        a.A = token.getLine();
        a.B = token.getColumn();
        final String[] split = token.getOriginalValue().split("(\r)?\n|\r", -1);
        if (split.length == 1) {
            final _A a2 = a;
            a2.B += split[0].length();
        }
        else {
            final _A a3 = a;
            a3.A += split.length - 1;
            a.B = split[split.length - 1].length();
        }
        return a;
    }
    
    private static void A(final StringBuilder sb, final List<Token> list, final int n, final int n2) {
        final List<Token> subList = list.subList(Math.max(n - 30, 0), Math.min(n + 30, list.size()));
        int i = subList.get(0).getLine();
        int j = subList.get(0).getColumn();
        sb.append(A(i, n2));
        for (final Token token : subList) {
            while (i < token.getLine()) {
                ++i;
                j = 0;
                sb.append('\n').append(A(i, n2));
            }
            while (j < token.getColumn()) {
                sb.append(' ');
                ++j;
            }
            final String[] split = token.getOriginalValue().split("(\r)?\n|\r", -1);
            sb.append(split[0]);
            j += split[0].length();
            for (int k = 1; k < split.length; ++k) {
                ++i;
                sb.append('\n').append(A(i, n2)).append(split[k]);
                j = split[k].length();
            }
        }
        sb.append('\n');
    }
    
    private static String A(final int i, final int n) {
        return (i == n) ? String.format("%1$5s  ", "-->") : String.format("%1$5d: ", i);
    }
    
    private static class _A
    {
        int A;
        int B;
        
        @Override
        public String toString() {
            return "(" + this.A + ", " + this.B + ")";
        }
    }
}
