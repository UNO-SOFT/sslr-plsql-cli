// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm.lexerful;

import org.sonar.sslr.internal.vm.Machine;
import com.sonar.sslr.api.TokenType;
import org.sonar.sslr.internal.matchers.Matcher;
import org.sonar.sslr.internal.vm.NativeExpression;

public class TokenTypeExpression extends NativeExpression implements Matcher
{
    private final TokenType \u039a;
    
    public TokenTypeExpression(final TokenType \u03ba) {
        this.\u039a = \u03ba;
    }
    
    @Override
    public void execute(final Machine machine) {
        if (machine.length() == 0 || this.\u039a != machine.tokenAt(0).getType()) {
            machine.backtrack();
            return;
        }
        machine.createLeafNode(this, 1);
        machine.jump(1);
    }
    
    @Override
    public String toString() {
        return "TokenType " + this.\u039a;
    }
}
