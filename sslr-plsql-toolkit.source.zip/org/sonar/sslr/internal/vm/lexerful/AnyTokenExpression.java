// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm.lexerful;

import org.sonar.sslr.internal.vm.Machine;
import org.sonar.sslr.internal.matchers.Matcher;
import org.sonar.sslr.internal.vm.NativeExpression;

public class AnyTokenExpression extends NativeExpression implements Matcher
{
    public static final AnyTokenExpression INSTANCE;
    
    private AnyTokenExpression() {
    }
    
    @Override
    public void execute(final Machine machine) {
        if (machine.length() == 0) {
            machine.backtrack();
        }
        else {
            machine.createLeafNode(this, 1);
            machine.jump(1);
        }
    }
    
    @Override
    public String toString() {
        return "AnyToken";
    }
    
    static {
        INSTANCE = new AnyTokenExpression();
    }
}
