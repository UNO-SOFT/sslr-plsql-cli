// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm.lexerful;

import com.sonar.sslr.api.Token;
import com.sonar.sslr.api.GenericTokenType;
import org.sonar.sslr.internal.vm.Machine;
import org.sonar.sslr.internal.matchers.Matcher;
import org.sonar.sslr.internal.vm.NativeExpression;

public class TillNewLineExpression extends NativeExpression implements Matcher
{
    public static final TillNewLineExpression INSTANCE;
    
    private TillNewLineExpression() {
    }
    
    @Override
    public void execute(final Machine machine) {
        final int n = (machine.getIndex() == 0) ? 1 : machine.tokenAt(-1).getLine();
        int n2 = 0;
        for (Token token = machine.tokenAt(n2); token.getLine() == n && token.getType() != GenericTokenType.EOF; token = machine.tokenAt(n2)) {
            ++n2;
        }
        for (int i = 0; i < n2; ++i) {
            machine.createLeafNode(this, 1);
        }
        machine.jump(1);
    }
    
    @Override
    public String toString() {
        return "TillNewLine";
    }
    
    static {
        INSTANCE = new TillNewLineExpression();
    }
}
