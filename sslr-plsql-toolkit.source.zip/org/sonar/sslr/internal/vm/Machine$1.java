// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

class Machine$1 implements MachineHandler {
    @Override
    public void onBacktrack(final Machine machine) {
    }
}