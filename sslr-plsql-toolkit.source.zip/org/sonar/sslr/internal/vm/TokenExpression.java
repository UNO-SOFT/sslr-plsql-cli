// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import com.sonar.sslr.api.TokenType;
import org.sonar.sslr.internal.matchers.Matcher;

public class TokenExpression implements Matcher, ParsingExpression
{
    private final TokenType O;
    private final ParsingExpression N;
    
    public TokenExpression(final TokenType o, final ParsingExpression n) {
        this.O = o;
        this.N = n;
    }
    
    public TokenType getTokenType() {
        return this.O;
    }
    
    @Override
    public Instruction[] compile(final CompilationHandler compilationHandler) {
        return A(compilationHandler, this, this.N);
    }
    
    static Instruction[] A(final CompilationHandler compilationHandler, final Matcher matcher, final ParsingExpression parsingExpression) {
        final Instruction[] compile = compilationHandler.compile(parsingExpression);
        final Instruction[] array = new Instruction[compile.length + 4];
        array[0] = Instruction.call(2, matcher);
        array[1] = Instruction.jump(compile.length + 3);
        array[2] = Instruction.ignoreErrors();
        System.arraycopy(compile, 0, array, 3, compile.length);
        array[3 + compile.length] = Instruction.ret();
        return array;
    }
    
    @Override
    public String toString() {
        return "Token " + this.O + "[" + this.N + "]";
    }
}
