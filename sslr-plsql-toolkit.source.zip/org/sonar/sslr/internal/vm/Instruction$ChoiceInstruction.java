// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public static final class ChoiceInstruction extends Instruction
{
    private final int \u0391;
    
    public ChoiceInstruction(final int \u03b1) {
        this.\u0391 = \u03b1;
    }
    
    @Override
    public void execute(final Machine machine) {
        machine.pushBacktrack(this.\u0391);
        machine.jump(1);
    }
    
    @Override
    public String toString() {
        return "Choice " + this.\u0391;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof ChoiceInstruction && this.\u0391 == ((ChoiceInstruction)o).\u0391;
    }
    
    @Override
    public int hashCode() {
        return this.\u0391;
    }
}
