// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

public class OneOrMoreExpression implements ParsingExpression
{
    private final ParsingExpression M;
    
    public OneOrMoreExpression(final ParsingExpression m) {
        this.M = m;
    }
    
    @Override
    public Instruction[] compile(final CompilationHandler compilationHandler) {
        final Instruction[] compile = compilationHandler.compile(this.M);
        final Instruction[] array = new Instruction[compile.length + 5];
        array[0] = Instruction.choice(compile.length + 4);
        System.arraycopy(compile, 0, array, 1, compile.length);
        array[compile.length + 1] = Instruction.commitVerify(1);
        array[compile.length + 2] = Instruction.choice(3);
        array[compile.length + 3] = Instruction.jump(-2 - compile.length);
        array[compile.length + 4] = Instruction.backtrack();
        return array;
    }
    
    @Override
    public String toString() {
        return "OneOrMore[" + this.M + "]";
    }
}
