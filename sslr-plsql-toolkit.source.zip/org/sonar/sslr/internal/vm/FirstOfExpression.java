// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.internal.vm;

import java.util.Arrays;

public class FirstOfExpression implements ParsingExpression
{
    private final ParsingExpression[] \u0386;
    
    public FirstOfExpression(final ParsingExpression... \u03ac) {
        this.\u0386 = \u03ac;
    }
    
    @Override
    public Instruction[] compile(final CompilationHandler compilationHandler) {
        int n = 0;
        final Instruction[][] array = new Instruction[this.\u0386.length][];
        for (int i = 0; i < this.\u0386.length; ++i) {
            array[i] = compilationHandler.compile(this.\u0386[i]);
            n += array[i].length;
        }
        final Instruction[] array2 = new Instruction[n + (this.\u0386.length - 1) * 2];
        int n2 = 0;
        for (int j = 0; j < this.\u0386.length - 1; ++j) {
            array2[n2] = Instruction.choice(array[j].length + 2);
            System.arraycopy(array[j], 0, array2, n2 + 1, array[j].length);
            n2 += array[j].length + 1;
            array2[n2] = Instruction.commit(array2.length - n2);
            ++n2;
        }
        System.arraycopy(array[array.length - 1], 0, array2, n2, array[array.length - 1].length);
        return array2;
    }
    
    @Override
    public String toString() {
        return "FirstOf" + Arrays.toString(this.\u0386);
    }
}
