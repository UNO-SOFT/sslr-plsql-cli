// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.parser;

import com.sonar.sslr.impl.matcher.RuleDefinition;
import com.sonar.sslr.api.Token;
import java.util.List;
import org.sonar.sslr.internal.matchers.AstCreator;
import java.io.IOException;
import com.sonar.sslr.api.RecognitionException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.File;
import org.sonar.sslr.internal.matchers.LocatedText;
import com.sonar.sslr.api.AstNode;
import java.util.Objects;
import java.nio.charset.Charset;
import com.sonar.sslr.impl.Parser;

public class ParserAdapter<G extends LexerlessGrammar> extends Parser<G>
{
    private final Charset H;
    private final ParseRunner G;
    
    public ParserAdapter(final Charset obj, final G obj2) {
        super(Objects.requireNonNull(obj2, "grammar"));
        this.H = Objects.requireNonNull(obj, "charset");
        this.G = new ParseRunner(obj2.getRootRule());
    }
    
    @Override
    public AstNode parse(final String s) {
        return this.A(new LocatedText(null, s.toCharArray()));
    }
    
    @Override
    public AstNode parse(final File file) {
        return this.A(new LocatedText(file, A(file, this.H)));
    }
    
    private static char[] A(final File file, final Charset charset) {
        try {
            return new String(Files.readAllBytes(Paths.get(file.getPath(), new String[0])), charset).toCharArray();
        }
        catch (final IOException ex) {
            throw new RecognitionException(0, ex.getMessage(), ex);
        }
    }
    
    private AstNode A(final LocatedText locatedText) {
        final ParsingResult parse = this.G.parse(locatedText.toChars());
        if (parse.isMatched()) {
            return AstCreator.create(parse, locatedText);
        }
        final ParseError parseError = parse.getParseError();
        throw new RecognitionException(parseError.getInputBuffer().getPosition(parseError.getErrorIndex()).getLine(), new ParseErrorFormatter().format(parseError));
    }
    
    @Override
    public AstNode parse(final List<Token> list) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public RuleDefinition getRootRule() {
        throw new UnsupportedOperationException();
    }
}
