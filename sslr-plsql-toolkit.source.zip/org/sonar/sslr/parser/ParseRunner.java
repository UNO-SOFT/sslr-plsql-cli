// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.parser;

import org.sonar.sslr.internal.vm.Machine;
import org.sonar.sslr.internal.vm.MutableGrammarCompiler;
import java.util.Objects;
import org.sonar.sslr.internal.vm.CompilableGrammarRule;
import com.sonar.sslr.api.Rule;
import org.sonar.sslr.internal.vm.CompiledGrammar;

public class ParseRunner
{
    private final CompiledGrammar A;
    
    public ParseRunner(final Rule obj) {
        this.A = MutableGrammarCompiler.compile(Objects.requireNonNull(obj, "rule"));
    }
    
    public ParsingResult parse(final char[] array) {
        return Machine.parse(array, this.A);
    }
}
