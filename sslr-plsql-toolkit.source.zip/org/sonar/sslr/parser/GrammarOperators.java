// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.parser;

import org.sonar.sslr.internal.vm.StringExpression;
import org.sonar.sslr.internal.vm.SequenceExpression;
import org.sonar.sslr.internal.vm.ParsingExpression;
import org.sonar.sslr.internal.vm.TriviaExpression;
import com.sonar.sslr.api.Trivia;
import org.sonar.sslr.internal.vm.TokenExpression;
import com.sonar.sslr.api.TokenType;
import org.sonar.sslr.internal.vm.NothingExpression;
import org.sonar.sslr.internal.vm.EndOfInputExpression;
import org.sonar.sslr.internal.vm.PatternExpression;
import org.sonar.sslr.internal.vm.NextNotExpression;
import org.sonar.sslr.internal.vm.NextExpression;
import org.sonar.sslr.internal.vm.ZeroOrMoreExpression;
import org.sonar.sslr.internal.vm.OneOrMoreExpression;
import org.sonar.sslr.internal.vm.OptionalExpression;
import org.sonar.sslr.internal.vm.FirstOfExpression;
import java.util.Objects;

@Deprecated
public final class GrammarOperators
{
    private GrammarOperators() {
    }
    
    @Deprecated
    public static Object sequence(final Object... array) {
        return A(array);
    }
    
    @Deprecated
    public static Object firstOf(final Object... obj) {
        Objects.requireNonNull(obj);
        if (obj.length == 1) {
            return A(obj[0]);
        }
        return new FirstOfExpression(B(obj));
    }
    
    @Deprecated
    public static Object optional(final Object... array) {
        return new OptionalExpression(A(array));
    }
    
    @Deprecated
    public static Object oneOrMore(final Object... array) {
        return new OneOrMoreExpression(A(array));
    }
    
    @Deprecated
    public static Object zeroOrMore(final Object... array) {
        return new ZeroOrMoreExpression(A(array));
    }
    
    @Deprecated
    public static Object next(final Object... array) {
        return new NextExpression(A(array));
    }
    
    @Deprecated
    public static Object nextNot(final Object... array) {
        return new NextNotExpression(A(array));
    }
    
    @Deprecated
    public static Object regexp(final String s) {
        return new PatternExpression(s);
    }
    
    @Deprecated
    public static Object endOfInput() {
        return EndOfInputExpression.INSTANCE;
    }
    
    @Deprecated
    public static Object nothing() {
        return NothingExpression.INSTANCE;
    }
    
    @Deprecated
    public static Object token(final TokenType tokenType, final Object o) {
        return new TokenExpression(tokenType, A(o));
    }
    
    @Deprecated
    public static Object commentTrivia(final Object o) {
        return new TriviaExpression(Trivia.TriviaKind.COMMENT, A(o));
    }
    
    @Deprecated
    public static Object skippedTrivia(final Object o) {
        return new TriviaExpression(Trivia.TriviaKind.SKIPPED_TEXT, A(o));
    }
    
    private static ParsingExpression A(final Object... obj) {
        Objects.requireNonNull(obj);
        if (obj.length == 1) {
            return A(obj[0]);
        }
        return new SequenceExpression(B(obj));
    }
    
    private static ParsingExpression[] B(final Object... obj) {
        Objects.requireNonNull(obj);
        if (obj.length <= 0) {
            throw new IllegalArgumentException();
        }
        final ParsingExpression[] array = new ParsingExpression[obj.length];
        for (int i = 0; i < array.length; ++i) {
            array[i] = A(obj[i]);
        }
        return array;
    }
    
    private static ParsingExpression A(final Object obj) {
        Objects.requireNonNull(obj);
        if (obj instanceof ParsingExpression) {
            return (ParsingExpression)obj;
        }
        if (obj instanceof String) {
            return new StringExpression((String)obj);
        }
        if (obj instanceof Character) {
            return new StringExpression(((Character)obj).toString());
        }
        throw new IllegalArgumentException("Incorrect type of parsing expression: " + obj.getClass().toString());
    }
}
