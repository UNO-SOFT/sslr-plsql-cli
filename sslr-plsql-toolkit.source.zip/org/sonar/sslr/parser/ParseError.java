// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.parser;

import java.util.Objects;
import org.sonar.sslr.internal.matchers.InputBuffer;

public class ParseError
{
    private final InputBuffer B;
    private final int A;
    
    public ParseError(final InputBuffer obj, final int a) {
        this.B = Objects.requireNonNull(obj, "inputBuffer");
        this.A = a;
    }
    
    public InputBuffer getInputBuffer() {
        return this.B;
    }
    
    public int getErrorIndex() {
        return this.A;
    }
}
