// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.parser;

import org.sonar.sslr.internal.matchers.TextUtils;
import org.sonar.sslr.internal.matchers.InputBuffer;
import java.util.Objects;

public class ParseErrorFormatter
{
    private static final int A = 10;
    
    public String format(final ParseError obj) {
        Objects.requireNonNull(obj);
        final InputBuffer inputBuffer = obj.getInputBuffer();
        final InputBuffer.Position position = inputBuffer.getPosition(obj.getErrorIndex());
        final StringBuilder sb = new StringBuilder();
        sb.append("Parse error at line ").append(position.getLine()).append(" column ").append(position.getColumn()).append(":\n\n");
        A(sb, inputBuffer, position);
        return sb.toString();
    }
    
    private static void A(final StringBuilder sb, final InputBuffer inputBuffer, final InputBuffer.Position position) {
        final int max = Math.max(position.getLine() - 10, 1);
        final int min = Math.min(position.getLine() + 10, inputBuffer.getLineCount());
        final int length = Integer.toString(min).length();
        final String string = "%1$" + length + "d: ";
        for (int i = max; i <= min; ++i) {
            sb.append(String.format(string, i));
            sb.append(TextUtils.trimTrailingLineSeparatorFrom(inputBuffer.extractLine(i)).replace("\t", " ")).append('\n');
            if (i == position.getLine()) {
                for (int j = 1; j < position.getColumn() + length + 2; ++j) {
                    sb.append(' ');
                }
                sb.append("^\n");
            }
        }
    }
}
