// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.parser;

import com.sonar.sslr.api.Grammar;

public abstract class LexerlessGrammar extends Grammar
{
}
