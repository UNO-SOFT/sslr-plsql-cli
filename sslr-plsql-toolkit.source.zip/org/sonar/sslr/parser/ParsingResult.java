// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.parser;

import java.util.Objects;
import javax.annotation.Nullable;
import org.sonar.sslr.internal.matchers.InputBuffer;
import org.sonar.sslr.internal.matchers.ParseNode;

public class ParsingResult
{
    private final boolean A;
    private final ParseNode D;
    private final InputBuffer B;
    private final ParseError C;
    
    public ParsingResult(final InputBuffer obj, final boolean a, @Nullable final ParseNode d, @Nullable final ParseError c) {
        this.B = Objects.requireNonNull(obj, "inputBuffer");
        this.A = a;
        this.D = d;
        this.C = c;
    }
    
    public InputBuffer getInputBuffer() {
        return this.B;
    }
    
    public boolean isMatched() {
        return this.A;
    }
    
    public ParseError getParseError() {
        return this.C;
    }
    
    public ParseNode getParseTreeRoot() {
        return this.D;
    }
}
