// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.ast;

import java.util.Iterator;
import java.util.function.Predicate;
import com.sonar.sslr.api.AstNodeType;
import com.sonar.sslr.api.AstNode;

@Deprecated
public interface AstSelect extends Iterable<AstNode>
{
    AstSelect children();
    
    AstSelect children(final AstNodeType p0);
    
    AstSelect children(final AstNodeType... p0);
    
    AstSelect nextSibling();
    
    AstSelect previousSibling();
    
    AstSelect parent();
    
    AstSelect firstAncestor(final AstNodeType p0);
    
    AstSelect firstAncestor(final AstNodeType... p0);
    
    AstSelect descendants(final AstNodeType p0);
    
    AstSelect descendants(final AstNodeType... p0);
    
    boolean isEmpty();
    
    boolean isNotEmpty();
    
    AstSelect filter(final AstNodeType p0);
    
    AstSelect filter(final AstNodeType... p0);
    
    AstSelect filter(final Predicate<AstNode> p0);
    
    int size();
    
    AstNode get(final int p0);
    
    Iterator<AstNode> iterator();
}
