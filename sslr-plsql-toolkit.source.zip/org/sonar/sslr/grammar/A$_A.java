// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.grammar;

import org.sonar.sslr.internal.vm.SequenceExpression;
import org.sonar.sslr.internal.vm.CompilableGrammarRule;

static class _A implements GrammarRuleBuilder
{
    private final A A;
    private final CompilableGrammarRule B;
    
    public _A(final A a, final CompilableGrammarRule b) {
        this.A = a;
        this.B = b;
    }
    
    @Override
    public GrammarRuleBuilder is(final Object o) {
        if (this.B.getExpression() != null) {
            throw new GrammarException("The rule '" + this.B.getRuleKey() + "' has already been defined somewhere in the grammar.");
        }
        this.B.setExpression(this.A.convertToExpression(o));
        return this;
    }
    
    @Override
    public GrammarRuleBuilder is(final Object o, final Object... array) {
        return this.is(new SequenceExpression(this.A.D(o, array)));
    }
    
    @Override
    public GrammarRuleBuilder override(final Object o) {
        this.B.setExpression(this.A.convertToExpression(o));
        return this;
    }
    
    @Override
    public GrammarRuleBuilder override(final Object o, final Object... array) {
        return this.override(new SequenceExpression(this.A.D(o, array)));
    }
    
    @Override
    public void skip() {
        this.B.skip();
    }
    
    @Override
    public void skipIfOneChild() {
        this.B.skipIfOneChild();
    }
}
