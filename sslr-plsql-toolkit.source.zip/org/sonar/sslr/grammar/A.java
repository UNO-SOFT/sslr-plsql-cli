// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.grammar;

import org.sonar.sslr.internal.vm.CompilableGrammarRule;
import org.sonar.sslr.internal.vm.NothingExpression;
import org.sonar.sslr.internal.vm.NextNotExpression;
import org.sonar.sslr.internal.vm.NextExpression;
import org.sonar.sslr.internal.vm.ZeroOrMoreExpression;
import org.sonar.sslr.internal.vm.OneOrMoreExpression;
import org.sonar.sslr.internal.vm.OptionalExpression;
import org.sonar.sslr.internal.vm.FirstOfExpression;
import org.sonar.sslr.internal.vm.SequenceExpression;
import org.sonar.sslr.internal.vm.ParsingExpression;

abstract class A
{
    public abstract GrammarRuleBuilder rule(final GrammarRuleKey p0);
    
    public abstract void setRootRule(final GrammarRuleKey p0);
    
    public final Object B(final Object o, final Object o2) {
        return new SequenceExpression(new ParsingExpression[] { this.convertToExpression(o), this.convertToExpression(o2) });
    }
    
    public final Object B(final Object o, final Object o2, final Object... array) {
        return new SequenceExpression(this.A(o, o2, array));
    }
    
    public final Object A(final Object o, final Object o2) {
        return new FirstOfExpression(new ParsingExpression[] { this.convertToExpression(o), this.convertToExpression(o2) });
    }
    
    public final Object C(final Object o, final Object o2, final Object... array) {
        return new FirstOfExpression(this.A(o, o2, array));
    }
    
    public final Object C(final Object o) {
        return new OptionalExpression(this.convertToExpression(o));
    }
    
    public final Object C(final Object o, final Object... array) {
        return new OptionalExpression(new SequenceExpression(this.D(o, array)));
    }
    
    public final Object A(final Object o) {
        return new OneOrMoreExpression(this.convertToExpression(o));
    }
    
    public final Object A(final Object o, final Object... array) {
        return new OneOrMoreExpression(new SequenceExpression(this.D(o, array)));
    }
    
    public final Object D(final Object o) {
        return new ZeroOrMoreExpression(this.convertToExpression(o));
    }
    
    public final Object E(final Object o, final Object... array) {
        return new ZeroOrMoreExpression(new SequenceExpression(this.D(o, array)));
    }
    
    public final Object E(final Object o) {
        return new NextExpression(this.convertToExpression(o));
    }
    
    public final Object B(final Object o, final Object... array) {
        return new NextExpression(new SequenceExpression(this.D(o, array)));
    }
    
    public final Object B(final Object o) {
        return new NextNotExpression(this.convertToExpression(o));
    }
    
    public final Object F(final Object o, final Object... array) {
        return new NextNotExpression(new SequenceExpression(this.D(o, array)));
    }
    
    public final Object A() {
        return NothingExpression.INSTANCE;
    }
    
    protected abstract ParsingExpression convertToExpression(final Object p0);
    
    final ParsingExpression[] D(final Object o, final Object[] array) {
        final ParsingExpression[] array2 = new ParsingExpression[1 + array.length];
        array2[0] = this.convertToExpression(o);
        for (int i = 0; i < array.length; ++i) {
            array2[1 + i] = this.convertToExpression(array[i]);
        }
        return array2;
    }
    
    private ParsingExpression[] A(final Object o, final Object o2, final Object[] array) {
        final ParsingExpression[] array2 = new ParsingExpression[2 + array.length];
        array2[0] = this.convertToExpression(o);
        array2[1] = this.convertToExpression(o2);
        for (int i = 0; i < array.length; ++i) {
            array2[2 + i] = this.convertToExpression(array[i]);
        }
        return array2;
    }
    
    static class _A implements GrammarRuleBuilder
    {
        private final A A;
        private final CompilableGrammarRule B;
        
        public _A(final A a, final CompilableGrammarRule b) {
            this.A = a;
            this.B = b;
        }
        
        @Override
        public GrammarRuleBuilder is(final Object o) {
            if (this.B.getExpression() != null) {
                throw new GrammarException("The rule '" + this.B.getRuleKey() + "' has already been defined somewhere in the grammar.");
            }
            this.B.setExpression(this.A.convertToExpression(o));
            return this;
        }
        
        @Override
        public GrammarRuleBuilder is(final Object o, final Object... array) {
            return this.is(new SequenceExpression(this.A.D(o, array)));
        }
        
        @Override
        public GrammarRuleBuilder override(final Object o) {
            this.B.setExpression(this.A.convertToExpression(o));
            return this;
        }
        
        @Override
        public GrammarRuleBuilder override(final Object o, final Object... array) {
            return this.override(new SequenceExpression(this.A.D(o, array)));
        }
        
        @Override
        public void skip() {
            this.B.skip();
        }
        
        @Override
        public void skipIfOneChild() {
            this.B.skipIfOneChild();
        }
    }
}
