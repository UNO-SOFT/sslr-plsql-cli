// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.grammar;

public interface GrammarRuleBuilder
{
    GrammarRuleBuilder is(final Object p0);
    
    GrammarRuleBuilder is(final Object p0, final Object... p1);
    
    GrammarRuleBuilder override(final Object p0);
    
    GrammarRuleBuilder override(final Object p0, final Object... p1);
    
    void skip();
    
    void skipIfOneChild();
}
