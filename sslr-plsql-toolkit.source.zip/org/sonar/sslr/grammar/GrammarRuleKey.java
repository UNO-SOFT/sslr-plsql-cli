// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.grammar;

import com.sonar.sslr.api.AstNodeType;

public interface GrammarRuleKey extends AstNodeType
{
}
