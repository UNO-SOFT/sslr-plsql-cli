// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.grammar;

import org.sonar.sslr.internal.vm.lexerful.TokenTypeClassExpression;
import org.sonar.sslr.internal.vm.lexerful.TokenValueExpression;
import org.sonar.sslr.internal.vm.lexerful.TokenTypeExpression;
import java.util.Objects;
import org.sonar.sslr.internal.vm.FirstOfExpression;
import org.sonar.sslr.internal.vm.ZeroOrMoreExpression;
import org.sonar.sslr.internal.vm.lexerful.TillNewLineExpression;
import org.sonar.sslr.internal.vm.lexerful.TokensBridgeExpression;
import org.sonar.sslr.internal.vm.lexerful.TokenTypesExpression;
import com.sonar.sslr.api.TokenType;
import org.sonar.sslr.internal.vm.lexerful.AnyTokenExpression;
import org.sonar.sslr.internal.vm.NextNotExpression;
import org.sonar.sslr.internal.vm.SequenceExpression;
import org.sonar.sslr.internal.vm.lexerful.AdjacentExpression;
import org.sonar.sslr.internal.vm.ParsingExpression;
import java.util.Iterator;
import org.sonar.sslr.internal.grammar.MutableGrammar;
import com.sonar.sslr.api.Grammar;
import org.sonar.sslr.internal.vm.CompilableGrammarRule;
import java.util.HashMap;
import com.sonar.sslr.impl.matcher.RuleDefinition;
import java.util.Map;

public class LexerfulGrammarBuilder extends A
{
    private final Map<GrammarRuleKey, RuleDefinition> A;
    private GrammarRuleKey B;
    
    public static LexerfulGrammarBuilder create() {
        return new LexerfulGrammarBuilder();
    }
    
    private LexerfulGrammarBuilder() {
        this.A = new HashMap<GrammarRuleKey, RuleDefinition>();
    }
    
    @Override
    public GrammarRuleBuilder rule(final GrammarRuleKey grammarRuleKey) {
        RuleDefinition ruleDefinition = this.A.get(grammarRuleKey);
        if (ruleDefinition == null) {
            ruleDefinition = new RuleDefinition(grammarRuleKey);
            this.A.put(grammarRuleKey, ruleDefinition);
        }
        return new _A(this, ruleDefinition);
    }
    
    @Override
    public void setRootRule(final GrammarRuleKey b) {
        this.rule(b);
        this.B = b;
    }
    
    public Grammar build() {
        for (final RuleDefinition ruleDefinition : this.A.values()) {
            if (ruleDefinition.getExpression() == null) {
                throw new GrammarException("The rule '" + ruleDefinition.getRuleKey() + "' hasn't been defined.");
            }
        }
        return new MutableGrammar(this.A, this.B);
    }
    
    public Grammar buildWithMemoizationOfMatchesForAllRules() {
        final Iterator<RuleDefinition> iterator = this.A.values().iterator();
        while (iterator.hasNext()) {
            iterator.next().enableMemoization();
        }
        return this.build();
    }
    
    public Object adjacent(final Object o) {
        return new SequenceExpression(new ParsingExpression[] { AdjacentExpression.INSTANCE, this.convertToExpression(o) });
    }
    
    public Object anyTokenButNot(final Object o) {
        return new SequenceExpression(new ParsingExpression[] { new NextNotExpression(this.convertToExpression(o)), AnyTokenExpression.INSTANCE });
    }
    
    public Object isOneOfThem(final TokenType tokenType, final TokenType... array) {
        final TokenType[] array2 = new TokenType[1 + array.length];
        array2[0] = tokenType;
        System.arraycopy(array, 0, array2, 1, array.length);
        return new TokenTypesExpression(array2);
    }
    
    public Object bridge(final TokenType tokenType, final TokenType tokenType2) {
        return new TokensBridgeExpression(tokenType, tokenType2);
    }
    
    @Deprecated
    public Object everything() {
        return AnyTokenExpression.INSTANCE;
    }
    
    public Object anyToken() {
        return AnyTokenExpression.INSTANCE;
    }
    
    public Object tillNewLine() {
        return TillNewLineExpression.INSTANCE;
    }
    
    public Object till(final Object o) {
        final ParsingExpression convertToExpression = this.convertToExpression(o);
        return new SequenceExpression(new ParsingExpression[] { new ZeroOrMoreExpression(new SequenceExpression(new ParsingExpression[] { new NextNotExpression(convertToExpression), AnyTokenExpression.INSTANCE })), convertToExpression });
    }
    
    public Object exclusiveTill(final Object o) {
        return new ZeroOrMoreExpression(new SequenceExpression(new ParsingExpression[] { new NextNotExpression(this.convertToExpression(o)), AnyTokenExpression.INSTANCE }));
    }
    
    public Object exclusiveTill(final Object o, final Object... array) {
        return this.exclusiveTill(new FirstOfExpression(this.D(o, array)));
    }
    
    @Override
    protected ParsingExpression convertToExpression(final Object obj) {
        Objects.requireNonNull(obj, "Parsing expression can't be null");
        ParsingExpression parsingExpression;
        if (obj instanceof ParsingExpression) {
            parsingExpression = (ParsingExpression)obj;
        }
        else if (obj instanceof GrammarRuleKey) {
            final GrammarRuleKey grammarRuleKey = (GrammarRuleKey)obj;
            this.rule(grammarRuleKey);
            parsingExpression = this.A.get(grammarRuleKey);
        }
        else if (obj instanceof TokenType) {
            parsingExpression = new TokenTypeExpression((TokenType)obj);
        }
        else if (obj instanceof String) {
            parsingExpression = new TokenValueExpression((String)obj);
        }
        else {
            if (!(obj instanceof Class)) {
                throw new IllegalArgumentException("Incorrect type of parsing expression: " + obj.getClass().toString());
            }
            parsingExpression = new TokenTypeClassExpression((Class)obj);
        }
        return parsingExpression;
    }
}
