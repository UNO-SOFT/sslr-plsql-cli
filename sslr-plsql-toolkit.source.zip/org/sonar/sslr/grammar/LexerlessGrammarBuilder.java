// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.grammar;

import org.sonar.sslr.internal.vm.StringExpression;
import java.util.Objects;
import org.sonar.sslr.internal.vm.ParsingExpression;
import org.sonar.sslr.internal.vm.TriviaExpression;
import com.sonar.sslr.api.Trivia;
import org.sonar.sslr.internal.vm.TokenExpression;
import com.sonar.sslr.api.TokenType;
import org.sonar.sslr.internal.vm.EndOfInputExpression;
import org.sonar.sslr.internal.vm.PatternExpression;
import java.util.Iterator;
import org.sonar.sslr.internal.grammar.MutableGrammar;
import org.sonar.sslr.parser.LexerlessGrammar;
import org.sonar.sslr.internal.vm.CompilableGrammarRule;
import java.util.HashMap;
import org.sonar.sslr.internal.grammar.MutableParsingRule;
import java.util.Map;

public class LexerlessGrammarBuilder extends A
{
    private final Map<GrammarRuleKey, MutableParsingRule> C;
    private GrammarRuleKey D;
    
    public static LexerlessGrammarBuilder create() {
        return new LexerlessGrammarBuilder();
    }
    
    private LexerlessGrammarBuilder() {
        this.C = new HashMap<GrammarRuleKey, MutableParsingRule>();
    }
    
    @Override
    public GrammarRuleBuilder rule(final GrammarRuleKey grammarRuleKey) {
        MutableParsingRule mutableParsingRule = this.C.get(grammarRuleKey);
        if (mutableParsingRule == null) {
            mutableParsingRule = new MutableParsingRule(grammarRuleKey);
            this.C.put(grammarRuleKey, mutableParsingRule);
        }
        return new _A(this, mutableParsingRule);
    }
    
    @Override
    public void setRootRule(final GrammarRuleKey d) {
        this.rule(d);
        this.D = d;
    }
    
    public LexerlessGrammar build() {
        for (final MutableParsingRule mutableParsingRule : this.C.values()) {
            if (mutableParsingRule.getExpression() == null) {
                throw new GrammarException("The rule '" + mutableParsingRule.getRuleKey() + "' hasn't been defined.");
            }
        }
        return new MutableGrammar(this.C, this.D);
    }
    
    public Object regexp(final String s) {
        return new PatternExpression(s);
    }
    
    public Object endOfInput() {
        return EndOfInputExpression.INSTANCE;
    }
    
    public Object token(final TokenType tokenType, final Object o) {
        return new TokenExpression(tokenType, this.convertToExpression(o));
    }
    
    public Object commentTrivia(final Object o) {
        return new TriviaExpression(Trivia.TriviaKind.COMMENT, this.convertToExpression(o));
    }
    
    public Object skippedTrivia(final Object o) {
        return new TriviaExpression(Trivia.TriviaKind.SKIPPED_TEXT, this.convertToExpression(o));
    }
    
    @Override
    protected ParsingExpression convertToExpression(final Object obj) {
        Objects.requireNonNull(obj, "Parsing expression can't be null");
        ParsingExpression parsingExpression;
        if (obj instanceof ParsingExpression) {
            parsingExpression = (ParsingExpression)obj;
        }
        else if (obj instanceof GrammarRuleKey) {
            final GrammarRuleKey grammarRuleKey = (GrammarRuleKey)obj;
            this.rule(grammarRuleKey);
            parsingExpression = this.C.get(grammarRuleKey);
        }
        else if (obj instanceof String) {
            parsingExpression = new StringExpression((String)obj);
        }
        else {
            if (!(obj instanceof Character)) {
                throw new IllegalArgumentException("Incorrect type of parsing expression: " + obj.getClass().toString());
            }
            parsingExpression = new StringExpression(((Character)obj).toString());
        }
        return parsingExpression;
    }
}
