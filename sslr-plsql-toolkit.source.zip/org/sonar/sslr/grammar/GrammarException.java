// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.grammar;

public class GrammarException extends RuntimeException
{
    public GrammarException(final String message) {
        super(message);
    }
    
    public GrammarException(final Throwable cause, final String message) {
        super(message, cause);
    }
}
