// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.channel;

public class ChannelException extends RuntimeException
{
    public ChannelException(final String message, final Exception cause) {
        super(message, cause);
    }
    
    public ChannelException(final String message) {
        super(message);
    }
    
    public ChannelException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
