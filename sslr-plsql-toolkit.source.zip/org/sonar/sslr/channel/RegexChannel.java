// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.channel;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public abstract class RegexChannel<O> extends Channel<O>
{
    private final StringBuilder W;
    private final Matcher V;
    
    public RegexChannel(final String regex) {
        this.W = new StringBuilder();
        this.V = Pattern.compile(regex).matcher("");
    }
    
    @Override
    public final boolean consume(final CodeReader codeReader, final O o) {
        if (codeReader.popTo(this.V, this.W) > 0) {
            this.consume(this.W, o);
            this.W.delete(0, this.W.length());
            return true;
        }
        return false;
    }
    
    protected abstract void consume(final CharSequence p0, final O p1);
}
