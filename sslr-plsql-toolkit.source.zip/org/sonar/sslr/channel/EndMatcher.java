// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.channel;

public interface EndMatcher
{
    boolean match(final int p0);
}
