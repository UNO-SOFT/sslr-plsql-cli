// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.channel;

import java.util.regex.Matcher;
import java.io.IOException;
import java.io.Reader;

public class CodeReader extends CodeBuffer
{
    private Cursor J;
    
    public CodeReader(final Reader reader) {
        super(reader, new CodeReaderConfiguration());
    }
    
    public CodeReader(final String s) {
        super(s, new CodeReaderConfiguration());
    }
    
    public CodeReader(final Reader reader, final CodeReaderConfiguration codeReaderConfiguration) {
        super(reader, codeReaderConfiguration);
    }
    
    public CodeReader(final String s, final CodeReaderConfiguration codeReaderConfiguration) {
        super(s, codeReaderConfiguration);
    }
    
    public final void pop(final Appendable appendable) {
        try {
            appendable.append((char)this.pop());
        }
        catch (final IOException ex) {
            throw new ChannelException(ex.getMessage(), ex);
        }
    }
    
    public final char[] peek(final int n) {
        final char[] array = new char[n];
        for (int n2 = 0, n3 = this.intAt(n2); n3 != -1 && n2 < n; ++n2, n3 = this.intAt(n2)) {
            array[n2] = (char)n3;
        }
        return array;
    }
    
    public final void peekTo(final EndMatcher endMatcher, final Appendable appendable) {
        int n = 0;
        int n2 = this.intAt(n);
        try {
            while (!endMatcher.match(n2) && n2 != -1) {
                appendable.append((char)n2);
                ++n;
                n2 = this.intAt(n);
            }
        }
        catch (final IOException ex) {
            throw new ChannelException(ex.getMessage(), ex);
        }
    }
    
    public final int popTo(final Matcher matcher, final Appendable appendable) {
        return this.popTo(matcher, null, appendable);
    }
    
    public final int popTo(final Matcher matcher, final Matcher matcher2, final Appendable appendable) {
        try {
            matcher.reset(this);
            if (matcher.lookingAt()) {
                if (matcher2 != null) {
                    matcher2.reset(this);
                    matcher2.region(matcher.end(), this.length());
                    if (!matcher2.lookingAt()) {
                        return -1;
                    }
                }
                this.J = this.getCursor().clone();
                for (int i = 0; i < matcher.end(); ++i) {
                    appendable.append((char)this.pop());
                }
                return matcher.end();
            }
            return -1;
        }
        catch (final StackOverflowError stackOverflowError) {
            throw new ChannelException("Unable to apply regular expression '" + matcher.pattern().pattern() + "' at line " + this.getCursor().getLine() + " and column " + this.getCursor().getColumn() + ", because it led to a stack overflow error. This error may be due to an inefficient use of alternations - see http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=5050507", stackOverflowError);
        }
        catch (final IndexOutOfBoundsException ex) {
            return -1;
        }
        catch (final IOException ex2) {
            throw new ChannelException(ex2.getMessage(), ex2);
        }
        finally {
            matcher.reset("");
        }
        return -1;
    }
    
    public final Cursor getPreviousCursor() {
        return this.J;
    }
}
