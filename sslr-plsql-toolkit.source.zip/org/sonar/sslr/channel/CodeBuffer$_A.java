// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.channel;

import java.io.IOException;
import java.io.Reader;
import java.io.FilterReader;

static final class _A extends FilterReader
{
    private final CodeReaderFilter<?> A;
    
    public _A(final Reader reader, final CodeReaderFilter<?> a, final CodeReaderConfiguration codeReaderConfiguration) {
        super(reader);
        (this.A = a).setConfiguration(codeReaderConfiguration.cloneWithoutCodeReaderFilters());
        this.A.setReader(reader);
    }
    
    @Override
    public int read() throws IOException {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public int read(final char[] array, final int n, final int n2) throws IOException {
        final int read = this.A.read(array, n, n2);
        return (read == 0) ? -1 : read;
    }
    
    @Override
    public long skip(final long n) throws IOException {
        throw new UnsupportedOperationException();
    }
}
