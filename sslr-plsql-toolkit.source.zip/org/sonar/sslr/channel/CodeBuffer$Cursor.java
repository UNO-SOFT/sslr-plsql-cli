// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.channel;

public static class Cursor implements Cloneable
{
    private int A;
    private int B;
    
    public Cursor() {
        this.A = 1;
        this.B = 0;
    }
    
    public int getLine() {
        return this.A;
    }
    
    public int getColumn() {
        return this.B;
    }
    
    public Cursor clone() {
        Cursor cursor;
        try {
            cursor = (Cursor)super.clone();
        }
        catch (final CloneNotSupportedException cause) {
            throw new RuntimeException(cause);
        }
        cursor.B = this.B;
        cursor.A = this.A;
        return cursor;
    }
}
