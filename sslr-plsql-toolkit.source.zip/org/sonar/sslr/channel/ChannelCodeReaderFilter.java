// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.channel;

import java.io.IOException;
import java.io.Reader;

public final class ChannelCodeReaderFilter<O> extends CodeReaderFilter<O>
{
    private Channel<O>[] E;
    private CodeReader D;
    
    public ChannelCodeReaderFilter(final Channel<O>... e) {
        this.E = new Channel[0];
        this.E = e;
    }
    
    public ChannelCodeReaderFilter(final O o, final Channel<O>... e) {
        super(o);
        this.E = new Channel[0];
        this.E = e;
    }
    
    @Override
    public void setReader(final Reader reader) {
        super.setReader(reader);
        this.D = new CodeReader(reader, this.getConfiguration());
    }
    
    @Override
    public int read(final char[] array, final int n, final int n2) throws IOException {
        int n3 = n;
        if (this.D.peek() == -1) {
            return -1;
        }
        final int n4 = n3;
        while (n3 < array.length && this.D.peek() != -1) {
            boolean b = false;
            final Channel<O>[] e = this.E;
            for (int length = e.length, i = 0; i < length; ++i) {
                if (e[i].consume(this.D, this.getOutput())) {
                    b = true;
                    break;
                }
            }
            if (!b) {
                array[n3] = (char)this.D.pop();
                ++n3;
            }
        }
        return n3 - n4;
    }
}
