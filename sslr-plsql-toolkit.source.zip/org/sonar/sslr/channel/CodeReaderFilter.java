// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.channel;

import java.io.IOException;
import java.io.Reader;

public abstract class CodeReaderFilter<O>
{
    private Reader A;
    private O B;
    private CodeReaderConfiguration C;
    
    public CodeReaderFilter() {
    }
    
    public CodeReaderFilter(final O b) {
        this.B = b;
    }
    
    public Reader getReader() {
        return this.A;
    }
    
    public void setReader(final Reader a) {
        this.A = a;
    }
    
    public O getOutput() {
        return this.B;
    }
    
    public void setOutput(final O b) {
        this.B = b;
    }
    
    public CodeReaderConfiguration getConfiguration() {
        return this.C;
    }
    
    public void setConfiguration(final CodeReaderConfiguration c) {
        this.C = c;
    }
    
    public abstract int read(final char[] p0, final int p1, final int p2) throws IOException;
}
