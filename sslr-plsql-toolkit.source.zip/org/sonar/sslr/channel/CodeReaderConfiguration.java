// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.channel;

import java.util.Collection;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

public class CodeReaderConfiguration
{
    public static final int DEFAULT_TAB_WIDTH = 1;
    private int A;
    private List<CodeReaderFilter<?>> B;
    
    public CodeReaderConfiguration() {
        this.A = 1;
        this.B = new ArrayList<CodeReaderFilter<?>>();
    }
    
    public int getTabWidth() {
        return this.A;
    }
    
    public void setTabWidth(final int a) {
        this.A = a;
    }
    
    public CodeReaderFilter[] getCodeReaderFilters() {
        return this.B.toArray(new CodeReaderFilter[this.B.size()]);
    }
    
    public void setCodeReaderFilters(final CodeReaderFilter<?>... a) {
        this.B = new ArrayList<CodeReaderFilter<?>>(Arrays.asList(a));
    }
    
    public void addCodeReaderFilters(final CodeReaderFilter<?> codeReaderFilter) {
        this.B.add(codeReaderFilter);
    }
    
    public CodeReaderConfiguration cloneWithoutCodeReaderFilters() {
        final CodeReaderConfiguration codeReaderConfiguration = new CodeReaderConfiguration();
        codeReaderConfiguration.setTabWidth(this.A);
        return codeReaderConfiguration;
    }
}
