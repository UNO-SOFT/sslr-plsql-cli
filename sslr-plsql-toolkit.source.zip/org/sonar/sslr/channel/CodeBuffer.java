// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.channel;

import java.io.FilterReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

public class CodeBuffer implements CharSequence
{
    private int H;
    private Cursor G;
    private char[] B;
    private int I;
    private static final char C = '\n';
    private static final char A = '\r';
    private int E;
    private boolean D;
    private StringBuilder F;
    
    protected CodeBuffer(final String s, final CodeReaderConfiguration codeReaderConfiguration) {
        this(new StringReader(s), codeReaderConfiguration);
    }
    
    protected CodeBuffer(final Reader reader, final CodeReaderConfiguration codeReaderConfiguration) {
        this.H = -1;
        this.I = 0;
        this.D = false;
        this.F = new StringBuilder();
        try {
            try {
                this.H = -1;
                this.G = new Cursor();
                this.E = codeReaderConfiguration.getTabWidth();
                Reader reader2 = reader;
                final CodeReaderFilter[] codeReaderFilters = codeReaderConfiguration.getCodeReaderFilters();
                for (int length = codeReaderFilters.length, i = 0; i < length; ++i) {
                    reader2 = new _A(reader2, codeReaderFilters[i], codeReaderConfiguration);
                }
                try (final Reader reader3 = reader2) {
                    this.B = this.A(reader3);
                }
                if (reader != null) {
                    reader.close();
                }
            }
            catch (final Throwable t2) {
                if (reader != null) {
                    try {
                        reader.close();
                    }
                    catch (final Throwable exception2) {
                        t2.addSuppressed(exception2);
                    }
                }
                throw t2;
            }
        }
        catch (final IOException ex) {
            throw new ChannelException(ex.getMessage(), ex);
        }
    }
    
    private char[] A(final Reader reader) throws IOException {
        final StringBuilder sb = new StringBuilder();
        final char[] array = new char[4096];
        int read;
        while ((read = reader.read(array)) > 0) {
            sb.append(array, 0, read);
        }
        return sb.toString().toCharArray();
    }
    
    public final int pop() {
        if (this.I >= this.B.length) {
            return -1;
        }
        final char h = this.B[this.I];
        ++this.I;
        this.A(h);
        if (this.D) {
            this.F.append(h);
        }
        return this.H = h;
    }
    
    private void A(final int n) {
        if (n == 10 || (n == 13 && this.peek() != 10)) {
            this.G.A++;
            this.G.B = 0;
        }
        else if (n == 9) {
            this.G.B += this.E;
        }
        else {
            this.G.B++;
        }
    }
    
    public final int lastChar() {
        return this.H;
    }
    
    public final int peek() {
        return this.intAt(0);
    }
    
    public final int getLinePosition() {
        return this.G.A;
    }
    
    public final Cursor getCursor() {
        return this.G;
    }
    
    public final int getColumnPosition() {
        return this.G.B;
    }
    
    public final CodeBuffer setColumnPosition(final int n) {
        this.G.B = n;
        return this;
    }
    
    public final void setLinePosition(final int n) {
        this.G.A = n;
    }
    
    public final void startRecording() {
        this.D = true;
    }
    
    public final CharSequence stopRecording() {
        this.D = false;
        final StringBuilder f = this.F;
        this.F = new StringBuilder();
        return f;
    }
    
    @Override
    public final char charAt(final int n) {
        return (char)this.intAt(n);
    }
    
    protected final int intAt(final int n) {
        if (this.I + n >= this.B.length) {
            return -1;
        }
        return this.B[this.I + n];
    }
    
    @Override
    public final int length() {
        return this.B.length - this.I;
    }
    
    @Override
    public final CharSequence subSequence(final int n, final int n2) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("CodeReader(");
        sb.append("line:").append(this.G.A);
        sb.append("|column:").append(this.G.B);
        sb.append("|cursor value:'").append((char)this.peek()).append("'");
        sb.append(")");
        return sb.toString();
    }
    
    static final class _A extends FilterReader
    {
        private final CodeReaderFilter<?> A;
        
        public _A(final Reader reader, final CodeReaderFilter<?> a, final CodeReaderConfiguration codeReaderConfiguration) {
            super(reader);
            (this.A = a).setConfiguration(codeReaderConfiguration.cloneWithoutCodeReaderFilters());
            this.A.setReader(reader);
        }
        
        @Override
        public int read() throws IOException {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public int read(final char[] array, final int n, final int n2) throws IOException {
            final int read = this.A.read(array, n, n2);
            return (read == 0) ? -1 : read;
        }
        
        @Override
        public long skip(final long n) throws IOException {
            throw new UnsupportedOperationException();
        }
    }
    
    public static class Cursor implements Cloneable
    {
        private int A;
        private int B;
        
        public Cursor() {
            this.A = 1;
            this.B = 0;
        }
        
        public int getLine() {
            return this.A;
        }
        
        public int getColumn() {
            return this.B;
        }
        
        public Cursor clone() {
            Cursor cursor;
            try {
                cursor = (Cursor)super.clone();
            }
            catch (final CloneNotSupportedException cause) {
                throw new RuntimeException(cause);
            }
            cursor.B = this.B;
            cursor.A = this.A;
            return cursor;
        }
    }
}
