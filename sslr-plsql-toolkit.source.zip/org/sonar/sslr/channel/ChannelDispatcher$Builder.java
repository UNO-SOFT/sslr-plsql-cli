// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.channel;

import java.util.ArrayList;
import java.util.List;

public static final class Builder
{
    private final List<Channel> A;
    private boolean B;
    
    private Builder() {
        this.A = new ArrayList<Channel>();
        this.B = false;
    }
    
    public Builder addChannel(final Channel channel) {
        this.A.add(channel);
        return this;
    }
    
    public Builder addChannels(final Channel... array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            this.addChannel(array[i]);
        }
        return this;
    }
    
    public Builder failIfNoChannelToConsumeOneCharacter() {
        this.B = true;
        return this;
    }
    
    public <O> ChannelDispatcher<O> build() {
        return new ChannelDispatcher<O>(this, null);
    }
}
