// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.channel;

public abstract class Channel<O>
{
    public abstract boolean consume(final CodeReader p0, final O p1);
}
