// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.sslr.channel;

import java.util.ArrayList;
import java.util.List;

public class ChannelDispatcher<O> extends Channel<O>
{
    private final boolean U;
    private final Channel<O>[] T;
    
    private ChannelDispatcher(final Builder builder) {
        this.T = builder.A.toArray(new Channel[builder.A.size()]);
        this.U = builder.B;
    }
    
    @Override
    public boolean consume(final CodeReader codeReader, final O o) {
        for (int i = codeReader.peek(); i != -1; i = codeReader.peek()) {
            boolean b = false;
            final Channel<O>[] t = this.T;
            for (int length = t.length, j = 0; j < length; ++j) {
                if (t[j].consume(codeReader, o)) {
                    b = true;
                    break;
                }
            }
            if (!b) {
                if (this.U) {
                    throw new IllegalStateException("None of the channel has been able to handle character '" + (char)codeReader.peek() + "' (decimal value " + codeReader.peek() + ") at line " + codeReader.getLinePosition() + ", column " + codeReader.getColumnPosition());
                }
                codeReader.pop();
            }
        }
        return true;
    }
    
    Channel[] A() {
        return this.T;
    }
    
    public static Builder builder() {
        return new Builder();
    }
    
    public static final class Builder
    {
        private final List<Channel> A;
        private boolean B;
        
        private Builder() {
            this.A = new ArrayList<Channel>();
            this.B = false;
        }
        
        public Builder addChannel(final Channel channel) {
            this.A.add(channel);
            return this;
        }
        
        public Builder addChannels(final Channel... array) {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.addChannel(array[i]);
            }
            return this;
        }
        
        public Builder failIfNoChannelToConsumeOneCharacter() {
            this.B = true;
            return this;
        }
        
        public <O> ChannelDispatcher<O> build() {
            return new ChannelDispatcher<O>(this, null);
        }
    }
}
