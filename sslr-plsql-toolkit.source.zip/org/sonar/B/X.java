// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import java.io.InputStream;
import java.io.Closeable;
import com.A.B.I.B;
import java.io.IOException;
import org.sonar.A.A;

public class X extends E
{
    private static final String m = "/sonar-colorizer.css";
    private Q k;
    private int j;
    private static final int l = 10;
    private static final int n = 13;
    
    public X(final Q k) {
        this.k = k;
        this.j = k.B();
    }
    
    public String H() {
        final StringBuilder sb = new StringBuilder();
        if (this.k.D()) {
            sb.append("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><style type=\"text/css\">");
            sb.append(J());
            sb.append("</style></head><body>");
        }
        sb.append("<table class=\"code\" id=\"");
        if (this.k.A() != null) {
            sb.append(this.k.A());
        }
        sb.append("\"><tbody><tr id=\"").append(this.j++).append("\"><td><pre>");
        return sb.toString();
    }
    
    public String I() {
        final StringBuilder sb = new StringBuilder();
        sb.append("</pre></td></tr></tbody></table>");
        if (this.k.D()) {
            sb.append("</body></html>");
        }
        return sb.toString();
    }
    
    public String G() {
        return "<tr id=\"" + this.j++ + "\"><td><pre>";
    }
    
    public String F() {
        return "</pre></td></tr>";
    }
    
    public boolean J(final A a, final F f) {
        final int g = a.G();
        if (a.D() == 10 || a.D() == 13) {
            a.F();
            if (g != a.G()) {
                f.A(this.F());
                f.A(this.G());
            }
            return true;
        }
        return false;
    }
    
    public static String J() {
        InputStream resourceAsStream = null;
        try {
            resourceAsStream = _.class.getResourceAsStream("/sonar-colorizer.css");
            return new String(com.A.B.I._.A(resourceAsStream));
        }
        catch (final IOException ex) {
            throw new U("SonarQube Colorizer CSS file not found: /sonar-colorizer.css", ex);
        }
        finally {
            B.closeQuietly((Closeable)resourceAsStream);
        }
    }
}
