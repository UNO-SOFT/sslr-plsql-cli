// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import java.util.HashMap;
import java.util.Map;

public class F implements Appendable
{
    private StringBuilder A;
    private Map B;
    
    public F() {
        this.A = new StringBuilder();
        this.B = new HashMap();
    }
    
    @Override
    public Appendable append(final CharSequence charSequence) {
        for (int i = 0; i < charSequence.length(); ++i) {
            this.append(charSequence.charAt(i));
        }
        return this;
    }
    
    @Override
    public Appendable append(final char c) {
        if (c == '<') {
            this.A.append("&lt;");
        }
        else if (c == '>') {
            this.A.append("&gt;");
        }
        else if (c == '&') {
            this.A.append("&amp;");
        }
        else {
            this.A.append(c);
        }
        return this;
    }
    
    @Override
    public Appendable append(final CharSequence charSequence, final int n, final int n2) {
        for (int i = n; i < n2; ++i) {
            this.append(charSequence.charAt(i));
        }
        return this;
    }
    
    public void A(final String str) {
        this.A.append(str);
    }
    
    @Override
    public String toString() {
        return this.A.toString();
    }
    
    public StringBuilder A() {
        return this.A;
    }
    
    public void A(final Object o, final Object o2) {
        this.B.put(o, o2);
    }
    
    public Object A(final Object o) {
        return this.B.get(o);
    }
    
    public Object B(final Object o, final Object o2) {
        Object value = this.B.get(o);
        if (value == null) {
            value = o2;
        }
        return value;
    }
    
    public Map B() {
        return this.B;
    }
}
