// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

public class J extends S
{
    public J(final String s, final String s2) {
        super("//", s, s2);
    }
}
