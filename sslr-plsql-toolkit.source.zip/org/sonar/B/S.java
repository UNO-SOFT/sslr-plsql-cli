// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import java.util.Arrays;
import org.sonar.A.A;
import org.sonar.A.B;

public abstract class S extends E
{
    private final String g;
    private final String f;
    private final char[] i;
    private static final B h;
    
    public S(final String s, final String g, final String f) {
        this.g = g;
        this.f = f;
        this.i = s.toCharArray();
    }
    
    public boolean I(final A a, final F f) {
        if (a.D() == this.i[0] && Arrays.equals(a.E(this.i.length), this.i)) {
            f.A(this.g);
            a.B(S.h, f);
            f.A(this.f);
            return true;
        }
        return false;
    }
    
    static {
        h = new B() {
            @Override
            public boolean A(final int n) {
                return n == 13 || n == 10;
            }
        };
    }
}
