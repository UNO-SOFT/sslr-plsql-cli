// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

public class U extends RuntimeException
{
    public U(final String message, final Throwable cause) {
        super(message, cause);
    }
    
    public U(final String message) {
        super(message);
    }
    
    public U(final Throwable cause) {
        super(cause);
    }
}
