// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import com.A.B.J.ED;
import java.util.Set;

public final class B
{
    private static final Set<String> A;
    
    private B() {
    }
    
    public static Set<String> A() {
        return B.A;
    }
    
    static {
        A = ED.A("as", "assert", "break", "case", "catch", "class", "continue", "def", "default", "do", "else", "extends", "finally", "for", "if", "in", "implements", "import", "instanceof", "interface", "new", "package", "property", "return", "switch", "throw", "throws", "try", "while");
    }
}
