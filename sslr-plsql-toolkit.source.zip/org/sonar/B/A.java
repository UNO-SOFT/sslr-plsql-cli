// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.B;

public class A extends E
{
    private final String H;
    private final String F;
    private static final B G;
    
    public A(final String h, final String f) {
        this.H = h;
        this.F = f;
    }
    
    @Override
    public boolean A(final org.sonar.A.A a, final F f) {
        if (a.D() == 64) {
            f.A(this.H);
            a.B(A.G, f);
            f.A(this.F);
            return true;
        }
        return false;
    }
    
    static {
        G = new B() {
            @Override
            public boolean A(final int codePoint) {
                return !Character.isJavaIdentifierPart(codePoint);
            }
        };
    }
}
