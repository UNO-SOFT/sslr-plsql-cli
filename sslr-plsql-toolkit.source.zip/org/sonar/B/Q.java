// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

public class Q
{
    public static final Q B;
    public static final V D;
    private boolean A;
    private boolean F;
    private String E;
    private int C;
    
    public Q() {
        this.A = true;
        this.F = true;
        this.E = null;
        this.C = 1;
    }
    
    public Q(final boolean a, final String e, final boolean f) {
        this.A = true;
        this.F = true;
        this.E = null;
        this.C = 1;
        this.A = a;
        this.F = f;
        this.E = e;
    }
    
    public boolean C() {
        return this.A;
    }
    
    public Q B(final boolean a) {
        this.A = a;
        return this;
    }
    
    public boolean D() {
        return this.F;
    }
    
    public Q A(final boolean f) {
        this.F = f;
        return this;
    }
    
    public String A() {
        return this.E;
    }
    
    public Q A(final String e) {
        this.E = e;
        return this;
    }
    
    public int B() {
        return this.C;
    }
    
    public Q A(final int c) {
        this.C = c;
        return this;
    }
    
    static {
        B = new Q(true, null, true);
        D = new V();
    }
}
