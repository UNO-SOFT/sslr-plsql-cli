// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.A;
import org.sonar.A.B;

public class C extends E
{
    private final String J;
    private final String I;
    private static final int L = 46;
    private B K;
    
    public C(final String j, final String i) {
        this.K = new B() {
            @Override
            public boolean A(final int n) {
                return !C.this.B(n);
            }
        };
        this.J = j;
        this.I = i;
    }
    
    private boolean A(final A a) {
        final int i = a.I();
        if (this.A(a.D()) && !Character.isJavaIdentifierPart(i) && !Character.isJavaIdentifierStart(i) && i != 46) {
            final String a2 = a.A(this.K);
            final char codePoint = a.E(a2.length() + 1)[a2.length()];
            return codePoint == '\0' || !Character.isJavaIdentifierPart((int)codePoint);
        }
        return false;
    }
    
    public boolean B(final A a, final F f) {
        if (this.A(a)) {
            f.A(this.J);
            a.B(this.K, f);
            f.A(this.I);
            return true;
        }
        return false;
    }
    
    private boolean A(final int codePoint) {
        return Character.isUpperCase(codePoint);
    }
    
    private boolean B(final int n) {
        return Character.isUpperCase(n) || n == 95 || n == 45 || Character.isDigit(n);
    }
}
