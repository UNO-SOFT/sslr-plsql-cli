// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.B;
import org.sonar.A.A;

public class N extends E
{
    private final String e;
    private final String d;
    
    public N(final String e, final String d) {
        this.e = e;
        this.d = d;
    }
    
    public N() {
        this("", "");
    }
    
    public boolean H(final A a, final F f) {
        if (a.D() == 39 || a.D() == 34) {
            f.A(this.e);
            a.B(new _A(a.D(), a), f);
            f.A(this.d);
            return true;
        }
        return false;
    }
    
    private static class _A implements B
    {
        private final int H;
        private final A G;
        private StringBuilder F;
        
        public _A(final int h, final A g) {
            this.H = h;
            this.G = g;
            this.F = new StringBuilder();
        }
        
        @Override
        public boolean A(final int n) {
            this.F.append((char)n);
            return this.G.I() == this.H && this.A() && this.F.length() > 1;
        }
        
        private boolean A() {
            int n = 0;
            for (int n2 = this.F.length() - 3; n2 >= 0 && this.F.charAt(n2) == '\\'; --n2) {
                ++n;
            }
            return n % 2 == 0;
        }
    }
}
