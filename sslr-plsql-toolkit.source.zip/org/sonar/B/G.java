// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.D;
import java.io.Reader;
import java.util.List;

public class G
{
    private List<E> A;
    
    public G(final List<E> a) {
        this.A = null;
        this.A = a;
    }
    
    public G(final _A a) {
        this.A = null;
        this.A = a.A();
    }
    
    public String A(final Reader reader) {
        return this.A(reader, null);
    }
    
    public String A(final Reader reader, final Q q) {
        return new _((q == null) ? Q.B : q).A(reader, this.A);
    }
    
    public static String C(final Reader reader, final Q q) {
        return new G(_A.D).A(reader, q);
    }
    
    public static String B(final Reader reader, final Q q) {
        return new G(_A.B).A(reader, q);
    }
    
    public static String A() {
        return X.J();
    }
    
    public enum _A
    {
        D(org.sonar.B.D.A()), 
        B(I.A());
        
        private List<E> C;
        
        private _A(final List<E> c) {
            this.C = c;
        }
        
        public List<E> A() {
            return this.C;
        }
    }
}
