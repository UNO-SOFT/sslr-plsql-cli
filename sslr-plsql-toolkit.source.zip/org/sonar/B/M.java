// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.B;
import java.util.Arrays;
import org.sonar.A.A;

public class M extends E
{
    private static final String a = "COMMENT_STARTED_ON_PREVIOUS_LINE";
    private static final String _ = "MULTILINE_COMMENT_TOKENIZER";
    private final char[] c;
    private final char[] b;
    private final String Z;
    private final String Y;
    
    @Deprecated
    public M(final String s, final String s2, final String s3) {
        this(s, "*/", s2, s3);
    }
    
    public M(final String s, final String s2, final String z, final String y) {
        this.Z = z;
        this.Y = y;
        this.c = s.toCharArray();
        this.b = s2.toCharArray();
    }
    
    public boolean G(final A a, final F f) {
        return a.D() != 10 && a.D() != 13 && (this.A(f) || (a.D() == this.c[0] && Arrays.equals(a.E(this.c.length), this.c)));
    }
    
    public boolean F(final A a, final F f) {
        if (this.G(a, f)) {
            f.A(this.Z);
            a.B(new _A(a, f), f);
            f.A(this.Y);
            return true;
        }
        return false;
    }
    
    private boolean A(final F f) {
        return f.B("COMMENT_STARTED_ON_PREVIOUS_LINE", Boolean.FALSE) == Boolean.TRUE && this.equals(f.A((Object)"MULTILINE_COMMENT_TOKENIZER"));
    }
    
    private void A(final F f, final Boolean b) {
        f.A("COMMENT_STARTED_ON_PREVIOUS_LINE", b);
        f.A("MULTILINE_COMMENT_TOKENIZER", b ? this : null);
    }
    
    private class _A implements B
    {
        private final A E;
        private final F D;
        private int C;
        
        public _A(final A e, final F d) {
            this.C = 0;
            this.E = e;
            this.D = d;
        }
        
        @Override
        public boolean A(final int n) {
            ++this.C;
            if (this.C >= M.this.b.length + M.this.c.length || (this.C >= M.this.b.length && M.this.A(this.D))) {
                boolean b = true;
                for (int i = 1; i <= M.this.b.length; ++i) {
                    if (this.E.charAt(-i) != M.this.b[M.this.b.length - i]) {
                        b = false;
                        break;
                    }
                }
                if (b) {
                    M.this.A(this.D, Boolean.FALSE);
                    return true;
                }
            }
            if (n == 13 || n == 10) {
                M.this.A(this.D, Boolean.TRUE);
                return true;
            }
            return false;
        }
    }
}
