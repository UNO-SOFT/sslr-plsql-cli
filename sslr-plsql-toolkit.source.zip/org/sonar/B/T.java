// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.A;
import java.util.List;
import org.sonar.A.D;

public class T
{
    private D<F>[] A;
    
    public T(final D<F>... a) {
        this.A = a;
    }
    
    public T(final List<D<F>> list) {
        this.A = list.toArray(new D[list.size()]);
    }
    
    public final String A(final String s) {
        final F f = new F();
        this.A(new A(s), f);
        return f.toString();
    }
    
    public final void A(final A a, final F f) {
        this.A();
    Label_0004:
        while (a.D() != -1) {
            final D<F>[] a2 = this.A;
            for (int length = a2.length, i = 0; i < length; ++i) {
                if (a2[i].A(a, f)) {
                    continue Label_0004;
                }
            }
            f.append((char)a.F());
        }
    }
    
    private void A() {
        for (int i = 0; i < this.A.length; ++i) {
            if (this.A[i] instanceof L) {
                this.A[i] = ((L)this.A[i]).C();
            }
        }
    }
}
