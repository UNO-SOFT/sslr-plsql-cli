// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.D;
import java.util.List;
import java.io.Reader;

public abstract class P
{
    public abstract String A(final Reader p0, final List<? extends D<F>> p1);
}
