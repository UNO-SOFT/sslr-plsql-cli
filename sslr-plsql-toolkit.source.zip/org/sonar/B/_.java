// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.A;
import java.util.Collection;
import java.util.ArrayList;
import org.sonar.A.D;
import java.util.List;
import java.io.Reader;

public class _ extends P
{
    private Q A;
    
    public _(final Q a) {
        this.A = null;
        this.A = a;
    }
    
    public _() {
        this(Q.B);
    }
    
    @Override
    public String A(final Reader reader, final List<? extends D<F>> list) {
        try {
            final ArrayList list2 = new ArrayList();
            final F f = new F();
            final X x = new X(this.A);
            if (this.A != null && this.A.C()) {
                f.A(x.H());
                list2.add(x);
            }
            list2.addAll(list);
            new T(list2).A(new A(reader), f);
            if (this.A != null && this.A.C()) {
                f.A(x.I());
            }
            return f.toString();
        }
        catch (final Exception ex) {
            throw new U("Can not render code", ex);
        }
    }
}
