// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.A;
import org.sonar.A.B;

private class _A implements B
{
    private final A E;
    private final F D;
    private int C;
    
    public _A(final A e, final F d) {
        this.C = 0;
        this.E = e;
        this.D = d;
    }
    
    @Override
    public boolean A(final int n) {
        ++this.C;
        if (this.C >= M.A(M.this).length + M.B(M.this).length || (this.C >= M.A(M.this).length && M.A(M.this, this.D))) {
            boolean b = true;
            for (int i = 1; i <= M.A(M.this).length; ++i) {
                if (this.E.charAt(-i) != M.A(M.this)[M.A(M.this).length - i]) {
                    b = false;
                    break;
                }
            }
            if (b) {
                M.A(M.this, this.D, Boolean.FALSE);
                return true;
            }
        }
        if (n == 13 || n == 10) {
            M.A(M.this, this.D, Boolean.TRUE);
            return true;
        }
        return false;
    }
}
