// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.B;

class C$1 implements B {
    @Override
    public boolean A(final int n) {
        return !C.A(C.this, n);
    }
}