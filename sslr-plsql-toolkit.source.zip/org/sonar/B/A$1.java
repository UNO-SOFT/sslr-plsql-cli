// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.B;

static final class A$1 implements B {
    @Override
    public boolean A(final int codePoint) {
        return !Character.isJavaIdentifierPart(codePoint);
    }
}