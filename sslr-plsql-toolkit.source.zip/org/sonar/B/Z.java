// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import com.A.B.J.ED;
import java.util.Set;

public final class Z
{
    private static final Set<String> A;
    
    private Z() {
    }
    
    public static Set<String> A() {
        return Z.A;
    }
    
    static {
        A = ED.A("abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const", "continue", "default", "do", "double", "else", "enum", "extends", "false", "final", "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native", "new", "null", "package", "private", "protected", "public", "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this", "throw", "throws", "transient", "true", "try", "void", "volatile", "while");
    }
}
