// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.A;
import org.sonar.A.B;

private static class _A implements B
{
    private final int H;
    private final A G;
    private StringBuilder F;
    
    public _A(final int h, final A g) {
        this.H = h;
        this.G = g;
        this.F = new StringBuilder();
    }
    
    @Override
    public boolean A(final int n) {
        this.F.append((char)n);
        return this.G.I() == this.H && this.A() && this.F.length() > 1;
    }
    
    private boolean A() {
        int n = 0;
        for (int n2 = this.F.length() - 3; n2 >= 0 && this.F.charAt(n2) == '\\'; --n2) {
            ++n;
        }
        return n % 2 == 0;
    }
}
