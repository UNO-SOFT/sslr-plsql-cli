// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

public class R extends M
{
    public R(final String s, final String s2) {
        super("/**", "*/", s, s2);
    }
    
    public R() {
        this("", "");
    }
}
