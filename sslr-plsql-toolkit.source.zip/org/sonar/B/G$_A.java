// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import java.util.List;

public enum _A
{
    D(org.sonar.B.D.A()), 
    B(I.A());
    
    private List<E> C;
    
    private _A(final List<E> c) {
        this.C = c;
    }
    
    public List<E> A() {
        return this.C;
    }
}
