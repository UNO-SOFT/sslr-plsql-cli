// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.A;
import java.util.Collection;
import java.util.Collections;
import java.util.regex.Pattern;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;

public class W extends L
{
    private final String V;
    private final String S;
    private boolean R;
    private Matcher W;
    private final StringBuilder X;
    private static final String T = "[a-zA-Z_][a-zA-Z0-9_]*+";
    private Set<String> U;
    
    public W(final String s, final String s2, final Set<String> set) {
        this(s, s2, set, "[a-zA-Z_][a-zA-Z0-9_]*+");
    }
    
    public W(final String v, final String s, final Set<String> u, final String regex) {
        this.R = false;
        this.X = new StringBuilder();
        this.U = new HashSet<String>();
        this.V = v;
        this.S = s;
        this.U = u;
        this.W = Pattern.compile(regex).matcher("");
    }
    
    public W(final String v, final String s, final String... elements) {
        this.R = false;
        this.X = new StringBuilder();
        this.U = new HashSet<String>();
        this.V = v;
        this.S = s;
        Collections.addAll(this.U, elements);
        this.W = Pattern.compile("[a-zA-Z_][a-zA-Z0-9_]*+").matcher("");
    }
    
    public boolean E(final A a, final F f) {
        if (a.A(this.W, this.X) > 0) {
            if (this.A(this.X.toString())) {
                f.A(this.V);
                f.append(this.X);
                f.A(this.S);
            }
            else {
                f.append(this.X);
            }
            this.X.delete(0, this.X.length());
            return true;
        }
        return false;
    }
    
    private boolean A(final String s) {
        return (!this.R && this.U.contains(s)) || (this.R && this.U.contains(s.toUpperCase()));
    }
    
    public void A(final boolean r) {
        this.R = r;
    }
    
    public W E() {
        final W w = new W(this.V, this.S, this.U, this.W.pattern().pattern());
        w.R = this.R;
        return w;
    }
}
