// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.A;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class O extends L
{
    private final String O;
    private final String N;
    private final Matcher P;
    private final StringBuilder Q;
    
    public O(final String o, final String n, final String regex) {
        this.Q = new StringBuilder();
        this.O = o;
        this.N = n;
        this.P = Pattern.compile(regex).matcher("");
    }
    
    public boolean D(final A a, final F f) {
        if (a.A(this.P, this.Q) > 0) {
            f.A(this.O);
            f.append(this.Q);
            f.A(this.N);
            this.Q.delete(0, this.Q.length());
            return true;
        }
        return false;
    }
    
    public O D() {
        return new O(this.O, this.N, this.P.pattern().pattern());
    }
}
