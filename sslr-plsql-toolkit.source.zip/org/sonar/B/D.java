// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import java.util.Collections;
import java.util.Arrays;
import java.util.List;

public final class D
{
    private D() {
    }
    
    public static List<E> A() {
        return Collections.unmodifiableList((List<? extends E>)Arrays.asList(new A("<span class=\"a\">", "</span>"), new N("<span class=\"s\">", "</span>"), new J("<span class=\"cd\">", "</span>"), new R("<span class=\"j\">", "</span>"), new K("<span class=\"cppd\">", "</span>"), new C("<span class=\"c\">", "</span>"), new W("<span class=\"k\">", "</span>", Z.A())));
    }
}
