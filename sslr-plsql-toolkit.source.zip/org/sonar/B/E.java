// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.D;

public abstract class E extends D<F>
{
}
