// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.B;

static final class S$1 implements B {
    @Override
    public boolean A(final int n) {
        return n == 13 || n == 10;
    }
}