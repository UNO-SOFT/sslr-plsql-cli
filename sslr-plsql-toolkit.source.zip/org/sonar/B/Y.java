// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import java.util.Set;

public class Y extends W
{
    public Y(final String s, final String s2, final Set<String> set) {
        super(s, s2, set);
        this.A(true);
    }
    
    public Y(final String s, final String s2, final String... array) {
        super(s, s2, array);
        this.A(true);
    }
    
    @Override
    public W E() {
        final W e = super.E();
        e.A(true);
        return e;
    }
}
