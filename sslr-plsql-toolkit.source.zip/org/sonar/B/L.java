// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

public abstract class L extends E implements Cloneable
{
    public abstract L C();
}
