// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

import org.sonar.A.A;

public class H extends E
{
    private final N M;
    
    public H(final String s, final String s2) {
        this.M = new N(s, s2);
    }
    
    public H() {
        this.M = new N("", "");
    }
    
    public boolean C(final A a, final F f) {
        return this.M.H(a, f);
    }
}
