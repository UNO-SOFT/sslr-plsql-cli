// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

public class K extends M
{
    public K(final String s, final String s2) {
        super("/*", "*/", s, s2);
    }
    
    public K() {
        this("", "");
    }
}
