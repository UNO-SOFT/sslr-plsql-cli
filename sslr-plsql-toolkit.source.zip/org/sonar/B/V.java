// 
// Decompiled by Procyon v0.6.0
// 

package org.sonar.B;

class V extends Q
{
    @Override
    public boolean C() {
        return false;
    }
    
    @Override
    public boolean D() {
        return false;
    }
    
    @Override
    public String A() {
        return null;
    }
    
    @Override
    public Q A(final boolean b) {
        throw new IllegalStateException();
    }
    
    @Override
    public Q B(final boolean b) {
        throw new IllegalStateException();
    }
    
    @Override
    public Q A(final String s) {
        throw new IllegalStateException();
    }
}
